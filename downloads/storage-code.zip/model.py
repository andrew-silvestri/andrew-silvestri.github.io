"""
Storage Revenue Stack Simulator — ERCOT-style Battery Arbitrage (LP)
====================================================================
"Model 1" from 2yearPlanWeeklyModeling.pdf (storage revenue stack simulator,
baseline + sensitivity framework). Also covers options #1 and #24 from
UT_Energy_Poster_Options_Table (battery arbitrage backtest; 2h vs 4h vs 8h value).

Perfect-foresight LP dispatch of a 1 MW battery against hourly prices:
    max  sum_t  p_t*(dis_t - ch_t) - c_deg*(dis_t + ch_t)/2
    s.t. soc_{t+1} = soc_t + eta_c*ch_t - dis_t/eta_d,  0 <= soc <= E
         0 <= ch_t, dis_t <= P_max
Perfect foresight = upper bound on arbitrage revenue; note in write-ups.

PRICES: real ERCOT settlement data is not reachable from this sandbox
(ercot.com blocked). The model generates a documented synthetic hourly year
calibrated to ERCOT DAM statistics (diurnal + seasonal shape, scarcity spikes,
occasional negative prices). Drop a real ERCOT CSV at data/prices.csv
(columns: timestamp, price_usd_mwh) and it will be used automatically.

Run: python3 model.py    (writes PNGs + CSVs to outputs/, ~1 min for 3 LPs)
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import figstyle
figstyle.use()
import pulp, os, json, csv

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "outputs")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(42)


# --------------------------------------------------------------------- prices
def synthetic_ercot_prices(hours=8760):
    """Synthetic ERCOT-like hourly DAM prices, documented + reproducible (seed 42).
    Calibration targets (approximate, based on public ERCOT summaries):
    mean ~$35-45/MWh, summer scarcity spikes, ~1-2% negative hours."""
    t = np.arange(hours)
    day = t // 24
    hod = t % 24
    doy = day % 365
    seasonal = 30 + 12 * np.exp(-((doy - 205) ** 2) / (2 * 45 ** 2))       # summer bump
    diurnal = 1.0 + 0.35 * np.exp(-((hod - 18) ** 2) / (2 * 2.5 ** 2)) \
                  + 0.15 * np.exp(-((hod - 8) ** 2) / (2 * 2.0 ** 2)) \
                  - 0.25 * np.exp(-((hod - 3) ** 2) / (2 * 3.0 ** 2)) \
                  - 0.20 * np.exp(-((hod - 13) ** 2) / (2 * 2.0 ** 2))     # solar belly
    noise = rng.lognormal(mean=0.0, sigma=0.35, size=hours)
    base = seasonal * diurnal * noise
    # scarcity spikes: mostly summer evenings
    spike_prob = 0.002 + 0.02 * np.exp(-((doy - 205) ** 2) / (2 * 30 ** 2)) * \
                 np.exp(-((hod - 18) ** 2) / (2 * 2.0 ** 2))
    spikes = rng.random(hours) < spike_prob
    base[spikes] *= rng.uniform(8, 60, spikes.sum())
    base = np.minimum(base, 5000.0)                                        # cap
    # negative-price hours (wind-heavy nights, spring)
    # Applied only where no scarcity spike was written, and no longer gated on
    # the diurnal shape, which previously halved the intended rate to 0.7%.
    neg = (rng.random(hours) < 0.015) & (~spikes)
    base[neg] = -rng.uniform(1, 20, neg.sum())
    return base


def load_prices():
    f = os.path.join(HERE, "data", "prices.csv")
    if os.path.exists(f):
        import pandas as pd
        df = pd.read_csv(f)
        p = df["price_usd_mwh"].to_numpy(float)
        print(f"loaded {len(p)} real price hours from data/prices.csv")
        return p, "real"
    return synthetic_ercot_prices(), "synthetic (seed 42, calibrated shape)"


# --------------------------------------------------------------------- LP dispatch
def optimize(prices, duration_h=4, p_max=1.0, rte=0.86, c_deg=2.0,
             soc0_frac=0.5, chunk_days=30):
    """Perfect-foresight LP, solved in monthly chunks (SoC carried across chunks).
    Returns dict with dispatch arrays and annual metrics. c_deg in $/MWh throughput."""
    eta = np.sqrt(rte)
    E = duration_h * p_max
    n = len(prices)
    ch = np.zeros(n); dis = np.zeros(n); soc = np.zeros(n + 1)
    soc[0] = soc0_frac * E
    chunk = chunk_days * 24
    for s in range(0, n, chunk):
        e = min(s + chunk, n)
        T = range(s, e)
        prob = pulp.LpProblem("arb", pulp.LpMaximize)
        c = pulp.LpVariable.dicts("c", T, 0, p_max)
        d = pulp.LpVariable.dicts("d", T, 0, p_max)
        x = pulp.LpVariable.dicts("soc", range(s, e + 1), 0, E)
        prob += pulp.lpSum(prices[t] * (d[t] - c[t]) - c_deg * 0.5 * (d[t] + c[t])
                           for t in T)
        prob += x[s] == soc[s]
        for t in T:
            prob += x[t + 1] == x[t] + eta * c[t] - d[t] / eta
            # Charging and discharging in the same hour must be forbidden
            # explicitly. Without this the LP will, at a sufficiently negative
            # price, charge and discharge at once purely to dissipate energy —
            # it earns |p|*c*(1-rte) for a cycling charge of
            # 0.5*c_deg*c*(1+rte), which pays whenever the price is below
            # about -$13/MWh at these defaults. The synthetic price series
            # never triggers it, but ERCOT reaches -$250/MWh, so a real price
            # file would. One linear constraint closes it: at most one of the
            # two can run at full power, which is what a real inverter does.
            prob += c[t] + d[t] <= p_max
        prob.solve(pulp.PULP_CBC_CMD(msg=0))
        for t in T:
            ch[t] = c[t].value(); dis[t] = d[t].value()
            soc[t + 1] = x[t + 1].value()
    gross = float(np.sum(prices * (dis - ch)))
    # The LP already charges itself for cycling; reporting the gross figure
    # while the objective maximised the net one overstates revenue and, worse,
    # flattens the cycling-cost sensitivity to near-nothing. Both are reported
    # here and the net one is the headline.
    deg_cost = float(c_deg * 0.5 * np.sum(dis + ch))
    net = gross - deg_cost
    thru = float(np.sum(dis))
    # Equivalent full cycles are counted on the storage side, not the meter
    # side. One full traversal of the state of charge delivers only eta*E to
    # the grid, so dividing AC discharge by E understates cycles by 1/eta.
    cycles = thru / (E * eta)
    # A "4 hour" battery bounded on the state of charge sustains rated output
    # for E*eta/p_max hours, not E/p_max. Report what it actually delivers.
    duration_ac = E * eta / p_max
    ann = 8760 / len(prices)
    return dict(ch=ch, dis=dis, soc=soc[:-1],
                revenue=net, revenue_gross=gross, deg_cost=deg_cost,
                throughput=thru, cycles=cycles,
                rev_per_kw_yr=net / (p_max * 1000) * ann,
                rev_per_kw_yr_gross=gross / (p_max * 1000) * ann,
                duration=duration_h, duration_ac=duration_ac,
                rte=rte, c_deg=c_deg)


# --------------------------------------------------------------------- figures
def fig_price_duration(prices, tag):
    srt = np.sort(prices)[::-1]
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.6))
    a1.plot(srt, lw=2)
    a1.set_yscale("symlog", linthresh=100)
    a1.set_xlabel("Hours (sorted)"); a1.set_ylabel("Price [$/MWh]")
    a1.set_title(f"Price duration curve — {tag}")
    a1.grid(alpha=0.3)
    a2.plot(np.arange(24), [prices[h::24].mean() for h in range(24)], lw=2.5, marker="o", ms=4)
    a2.set_xlabel("Hour of day"); a2.set_ylabel("Mean price [$/MWh]")
    a2.set_title("Average diurnal shape (solar belly + evening peak)")
    a2.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig1_prices.png")


def fig_dispatch_week(res, prices, start_day=200):
    s, e = start_day * 24, (start_day + 7) * 24
    t = np.arange(s, e)
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(11, 6.5), sharex=True)
    a1.plot(t, prices[s:e], color=figstyle.DIM, lw=1.5)
    a1.set_ylabel("Price [$/MWh]"); a1.set_yscale("symlog", linthresh=100)
    a1.set_title(f"Sample summer week — {res['duration']}h battery dispatch")
    a1.grid(alpha=0.3)
    a2.bar(t, res["dis"][s:e], color=figstyle.GREEN, label="discharge [MW]")
    a2.bar(t, -res["ch"][s:e], color="tab:red", label="charge [MW]")
    a2.plot(t, res["soc"][s:e] / (res["duration"]), color="tab:blue", lw=1.5,
            label="SoC [fraction]")
    a2.legend(loc="upper right", fontsize=9)
    a2.set_xlabel("Hour of year"); a2.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig2_dispatch_week.png")


def fig_duration_value(results):
    durs = [r["duration"] for r in results]
    revs = [r["rev_per_kw_yr"] for r in results]
    cyc = [r["cycles"] for r in results]
    fig, a1 = plt.subplots(figsize=(8, 5.5))
    bars = a1.bar([str(d) + "h" for d in durs], revs, color="#4C72B0", alpha=0.9)
    for b, r, c in zip(bars, revs, cyc):
        a1.text(b.get_x() + b.get_width() / 2, r + 1, f"${r:.0f}/kW-yr\n{c:.0f} cyc",
                ha="center", fontsize=10)
    a1.set_ylabel("Arbitrage revenue [$/kW-yr]")
    a1.set_title("Energy-arbitrage value by duration (perfect foresight upper bound)")
    a1.grid(axis="y", alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig3_duration_value.png")


def fig_sensitivity(prices):
    rtes = [0.80, 0.86, 0.92]
    degs = [0.0, 2.0, 5.0, 10.0]
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    for rte in rtes:
        vals = [optimize(prices, 4, rte=rte, c_deg=cd)["rev_per_kw_yr"] for cd in degs]
        ax.plot(degs, vals, marker="o", lw=2.5, label=f"RTE {rte:.0%}")
    ax.set_xlabel("Degradation cost  [$/MWh throughput]")
    ax.set_ylabel("Revenue  [$/kW-yr]")
    ax.set_title("4h battery: revenue vs round-trip efficiency and cycling cost")
    ax.legend(); ax.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig4_sensitivity.png")


def fig_monthly(res, prices):
    rev_m = []
    for m in range(12):
        s, e = m * 730, (m + 1) * 730
        rev_m.append(np.sum(prices[s:e] * (res["dis"][s:e] - res["ch"][s:e])) / 1000)
    fig, ax = plt.subplots(figsize=(8.5, 5))
    ax.bar(["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], rev_m,
           color="#DD8452")
    ax.set_ylabel("Revenue [$k, 1 MW / 4 h]")
    ax.set_title("Monthly arbitrage revenue — scarcity months dominate")
    ax.grid(axis="y", alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig5_monthly.png")


def main():
    prices, tag = load_prices()
    fig_price_duration(prices, tag)
    results = [optimize(prices, d) for d in (2, 4, 8)]
    r4 = results[1]
    fig_dispatch_week(r4, prices)
    fig_duration_value(results)
    fig_monthly(r4, prices)
    fig_sensitivity(prices)
    summary = {
        "price_source": tag,
        "price_mean": round(float(prices.mean()), 2),
        "price_p99": round(float(np.percentile(prices, 99)), 1),
        "neg_hours": int((prices < 0).sum()),
        **{f"rev_$/kW-yr_{r['duration']}h": round(r["rev_per_kw_yr"], 1) for r in results},
        **{f"cycles_{r['duration']}h": round(r["cycles"], 1) for r in results},
    }
    with open(f"{OUT}/summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    with open(f"{OUT}/summary.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        [w.writerow([k, v]) for k, v in summary.items()]
    # hourly dispatch CSV for the workbook
    with open(f"{OUT}/dispatch_4h.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["hour", "price_usd_mwh", "charge_mw", "discharge_mw", "soc_mwh"])
        for t in range(len(prices)):
            w.writerow([t, round(prices[t], 2), round(r4["ch"][t], 4),
                        round(r4["dis"][t], 4), round(r4["soc"][t], 4)])
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
