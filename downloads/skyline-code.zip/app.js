/* Turning a skyline into a sound, and back again.
 *
 * THE MAPPING, stated in full, because a sonification that will not say what
 * it did is a mood and not an instrument.
 *
 * The observer stands at a fixed point outside the city and turns on the spot.
 * At any moment they see a window of the horizon - a hundred degrees by
 * default - and that window is divided into 40 bars. Each bar is the tallest
 * apparent building angle in its slice of azimuth, which is exactly the
 * silhouette an eye would see, and exactly the shape of a spectrum analyser.
 *
 * Each bar drives one partial of an additive tone:
 *
 *   FREQUENCY comes from position in the window. The left edge is the root and
 *   the right edge is four octaves above it, spaced along a pentatonic scale
 *   so that any combination of towers is consonant. A skyline is not a melody
 *   and there is no reason to make it sound like a mistake.
 *
 *   AMPLITUDE comes from the apparent height of that bar, normalised against
 *   the tallest thing in that city and raised to 1.6 so that the peaks stand
 *   out the way they do in the picture. An empty stretch of horizon is
 *   silence, which is why turning away from downtown quiets the instrument.
 *
 *   THE ROOT is set by the city: the log of its median tower height mapped
 *   onto two octaves from 55 Hz. Cities of low, dense towers sound low; cities
 *   of a few enormous spikes sound high and sparse. This is the one place a
 *   real quantity is used for something arbitrary, and it is arbitrary.
 *
 * Everything is deterministic. The same city at the same bearing always
 * produces the same sound, and the sound is a function of published building
 * heights and coordinates and of nothing else.
 *
 * Audio is one oscillator per partial through one gain each, built once and
 * left running with the gains moved. Rebuilding an oscillator bank on every
 * frame is how a Web Audio page ends up clicking.
 */
(function () {
  'use strict';

  var BARS = 40;
  var SEMI = [0, 2, 4, 7, 9];        // pentatonic, in semitones
  var C = D.cities;

  var canvas = document.getElementById('c');
  var ctx = canvas.getContext('2d');
  var tip = document.getElementById('tip');

  var S = { i: 0, az: 0, fov: 100, vol: 0.55, playing: false };

  function css(n) {
    return getComputedStyle(document.documentElement)
      .getPropertyValue(n).trim();
  }

  /* ------------------------------------------------------------ geometry -- */
  /* The window is [az - fov/2, az + fov/2] and wraps, because the observer is
     turning on the spot rather than panning along a strip. */
  function bars() {
    var c = C[S.i], p = c.prof, n = p.length;
    var out = new Array(BARS);
    var step = S.fov / BARS;
    for (var k = 0; k < BARS; k++) {
      var a0 = S.az - S.fov / 2 + k * step;
      var lo = Math.floor(a0), hi = Math.ceil(a0 + step);
      var m = 0;
      for (var i = lo; i <= hi; i++) {
        var v = p[((i % n) + n) % n];
        if (v > m) m = v;
      }
      out[k] = m;
    }
    return out;
  }

  function peak() {
    var p = C[S.i].prof, m = 0;
    for (var i = 0; i < p.length; i++) if (p[i] > m) m = p[i];
    return m || 1;
  }

  /* --------------------------------------------------------------- audio -- */
  var actx = null, master = null, parts = [], rootHz = 110;

  function buildAudio() {
    if (actx) return true;
    var AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) { document.getElementById('noaudio').style.display = 'block';
               return false; }
    actx = new AC();
    master = actx.createGain();
    master.gain.value = 0;
    // a gentle low-pass so the top partials do not turn into hiss
    var lp = actx.createBiquadFilter();
    lp.type = 'lowpass'; lp.frequency.value = 6000; lp.Q.value = 0.4;
    master.connect(lp).connect(actx.destination);

    for (var k = 0; k < BARS; k++) {
      var o = actx.createOscillator();
      o.type = k % 3 === 0 ? 'triangle' : 'sine';
      var g = actx.createGain();
      g.gain.value = 0;
      o.connect(g).connect(master);
      o.start();
      parts.push({ o: o, g: g });
    }
    return true;
  }

  function freqOf(k) {
    // k across the window maps to a pentatonic ladder four octaves tall
    var step = Math.round(k / BARS * SEMI.length * 4);
    var oct = Math.floor(step / SEMI.length);
    var deg = SEMI[step % SEMI.length];
    return rootHz * Math.pow(2, oct + deg / 12);
  }

  function setRoot() {
    /* Median tower height, log-mapped onto two octaves from 55 Hz. Deliberate
       and arbitrary; the alternative was to give every city the same root,
       which would have made fifty cities sound like one instrument played
       differently rather than like fifty instruments. */
    var meds = C.map(function (c) { return Math.log(c.median); });
    var lo = Math.min.apply(null, meds), hi = Math.max.apply(null, meds);
    var f = hi > lo ? (Math.log(C[S.i].median) - lo) / (hi - lo) : 0.5;
    rootHz = 55 * Math.pow(2, 1 + (1 - f) * 2);
  }

  function pushAudio() {
    if (!actx) return;
    var b = bars(), mx = peak(), t = actx.currentTime, k;
    for (k = 0; k < BARS; k++) {
      var a = Math.pow(Math.min(1, b[k] / mx), 1.6);
      // one over k keeps the top of the ladder from dominating, which is what
      // the ear expects from anything that sounds like an instrument
      var gain = a * 0.16 / Math.sqrt(k + 1);
      parts[k].o.frequency.setTargetAtTime(freqOf(k), t, 0.02);
      parts[k].g.gain.setTargetAtTime(gain, t, 0.05);
    }
    master.gain.setTargetAtTime(S.playing ? S.vol : 0, t, 0.08);
  }

  /* --------------------------------------------------------------- draw -- */
  var dpr = 1;
  function resize() {
    var r = canvas.getBoundingClientRect();
    dpr = Math.min(2, window.devicePixelRatio || 1);
    canvas.width = Math.max(1, Math.round(r.width * dpr));
    canvas.height = Math.max(1, Math.round(r.height * dpr));
    draw();
  }

  function draw() {
    var W = canvas.width, H = canvas.height;
    ctx.clearRect(0, 0, W, H);
    var b = bars(), mx = peak();
    var acc = css('--acc'), cool = css('--cool'), dim = css('--dim');

    var pad = 26 * dpr;
    var floor = H - 54 * dpr;
    var bw = (W - pad * 2) / BARS;

    // horizon
    ctx.strokeStyle = css('--rule');
    ctx.lineWidth = 1 * dpr;
    ctx.beginPath();
    ctx.moveTo(pad, floor + 0.5);
    ctx.lineTo(W - pad, floor + 0.5);
    ctx.stroke();

    var grad = ctx.createLinearGradient(0, floor, 0, 40 * dpr);
    grad.addColorStop(0, cool);
    grad.addColorStop(1, acc);

    for (var k = 0; k < BARS; k++) {
      var h = (b[k] / mx) * (floor - 46 * dpr);
      if (h < 1) continue;
      var x = pad + k * bw;
      ctx.fillStyle = grad;
      ctx.globalAlpha = 0.30 + 0.70 * (b[k] / mx);
      ctx.fillRect(x + bw * 0.10, floor - h, bw * 0.80, h);
      ctx.globalAlpha = 1;
      // a cap, so the bar reads as a roofline rather than as a column
      ctx.fillStyle = acc;
      ctx.fillRect(x + bw * 0.10, floor - h, bw * 0.80, 2 * dpr);
    }

    // compass ticks along the bottom, every ten degrees of real azimuth
    ctx.fillStyle = dim;
    ctx.font = (11 * dpr) + 'px ui-sans-serif, system-ui, sans-serif';
    ctx.textAlign = 'center';
    var a0 = S.az - S.fov / 2;
    for (var d = Math.ceil(a0 / 10) * 10; d < a0 + S.fov; d += 10) {
      var fx = pad + ((d - a0) / S.fov) * (W - pad * 2);
      var dd = ((d % 360) + 360) % 360;
      ctx.fillRect(fx, floor + 4 * dpr, 1 * dpr, 5 * dpr);
      if (dd % 30 === 0) {
        ctx.fillText(compass(dd), fx, floor + 24 * dpr);
      }
    }
  }

  function compass(d) {
    var names = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW',
                  270: 'W', 315: 'NW' };
    return names[d] || (d + '°');
  }

  /* ------------------------------------------------------------- panel -- */
  function panel() {
    var c = C[S.i];
    document.getElementById('stats').innerHTML =
      '<dt>Towers</dt><dd>' + c.n + ' at or above ' +
        D.minHeight.toFixed(0) + ' m</dd>' +
      '<dt>Tallest</dt><dd>' + c.tallest.toFixed(0) + ' m' +
        (c.tallestName ? ' &middot; ' + esc(c.tallestName) : '') + '</dd>' +
      '<dt>Median</dt><dd>' + c.median.toFixed(0) + ' m</dd>' +
      '<dt>Viewpoint</dt><dd>' + (c.dist / 1000).toFixed(1) + ' km out, '
        + 'looking ' + compass(Math.round(c.look / 45) * 45 % 360) + '</dd>' +
      '<dt>Root</dt><dd>' + rootHz.toFixed(1) + ' Hz</dd>';

    var a0 = S.az - S.fov / 2, a1 = S.az + S.fov / 2;
    var seen = c.towers.filter(function (t) {
      var off = ((t.az - S.az + 540) % 360) - 180;
      return Math.abs(off) <= S.fov / 2;
    }).slice(0, 8);
    document.getElementById('towers').innerHTML = seen.length
      ? seen.map(function (t) {
          return '<li><b>' + esc(t.n) + '</b> &middot; ' +
                 t.h.toFixed(0) + ' m' + (t.y ? ' &middot; ' + t.y : '') +
                 '</li>'; }).join('')
      : '<li>nothing named in this direction</li>';

    document.getElementById('az').textContent =
      'bearing ' + Math.round(((S.az % 360) + 360) % 360) + '°  ' +
      '·  ' + S.fov + '° wide';
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch];
    });
  }

  function what() {
    document.getElementById('what').innerHTML =
      'Forty bars across the view. Each is the tallest building angle in its '
      + 'slice of the horizon, and each drives one partial: position sets '
      + 'pitch along a pentatonic ladder four octaves tall, apparent height '
      + 'sets loudness. The root, <b>' + rootHz.toFixed(1) + ' Hz</b>, comes '
      + 'from this city&rsquo;s median tower height. Turn towards the towers '
      + 'and it fills out; turn away and it empties.';
  }

  /* ------------------------------------------------------------ events -- */
  var drag = null;
  canvas.addEventListener('pointerdown', function (e) {
    drag = { x: e.clientX, az: S.az };
    canvas.setPointerCapture(e.pointerId);
  });
  canvas.addEventListener('pointermove', function (e) {
    if (drag) {
      var r = canvas.getBoundingClientRect();
      S.az = drag.az - (e.clientX - drag.x) / r.width * S.fov;
      refresh();
      return;
    }
    hover(e);
  });
  canvas.addEventListener('pointerup', function () { drag = null; });
  canvas.addEventListener('pointerleave', function () {
    drag = null; tip.style.display = 'none';
  });

  function hover(e) {
    var r = canvas.getBoundingClientRect();
    var f = (e.clientX - r.left) / r.width;
    var az = S.az - S.fov / 2 + f * S.fov;
    var c = C[S.i];
    var near = null, best = 3.0;
    c.towers.forEach(function (t) {
      var off = Math.abs(((t.az - az + 540) % 360) - 180);
      if (off < best) { best = off; near = t; }
    });
    if (!near) { tip.style.display = 'none'; return; }
    tip.innerHTML = '<b>' + esc(near.n) + '</b> &middot; ' +
                    near.h.toFixed(0) + ' m';
    tip.style.display = 'block';
    tip.style.left = Math.min(r.width - tip.offsetWidth - 8,
                              Math.max(4, e.clientX - r.left + 12)) + 'px';
    tip.style.top = Math.max(4, e.clientY - r.top - 34) + 'px';
  }

  window.addEventListener('keydown', function (e) {
    if (e.target.tagName === 'SELECT' || e.target.tagName === 'INPUT') return;
    var step = e.shiftKey ? 15 : 3;
    if (e.key === 'ArrowLeft') S.az -= step;
    else if (e.key === 'ArrowRight') S.az += step;
    else return;
    e.preventDefault();
    refresh();
  });

  document.getElementById('city').addEventListener('change', function () {
    S.i = +this.value;
    S.az = C[S.i].look;          // start facing the way the viewpoint faces
    setRoot(); what(); refresh();
  });
  document.getElementById('fov').addEventListener('input', function () {
    S.fov = +this.value; refresh();
  });
  document.getElementById('vol').addEventListener('input', function () {
    S.vol = +this.value / 100; pushAudio();
  });

  var playBtn = document.getElementById('play');
  playBtn.addEventListener('click', function () {
    if (!S.playing) {
      if (!buildAudio()) return;
      // browsers require a gesture before an audio context may make noise
      if (actx.state === 'suspended') actx.resume();
      S.playing = true;
      playBtn.textContent = 'Stop';
      playBtn.classList.add('on');
    } else {
      S.playing = false;
      playBtn.textContent = 'Play';
      playBtn.classList.remove('on');
    }
    pushAudio();
  });

  function refresh() { draw(); panel(); pushAudio(); }

  var ro = window.ResizeObserver ? new ResizeObserver(resize) : null;
  if (ro) ro.observe(document.getElementById('stage'));
  window.addEventListener('resize', resize);

  /* --------------------------------------------------------------- boot -- */
  document.getElementById('city').innerHTML = C.map(function (c, i) {
    return '<option value="' + i + '">' + esc(c.city) + ' &middot; ' +
           esc(c.country) + '</option>';
  }).join('');
  S.az = C[0].look;
  setRoot(); what();
  resize();
  panel();

  window.__sky = {
    S: S, cities: C, bars: bars, peak: peak, freqOf: freqOf,
    setRoot: setRoot, root: function () { return rootHz; }, refresh: refresh
  };
})();
