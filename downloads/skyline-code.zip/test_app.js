/* Checks on the built app.
 *
 * The one that matters is the last one, and it exists because the previous
 * version of this file did not have it. It counted the rectangles the wheel
 * drew, found four hundred and thirty-two of them, and reported everything
 * fine while the panel was blank in a browser - because every rectangle was
 * less than a pixel tall. Drawing something and drawing something visible are
 * different claims, and only one of them was being tested.
 *
 * Run:  node test_app.js
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { JSDOM, VirtualConsole } = require('jsdom');

const PAGE = path.join(__dirname, 'skyline-app.html');
let fails = 0, checks = 0;
function ok(cond, label, detail) {
  checks++;
  console.log((cond ? '  ok    ' : '  FAIL  ') + label +
              (detail ? '   ' + detail : ''));
  if (!cond) fails++;
}

const VW = 1400, VH = 900;
let rects = [];
function stub() {
  return { clearRect() {}, strokeStyle: '', lineWidth: 0, globalAlpha: 1,
    fillStyle: '', font: '', textAlign: '', beginPath() {}, moveTo() {},
    lineTo() {}, stroke() {},
    createLinearGradient: () => ({ addColorStop() {} }),
    fillRect(x, y, w, h) { rects.push({ x, y, w, h }); },
    fillText() {}, measureText: () => ({ width: 40 }) };
}

const errs = [];
const vc = new VirtualConsole();
vc.on('jsdomError', e => errs.push(e.message));
const dom = new JSDOM(fs.readFileSync(PAGE, 'utf8'), {
  runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
  beforeParse(w) {
    w.matchMedia = () => ({ matches: false, addEventListener() {} });
    w.requestAnimationFrame = () => 0;
    w.HTMLCanvasElement.prototype.getContext = stub;
    w.HTMLCanvasElement.prototype.getBoundingClientRect =
      () => ({ left: 0, top: 0, width: VW, height: VH,
               right: VW, bottom: VH });
  }
});
const win = dom.window, doc = win.document, K = win.__sky;

console.log('\n  Boot');
ok(errs.length === 0, 'no errors on load', errs[0] || '');
ok(!!K, 'the app exposes its handle');
if (!K) process.exit(1);
win.dispatchEvent(new win.Event('resize'));
/* Not fifty. Fifty was the ask and the database will not support it: only
   this many cities have enough buildings on record to fill a wheel, and a
   sparse wheel was the complaint that started this. Publishing the ones that
   work says something true about the data; padding to fifty would say
   something false about the cities. */
ok(K.cities.length >= 20, 'enough cities to be worth browsing',
   K.cities.length + ' published');

console.log('\n  Data');
ok(K.cities.every(c => c.ring && c.ring.length >= 7),
   'every city has a ring');
ok(K.cities.every(c => c.rprof.length === 360 &&
                       c.rprof.every(v => v > 0.001)),
   'no bearing in any city is empty');
ok(K.cities.every(c => c.key && c.key.why), 'every city has a sourced key');
const c0 = K.cities.find(c => c.city === 'New York');
ok(c0.ring.every((r, i, a) => i === 0 || a[i - 1][6] <= r[6]),
   'ring keeps true compass order');
ok(new Set(c0.ring.map((r, i) =>
     +(r[0] - 360 * i / c0.ring.length).toFixed(3))).size === 1,
   'ring spacing is exactly equalised');

console.log('\n  The wheel is actually visible');
/* Split what is drawn into the two panels by where it sits, and require the
   top panel to contain bars of a real size. A panel of hairlines passes a
   count and fails a person. */
let worstTall = 1e9, worstCity = '', worstFill = 1e9, fillCity = '';
let spilled = 0, spillCity = '';
for (let i = 0; i < K.cities.length; i++) {
  K.S.i = i; K.setKey(); K.S.az = 0;
  for (let s = 0; s < 40; s++) K.step(0.016);
  rects = []; K.draw();
  /* The divider, in device pixels. Everything the wheel draws must sit above
     it - that is the check, not a convenience for the filter. The first
     version of this test filtered on it instead of asserting it, and so
     quietly threw away the front half of the wheel and then complained the
     wheel was short. */
  /* Read the canvas rather than assuming the device pixel ratio. Hard-coding
     a factor of two made the panel look twice its real height and reported
     every wheel as a third too short - a measurement bug wearing a drawing
     bug's clothes, for the second time in this file. */
  const split = Math.round(doc.getElementById('c').height * 0.56);
  const top = rects.filter(r => r.y < split && r.h > 1.5);
  const spill = top.filter(r => r.y + r.h > split + 2).length;
  if (spill) { spilled += spill; spillCity = K.cities[i].city; }
  const tallest = top.reduce((m, r) => Math.max(m, r.h), 0);
  const frac = tallest / split;
  if (frac < worstTall) { worstTall = frac; worstCity = K.cities[i].city; }
  // and the wheel must be populated, not one lonely spike
  const solid = top.filter(r => r.h > tallest * 0.08).length;
  if (solid < worstFill) { worstFill = solid; fillCity = K.cities[i].city; }
}
ok(worstTall > 0.35,
   'in every city the tallest tower fills a good part of the panel',
   `worst ${(worstTall * 100).toFixed(0)}% (${worstCity})`);
ok(worstFill >= 12, 'and the wheel is populated, not one lonely spike',
   `worst ${worstFill} visible towers (${fillCity})`);
ok(spilled === 0, 'and no part of it hangs down over the meter',
   spilled ? `${spilled} bars spill in ${spillCity}` : '');

console.log('\n  The meter');
K.S.i = 0; K.setKey();
let minSum = 1e9;
for (let az = 0; az < 360; az += 10) {
  K.S.az = az;
  for (let s = 0; s < 40; s++) K.step(0.016);
  minSum = Math.min(minSum, [...K.levels()].reduce((a, v) => a + v, 0));
}
ok(minSum > 1, 'no bearing leaves the meter silent',
   `quietest total ${minSum.toFixed(1)}`);

console.log('\n  The sidebar describes the wheel');
K.S.i = 0; K.S.az = 0; K.panel();
const stats = doc.getElementById('stats').textContent;
ok(/On the wheel/.test(stats) && /Standing/.test(stats),
   'stats mention the ring and where you stand');
ok(!/Viewpoint/.test(stats), 'and no longer the retired panorama viewpoint');
const li = doc.querySelectorAll('#towers li');
ok(li.length > 20, 'the tower list is the wheel, not twenty',
   li.length + ' rows');
ok(doc.querySelectorAll('#towers li.in').length < li.length,
   'and marks which of them are behind you');

console.log(`\n  ${checks - fails}/${checks} checks passed` +
            (fails ? `, ${fails} FAILED` : ''));
process.exit(fails ? 1 : 0);
