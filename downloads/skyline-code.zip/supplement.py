"""
Hand-entered buildings for cities the reference database barely covers.

Wikidata has three buildings on record for Austin and fourteen for Nashville.
Austin has something over forty above a hundred metres. That gap is not about
the cities; it is about who has been entering data, and English-language
coverage of mid-size American downtowns is thin in a way that coverage of
Manhattan is not.

So these two are supplemented by hand, and the supplement is kept in its own
file, tagged in the output, and named on the page. Heights are structural, from
published records. Coordinates are block-level rather than surveyed, which is a
real limitation and a small one here: the wheel equalises angular spacing
anyway, so what a coordinate decides is the order buildings appear in, not the
gap between them.

Any city listed here is marked "supplemented" in the app. Nothing in the main
set is touched.
"""

# name, height in metres, lat, lon, year
AUSTIN = [
    ("Waterline",                  320.0, 30.2601, -97.7381, 2026),
    ("Sixth and Guadalupe",        265.0, 30.2695, -97.7461, 2023),
    ("The Independent",            208.5, 30.2707, -97.7513, 2019),
    ("The Austonian",              208.0, 30.2668, -97.7443, 2010),
    ("Indeed Tower",               195.0, 30.2688, -97.7457, 2021),
    ("Google Tower (Block 185)",   191.0, 30.2637, -97.7440, 2022),
    ("Fairmont Austin",            180.0, 30.2625, -97.7395, 2017),
    ("44 East Avenue",             172.0, 30.2585, -97.7392, 2022),
    ("Frost Bank Tower",           157.9, 30.2686, -97.7430, 2004),
    ("The Quincy",                 152.0, 30.2705, -97.7440, 2022),
    ("70 Rainey",                  152.0, 30.2588, -97.7387, 2018),
    ("Natiivo Austin",             141.0, 30.2622, -97.7386, 2023),
    ("Northshore Austin",          134.0, 30.2660, -97.7480, 2016),
    ("100 Congress",               125.0, 30.2645, -97.7430, 1987),
    ("Colorado Tower",             122.0, 30.2678, -97.7452, 2015),
    ("One Eleven Congress",        120.0, 30.2650, -97.7434, 1987),
    ("Seaholm Residences",         118.0, 30.2650, -97.7513, 2015),
    ("Ashton Austin",              117.0, 30.2660, -97.7466, 2009),
    ("Third + Shoal",              105.0, 30.2673, -97.7482, 2019),
    ("W Austin Hotel",             102.0, 30.2655, -97.7477, 2010),
    ("Spring Condominiums",         92.0, 30.2683, -97.7495, 2009),
    ("The Monarch",                 90.0, 30.2718, -97.7442, 2007),
]

NASHVILLE = [
    ("Nashville Yards Tower 1",    228.6, 36.1600, -86.7869, 2025),
    ("AT&T Building",              188.4, 36.1600, -86.7768, 1994),
    ("Four Seasons Nashville",     168.0, 36.1560, -86.7742, 2022),
    ("505 Nashville",              164.0, 36.1592, -86.7802, 2018),
    ("Pinnacle at Symphony Place", 151.0, 36.1585, -86.7745, 2010),
    ("JW Marriott Nashville",      148.0, 36.1552, -86.7787, 2018),
    ("William R. Snodgrass Tower", 138.0, 36.1651, -86.7833, 1970),
    ("1010 Church",                136.0, 36.1618, -86.7845, 2023),
    ("Fifth Third Center",         131.0, 36.1621, -86.7791, 1986),
    ("UBS Tower",                  128.0, 36.1631, -86.7797, 1974),
    ("Regions Center",             126.0, 36.1637, -86.7783, 1974),
    ("SoBro / The Grand Hyatt",    124.0, 36.1547, -86.7853, 2020),
    ("Life & Casualty Tower",      124.0, 36.1614, -86.7773, 1957),
    ("Bridgestone Tower",          113.0, 36.1585, -86.7810, 2017),
    ("505 Church",                 110.0, 36.1625, -86.7826, 2018),
    ("Renaissance Nashville",      110.0, 36.1634, -86.7815, 1987),
    ("Broadwest Residences",       108.0, 36.1533, -86.7930, 2021),
    ("The Adelicia",               102.0, 36.1494, -86.7942, 2007),
    ("Viridian",                    98.0, 36.1638, -86.7803, 2006),
    ("Encore",                      95.0, 36.1568, -86.7746, 2008),
    ("Terrazzo",                    92.0, 36.1524, -86.7911, 2009),
    ("Icon in the Gulch",           88.0, 36.1520, -86.7897, 2008),
]

SUPPLEMENT = {"Austin": AUSTIN, "Nashville": NASHVILLE}


def rows_for(city):
    """Buildings in the same shape the loader produces, tagged as hand-entered
    so that the output can say so."""
    out = []
    for name, h, lat, lon, year in SUPPLEMENT.get(city, []):
        out.append({"name": name, "h": float(h), "lat": lat, "lon": lon,
                    "year": year, "hand": True})
    return out
