# AGENT.md: apply Perfidy to a project

You are a coding agent that was pointed at this kit to switch a project to **Perfidy**. Perfidy is a free (OFL) family of text, display, mono and semi-mono fonts that share one x-height and line metrics. Every file you need ships in the kit, so there is nothing to download or license.

- **KIT**: the folder this file is in (the root of the perfidy repository).
- **TARGET**: the project the user named. If they named none, use your working directory.

Don't edit anything in KIT. Only copy font files with `perfidykit.py install`, the install scripts, or the steps below.

| Family | Use for | Weights |
|---|---|---|
| Perfidy Text | body text, UI, labels, anything below about 22px | 300–800, italics |
| Perfidy Display | headings at 22px and up (tighter spacing) | 300–800, italics |
| Perfidy Mono | code, keys, fixed-grid readouts | 300–700, italics |
| Perfidy SemiMono | optional "instrument/terminal" voice for data UIs | 300–800, italics |
| Fira Math | math (MathML, KaTeX fallback, LaTeX operators) | 400 |

All families share a 0.50 em x-height and the same line metrics, so they mix inline cleanly. `line-height: normal` comes out at 1.25.

## 1. Identify the kind of project

- **Web UI** (HTML/CSS, WebView2, Electron, Lively wallpaper, Flask templates, Vite/React): follow steps 2–6.
- **LaTeX** (`.tex`): see the LaTeX section.
- **WPF / WinForms / tkinter / other desktop apps**: see the desktop section.

## 2. Audit (web)

```
python KIT/tools/perfidykit.py audit TARGET --out TARGET/perfidy-audit.md
```

The report has five sections:

1. Font-stack variables. These are the remap points.
2. Literal declarations.
3. Usage sites of each variable.
4. Old font loading (`@font-face`, Google Fonts).
5. Math libraries, canvas text, JS styles and desktop fonts.

If you can run the UI, take a **before** screenshot.

## 3. Map roles (default; apply without asking unless the user said otherwise)

| Project has | Becomes |
|---|---|
| body/UI sans or serif stack (`--font`, `--sans`, `--ui`, `--serif`, `--body`) | `var(--perfidy-text)` |
| heading/display stack used at 22px and up (`--font-display`, `--head`, `--serif-display`) | `var(--perfidy-display)` |
| display-named stack mostly used small | `var(--perfidy-text)` |
| monospace (`Consolas`, `--mono`, code, kbd) | `var(--perfidy-mono)` |
| timers, scores, prices, table columns | keep the role, add `font-variant-numeric: tabular-nums` |
| icon fonts | never touch |
| decorative one-offs (blackletter masthead, Impact logo) | leave them, and list them in the report |

For weights: 100 and 200 → 300, 900 → 800. For Mono, 800 → 700.

## 4. Install and wire in

```
python KIT/tools/perfidykit.py install TARGET --dest DEST [--roles text,display,mono] [--weights 300-700] [--font-display block] [--math] [--katex]
```

- `DEST` is the folder the UI serves static files from. It is `ui` when the server maps `/` to `ui/`, `.` when `index.html` is at the project root, and `public` for Vite.
- Ship only what the project uses: get the roles from step 3 and the weights from the CSS.
- Use `--font-display block` for local desktop UIs (WebView2, Lively, Electron), and the default `swap` for websites.
- Add `--math` if the project shows MathML, `--katex` if it uses KaTeX, and `--inline` only for pages opened via `file://` without a server.

The install writes `TARGET/DEST/perfidy/{perfidy.css, fonts/, perfidy-katex.css?, perfidy.manifest.json, LICENSE-NOTE.txt, OFL.txt}`. It can be re-run safely.

Then make these changes:

**a)** Load `perfidy/perfidy.css` before the project's CSS, with either `<link rel="stylesheet" href="perfidy/perfidy.css">` or `@import url("perfidy/perfidy.css");` on the first line of the main CSS. Put KaTeX's CSS first, then `perfidy-katex.css`.

**b)** Remap only the variable definitions from audit section 1, e.g. `--font-display: var(--perfidy-display);`. Point the section-2 literals at the project variable, or at a `--perfidy-*` token. Set `body { font-family: var(--perfidy-text); }` if no base font is set.

**c)** Remove the old `@font-face` blocks and font-service links you replaced. Delete the old font files only if nothing else references them.

**d)** Handle the special cases:
- canvas `ctx.font`: use `"Perfidy Text"`, and draw after `await document.fonts.load('16px "Perfidy Text"')`.
- inline JS styles: use `'var(--perfidy-text)'`.
- data-URI SVG favicons: leave them.
- Python servers with a custom `extensions_map`: add `".woff2": "font/woff2"`.

**e)** Tune lightly, based on what the screenshots show:
- Re-check heading `letter-spacing`. Perfidy Display already has tight tracking built in, so remove negative tracking that was compensating for the old font.
- Check fixed-height boxes and `nowrap` titles for overflow.
- Add `tabular-nums` to anything that ticks.

## 5. Math on the web

- **MathML**: the `--math` install adds `math { font-family: var(--perfidy-math) }`. That's Fira Math, scaled to Perfidy's x-height.
- **KaTeX**: install with `--katex` and load `perfidy-katex.css` after `katex.min.css`. Latin letters and digits render in Perfidy and Greek in Fira Math. Big operators and delimiters keep KaTeX's fonts.
- **MathJax 4**: set `output: { font: 'mathjax-fira' }`, which matches Fira Math. Don't override MathJax CSS.

## 6. Verify (required)

1. Run the UI the normal way (README / `run.bat` / `server.py`) and take an **after** screenshot.
2. Run `KIT/tools/perfidy-check.js` in the page. `failed` must be empty. `nonPerfidyText` may list only the deliberate exceptions from step 3.
3. If the fonts don't load:
   - Check that the `perfidy.css` path is correct relative to the HTML.
   - Check that the server serves `DEST/perfidy/fonts/`.
   - For `file://` pages, use `--inline`.
4. Report to the user: the role mapping, what you left alone and why, any layout fixes, and the screenshot paths. Delete `perfidy-audit.md` unless the user wants to keep it.

## LaTeX

Compile with **LuaLaTeX or XeLaTeX**. pdfLaTeX can't load these fonts; switch the engine (on Overleaf: Menu → Compiler).

```latex
% option A: fonts installed via install/install-latex.ps1 (or install-fonts.ps1)
\usepackage{perfidy}

% option B: portable, with no install (Overleaf, or another machine)
%   copy KIT/latex/perfidy.sty next to main.tex, and KIT/fonts/desktop/* into ./fonts/
\def\PerfidyFontPath{fonts/}
\usepackage{perfidy}
```

What the package sets up:
- Main and sans are Perfidy Text, mono is Perfidy Mono (`[semimono]` switches it), and math uses Fira Math with Latin letters and digits from Perfidy Text.
- Weight commands: `\textlight`, `\textmedium`, `\textsemibold`, `\textextrabold` (plus `\lightseries` and friends), and `\textdisplay` / `\perfidydisplay` for headings.
- `{\perfidytnum 1,250.00}` gives tabular figures.
- Use `\symbf` / `\symbfit` for bold math. `\boldsymbol` and `\mathbf` still work but are the legacy forms.

When converting an existing document:
- Remove other font packages (`lmodern`, `mathpazo`, `newtx*`, `libertine`, `fourier`), plus `fontenc` and `inputenc`, which aren't needed under LuaLaTeX/XeLaTeX.
- Keep `amsmath`, and load `perfidy` after it.
- Compile, and check the log for `Missing character`.

## Desktop apps

- **Install for the user**: `powershell -ExecutionPolicy Bypass -File KIT/install/install-fonts.ps1`. The families then appear by name (`Perfidy Text`, ...) in any app.
- **WPF (embedded)**: copy the needed `KIT/fonts/desktop/*.ttf` into `Fonts/Perfidy/`, add `<Resource Include="Fonts\Perfidy\*.ttf" />`, and reference them as `pack://application:,,,/Fonts/Perfidy/#Perfidy Text`. Regular, Italic, Bold and Bold Italic share the family `Perfidy Text`. Other weights are separate legacy families: `Perfidy Text Medium`, `Perfidy Text SemiBold`, `Perfidy Text Light`, `Perfidy Text ExtraBold`.
- **tkinter**: call `ctypes.windll.gdi32.AddFontResourceExW(path, 0x10, 0)` for each needed .ttf at startup, then use `("Perfidy Text", 11)`.

## License

All fonts are under the SIL Open Font License 1.1, so they're free to use, embed and redistribute, including on public websites and in public repos. Keep `OFL.txt` / `LICENSE-NOTE.txt` next to the font files. Don't sell the fonts on their own.
