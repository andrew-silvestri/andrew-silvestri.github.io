# Perfidy

Perfidy is a family of 46 fonts in four related families, released under the SIL Open Font License. Each family is built from an existing open-source typeface, and the four are recalibrated to share one set of proportions. They share an x-height (0.50 em) and line metrics, and their weights are spaced on one scale of stroke thickness, so text, code and figures can be mixed in the same line. LaTeX and web math setups are included.

![specimen](specimen/specimen.png)

| Family | Built from | Styles |
|---|---|---|
| Perfidy Text | Merriweather Sans and Merriweather Sans Italic (Sorkin Type) | Light to ExtraBold (300–800), with italics |
| Perfidy Display | the same sources, set tighter for large sizes | Light to ExtraBold, with italics |
| Perfidy SemiMono | iA Writer Quattro (Information Architects, based on IBM Plex) | Light to ExtraBold, with italics |
| Perfidy Mono | IBM Plex Mono (IBM) | Light to Bold (300–700), with italics |
| Fira Math | Fira Math (Xiangdong Zeng), included unmodified | Regular |

Every style ships as `.ttf` in `fonts/desktop/` for desktop apps and LaTeX, and as `.woff2` in `fonts/web/` for the web.

## What was changed

The letterforms are the source typefaces' own. Four things were changed:

1. **Weight.** Each style is an instance of the source's variable font, taken at the weight-axis value where the vertical stem of *n* reaches a target thickness. The targets run from 0.110 of the x-height (Light) to 0.310 (ExtraBold), in near-equal steps. Merriweather Sans' thinnest master is heavier than the Light target, so Perfidy Text and Display Light were extrapolated linearly past the end of the axis (to weight 240 on a 300–800 axis). SemiMono Light and ExtraBold were extrapolated the same way. Plex Mono is not variable and has no ExtraBold, so Perfidy Mono uses its static weights and stops at Bold.
2. **Size.** Each source was scaled uniformly so that its x-height is 0.50 em: Merriweather Sans ×0.900 (from 0.557 em), Quattro ×0.971 and Plex Mono ×0.973 (from 0.516 em).
3. **Spacing.** Each style's advance widths carry its own tracking value, so word widths follow the target. Perfidy Display is set tighter than Perfidy Text in every style, by 0.007 to 0.040 em per letter; the gap is widest at Regular and narrowest at ExtraBold.
4. **Metrics and names.** All families share one set of vertical metrics, so `line-height: normal` is 1.25. Every font was renamed (no Reserved Font Name is used), dehinted, and has its overlapping contours removed.

The target proportions (x-height, stem thickness per weight, word width per style) were measured from the published specimen of Ghost (Sharp Type, 2026). No outline, metric table or file from that typeface is used or included. `build/calibration/` has the measurement scripts and the numbers they produced. Across 34 measured weight-and-style samples, Perfidy's stem thickness is within 0.002 of the x-height of the target (median), and its word widths are within 0.9% (median; mean 2.5%).

## Install

Windows, for desktop apps (current user, no admin needed):
```
powershell -ExecutionPolicy Bypass -File install\install-fonts.ps1
```
On macOS or Linux, open the files in `fonts/desktop/` with the system font manager.

**Web.** Copy the `.woff2` files you need and use `css/perfidy.css`, or generate a subset with the URL prefix you need:
```
python tools/perfidykit.py css --prefix /fonts/ --roles text,mono --weights 400,700
python tools/perfidykit.py install path/to/project --dest public --math --katex
```
`perfidykit.py` uses only the Python standard library. `tools/perfidykit.py audit <project>` lists every font declaration in a project, as a starting point for switching it over. `AGENT.md` is a step-by-step procedure for a coding agent doing the same.

**LaTeX** (LuaLaTeX or XeLaTeX). To install into MiKTeX or TeX Live:
```
powershell -ExecutionPolicy Bypass -File install\install-latex.ps1
```
Then, in the document preamble:
```latex
\usepackage{amsmath}
\usepackage{perfidy}      % options: nomath, semimono
```
Without installing anything, put `perfidy.sty` beside the document, put the fonts in `fonts/`, and write `\def\PerfidyFontPath{fonts/}` before `\usepackage{perfidy}`.

Math is set in Fira Math, with Latin letters and digits taken from Perfidy Text, so the variables in an equation match the text around them. See [latex/perfidy-example.pdf](latex/perfidy-example.pdf). pdfLaTeX cannot load these fonts.

**Math on the web.** For MathML, `perfidy.css` sets `math { font-family: "Fira Math" }`, scaled to the 0.50 em x-height. For KaTeX, load `css/perfidy-katex.css` after `katex.min.css`. For MathJax 4, set `output: { font: 'mathjax-fira' }`.

## Features

- OpenType features in Perfidy Text and Display: tabular and oldstyle figures, fractions, superiors and inferiors, ordinals, small caps, slashed zero and case-sensitive forms.
- Character coverage:
  - Perfidy Text: 767 characters, Latin including Vietnamese. No Cyrillic. The only Greek letters are Δ, Ω, δ, μ, π and ω, the ones used as symbols.
  - Perfidy Mono: 930 characters, adding Cyrillic.
  - Perfidy SemiMono: 1,053 characters, adding Cyrillic and Greek.

## Limits

- The calibration changed weight, size and spacing, not the shape of any letter.
- Perfidy Display is Perfidy Text with tighter tracking. It has no separately drawn optical size.
- The extrapolated weights (Text, Display and SemiMono Light; SemiMono ExtraBold) lie outside what the source designers drew. They render cleanly at the sizes checked, but no designer reviewed them.
- The italic angle is the source's own, 7.5°.
- The fonts are dehinted, so very small sizes on Windows rely on antialiasing.
- These are static fonts. There is no variable-font build.

## Rebuild

```
python build/fetch_sources.py
python build/build_perfidy.py
```
The output is byte-identical to the shipped fonts in the glyf, hmtx, GPOS, GSUB and cmap tables. `build/plan.json` holds every axis value, scale and tracking value. The build needs `fonttools` and `skia-pathops`.

## License

SIL Open Font License 1.1 (`OFL.txt`). Perfidy is a Modified Version of the fonts listed above. Their copyright notices are kept in `OFL.txt`, in `licenses/`, and in each font's name table. `licenses/FONTLOG.md` lists every modification. The tools, CSS and LaTeX package are under the same license. Perfidy is not affiliated with Sharp Type, Sorkin Type, Information Architects or IBM.
