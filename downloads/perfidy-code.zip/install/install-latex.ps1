<#
  Make \usepackage{perfidy} work in every LaTeX document on this machine (MiKTeX or TeX Live).
  Builds a TDS tree at perfidy\latex\texmf, then:
    MiKTeX   -> registers it as a user root (initexmf --register-root) and refreshes the file name database
    TeX Live -> copies it into TEXMFHOME and refreshes luaotfload's font database

    powershell -ExecutionPolicy Bypass -File install\install-latex.ps1
    powershell -ExecutionPolicy Bypass -File install\install-latex.ps1 -Uninstall

  Without installing: put perfidy.sty next to your .tex file and write
    \def\PerfidyFontPath{C:/Users/<you>/Code/perfidy/fonts/desktop/}   before \usepackage{perfidy}.
  Compile with lualatex or xelatex (pdflatex cannot load these fonts).
#>
param([switch]$Uninstall)
$ErrorActionPreference = 'Stop'

$kit  = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$tree = Join-Path $kit 'latex\texmf'

function Build-Tree {
  $sty = Join-Path $tree 'tex\latex\perfidy'
  $ttf = Join-Path $tree 'fonts\truetype\perfidy'
  $otf = Join-Path $tree 'fonts\opentype\perfidy'
  foreach ($d in @($sty, $ttf, $otf)) { New-Item -ItemType Directory -Force -Path $d | Out-Null }
  Copy-Item (Join-Path $kit 'latex\perfidy.sty') $sty -Force
  Copy-Item (Join-Path $kit 'fonts\desktop\*.ttf') $ttf -Force
  Copy-Item (Join-Path $kit 'fonts\desktop\*.otf') $otf -Force
}

$initexmf = Get-Command initexmf -ErrorAction SilentlyContinue
$kpse     = Get-Command kpsewhich -ErrorAction SilentlyContinue
if (-not $kpse -and -not $initexmf) { throw 'No TeX distribution found on PATH (need MiKTeX or TeX Live).' }

if ($initexmf) {
  # ---------------- MiKTeX
  if ($Uninstall) {
    & initexmf --unregister-root="$tree" 2>$null
    & initexmf --update-fndb | Out-Null
    Write-Host 'Unregistered Perfidy root from MiKTeX.'
    return
  }
  Build-Tree
  & initexmf --register-root="$tree"
  & initexmf --update-fndb | Out-Null
  $lot = Get-Command luaotfload-tool -ErrorAction SilentlyContinue
  if ($lot) { & luaotfload-tool --update | Out-Null }
  Write-Host "MiKTeX: registered $tree"
} else {
  # ---------------- TeX Live
  $home_tex = (& kpsewhich -var-value TEXMFHOME).Trim()
  if (-not $home_tex) { $home_tex = Join-Path $env:USERPROFILE 'texmf' }
  $parts = @('tex\latex\perfidy', 'fonts\truetype\perfidy', 'fonts\opentype\perfidy')
  if ($Uninstall) {
    foreach ($p in $parts) { Remove-Item (Join-Path $home_tex $p) -Recurse -Force -ErrorAction SilentlyContinue }
    Write-Host "Removed Perfidy from $home_tex"
    return
  }
  Build-Tree
  foreach ($p in $parts) {
    $to = Join-Path $home_tex $p
    New-Item -ItemType Directory -Force -Path $to | Out-Null
    Copy-Item (Join-Path (Join-Path $tree $p) '*') $to -Force
  }
  $lot = Get-Command luaotfload-tool -ErrorAction SilentlyContinue
  if ($lot) { & luaotfload-tool --update | Out-Null }
  Write-Host "TeX Live: installed into $home_tex"
}
Write-Host 'Test: cd latex; lualatex perfidy-example.tex  (remove the \def\PerfidyFontPath line first)'
