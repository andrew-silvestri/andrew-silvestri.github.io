<#
  Install Perfidy (+ Fira Math) for the current Windows user. No admin rights needed.
  Afterwards the fonts show up in Word, Figma, WPF apps, LaTeX (XeLaTeX), etc.

    powershell -ExecutionPolicy Bypass -File install\install-fonts.ps1
    powershell -ExecutionPolicy Bypass -File install\install-fonts.ps1 -Uninstall

  If a font is "in use" during reinstall, run with -Uninstall, sign out and back in, then install again.
#>
param([switch]$Uninstall)
$ErrorActionPreference = 'Stop'

$src  = (Resolve-Path (Join-Path $PSScriptRoot '..\fonts\desktop')).Path
$dest = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
$reg  = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }

if (-not ('PerfidyInstall.Gdi' -as [type])) {
  Add-Type -Namespace PerfidyInstall -Name Gdi -MemberDefinition @'
[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceW(string file);
[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern bool RemoveFontResourceW(string file);
[DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern IntPtr SendMessageTimeoutW(IntPtr hWnd, uint Msg, UIntPtr wParam, IntPtr lParam, uint flags, uint timeout, out UIntPtr result);
'@
}

$files = Get-ChildItem -Path $src -File | Where-Object { $_.Extension -in @('.ttf', '.otf') }
$done = 0
foreach ($f in $files) {
  $target = Join-Path $dest $f.Name
  $kind = if ($f.Extension -eq '.otf') { 'OpenType' } else { 'TrueType' }
  $valueName = "$($f.BaseName) ($kind)"
  if ($Uninstall) {
    [void][PerfidyInstall.Gdi]::RemoveFontResourceW($target)
    Remove-ItemProperty -Path $reg -Name $valueName -ErrorAction SilentlyContinue
    Remove-Item -Path $target -Force -ErrorAction SilentlyContinue
  } else {
    try {
      Copy-Item -Path $f.FullName -Destination $target -Force
    } catch {
      Write-Warning "$($f.Name) is in use; skipped (uninstall, sign out/in, reinstall to update it)."
      continue
    }
    New-ItemProperty -Path $reg -Name $valueName -Value $target -PropertyType String -Force | Out-Null
    [void][PerfidyInstall.Gdi]::AddFontResourceW($target)
  }
  $done++
}
# WM_FONTCHANGE so running apps notice
$out = [UIntPtr]::Zero
[void][PerfidyInstall.Gdi]::SendMessageTimeoutW([IntPtr]0xffff, 0x001D, [UIntPtr]::Zero, [IntPtr]::Zero, 2, 1000, [ref]$out)

if ($Uninstall) { Write-Host "Removed $done font files." }
else { Write-Host "Installed $done font files to $dest (current user). Restart apps that were open." }
