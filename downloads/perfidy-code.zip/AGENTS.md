This folder is the Perfidy font kit, not an app. Follow AGENT.md.
