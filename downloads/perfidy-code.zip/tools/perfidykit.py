#!/usr/bin/env python3
"""
perfidykit - put the Perfidy fonts into a UI project.  Pure standard library (Python 3.8+).

  audit   <project> [--out F]          report every font declaration in the project (markdown)
  install <project> --dest DIR [opts]  copy the needed .woff2 files + a generated perfidy.css into
                                       <project>/<DIR>/perfidy/
  css     [--prefix P] [opts]          print a perfidy.css for any font URL prefix

install / css options:
  --roles text,display,mono,semimono   default: text,display,mono
  --weights 300-800 | 400,500,700      default: all available
  --no-italics                         skip italic faces
  --math                               add Fira Math + MathML rule
  --katex                              also write perfidy-katex.css (implies --math is not needed)
  --inline                             embed fonts as data: URIs (pages opened via file://)
  --font-display swap|block|...        default swap; use block for local desktop UIs
"""
from __future__ import annotations
import argparse, base64, datetime as _dt, json, os, re, shutil, sys
from collections import defaultdict
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
WEB = KIT / "fonts" / "web"
ROLES = {  # role -> (css family, file stem)
    "text": ("Perfidy Text", "PerfidyText"),
    "display": ("Perfidy Display", "PerfidyDisplay"),
    "mono": ("Perfidy Mono", "PerfidyMono"),
    "semimono": ("Perfidy SemiMono", "PerfidySemiMono"),
}
STYLE_W = {"Light": 300, "Regular": 400, "Medium": 500, "SemiBold": 600, "Bold": 700, "ExtraBold": 800}
SANS_FB = '"Segoe UI Variable Text", "Segoe UI", system-ui, -apple-system, "Helvetica Neue", Arial, sans-serif'
MONO_FB = 'ui-monospace, "Cascadia Mono", Consolas, "SF Mono", Menlo, monospace'
MATH_FB = 'math, "Cambria Math", "STIX Two Math", serif'
FIRA_MATH_SIZE_ADJUST = "94.9%"   # Fira Math x-height 0.527 em -> Perfidy 0.50 em


def faces():
    """Yield (role, weight, italic, filename) for every shipped Perfidy woff2."""
    out = []
    for f in sorted(WEB.glob("Perfidy*.woff2")):
        m = re.match(r"Perfidy(Text|Display|Mono|SemiMono)-(\w+?)(Italic)?\.woff2$", f.name)
        if not m:
            continue
        role = m.group(1).lower()
        style = m.group(2) or "Regular"
        if style == "" or style == "Italic":
            style = "Regular"
        italic = bool(m.group(3)) or f.name.endswith("-Italic.woff2")
        if f.name.endswith("-Italic.woff2"):
            style = "Regular"
        out.append((role, STYLE_W[style], italic, f.name))
    return out


def _weights(spec):
    if not spec:
        return None
    s = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = (int(x) for x in part.split("-"))
            s.update(range(a, b + 1, 100))
        elif part:
            s.add(int(part))
    return s


def select(roles, weights, italics):
    return [f for f in faces() if f[0] in roles and (not weights or f[1] in weights) and (italics or not f[2])]


def _src(fname, prefix, inline):
    if inline:
        data = base64.b64encode((WEB / fname).read_bytes()).decode()
        return f'url("data:font/woff2;base64,{data}") format("woff2")'
    return f'url("{prefix}{fname}") format("woff2")'


def build_css(roles, weights, italics, prefix="fonts/", math=False, inline=False, font_display="swap"):
    sel = select(roles, weights, italics)
    L = [f"/* perfidy.css - generated {_dt.date.today().isoformat()} by perfidy/tools/perfidykit.py",
         "   Perfidy: OFL-1.1 fonts derived from Merriweather Sans, iA Writer Quattro and IBM Plex Mono (see licenses/).",
         "   Regenerate instead of hand-editing. */", ""]
    for role, w, it, fname in sel:
        L += ["@font-face {", f'  font-family: "{ROLES[role][0]}";', f"  src: {_src(fname, prefix, inline)};",
              f"  font-weight: {w};", f"  font-style: {'italic' if it else 'normal'};", f"  font-display: {font_display};", "}"]
    if math:
        L += ["@font-face {", '  font-family: "Fira Math";', f"  src: {_src('FiraMath-Regular.woff2', prefix, inline)};",
              "  font-weight: 400;", "  font-style: normal;", f"  size-adjust: {FIRA_MATH_SIZE_ADJUST};",
              f"  font-display: {font_display};", "}"]
    present = {r for r, *_ in sel}
    L += ["", ":root {"]
    def stack(role, chain, fb):
        fams = [f'"{ROLES[r][0]}"' for r in chain if r in present]
        return ", ".join(fams + [fb])
    L.append(f"  --perfidy-text: {stack('text', ['text', 'display'], SANS_FB)};")
    L.append(f"  --perfidy-display: {stack('display', ['display', 'text'], SANS_FB)};")
    L.append(f"  --perfidy-mono: {stack('mono', ['mono', 'semimono'], MONO_FB)};")
    L.append(f"  --perfidy-semimono: {stack('semimono', ['semimono', 'mono'], MONO_FB)};")
    if math:
        L.append(f'  --perfidy-math: "Fira Math", {MATH_FB};')
    L += ["}", ""]
    if math:
        L += ["/* Native MathML (Chromium 109+, Firefox, Safari) */", "math { font-family: var(--perfidy-math); }", ""]
    L += ["/* Opt-in helpers */",
          ".perfidy-text { font-family: var(--perfidy-text); }",
          ".perfidy-display { font-family: var(--perfidy-display); }",
          ".perfidy-mono { font-family: var(--perfidy-mono); }",
          ".perfidy-semimono { font-family: var(--perfidy-semimono); }",
          ".perfidy-tnum { font-variant-numeric: tabular-nums; }",
          ".perfidy-onum { font-variant-numeric: oldstyle-nums; }",
          ".perfidy-frac { font-variant-numeric: diagonal-fractions; }",
          ".perfidy-ordn { font-variant-numeric: ordinal; }",
          ".perfidy-zero { font-variant-numeric: slashed-zero; }",
          ".perfidy-smcp { font-variant-caps: small-caps; }",
          ".perfidy-sups { font-variant-position: super; }",
          ".perfidy-subs { font-variant-position: sub; }",
          ".perfidy-case { font-feature-settings: \"case\"; }", ""]
    return "\n".join(L), sel


KATEX_CSS = """/* perfidy-katex.css - load AFTER katex.min.css (and after perfidy.css, which must include --math).
   Latin letters and digits come from Perfidy Text; Greek and symbols Perfidy lacks fall through to Fira Math;
   big operators and stretchy delimiters keep KaTeX's own size fonts, whose metrics drive the layout. */
.katex { font-family: "Perfidy Text", "Fira Math", KaTeX_Main, "Times New Roman", serif; }
.katex .mathnormal, .katex .mathit { font-family: "Perfidy Text", "Fira Math", KaTeX_Math; font-style: italic; }
.katex .boldsymbol { font-family: "Perfidy Text", "Fira Math", KaTeX_Math; font-weight: 700; font-style: italic; }
.katex .mathbf, .katex .textbf { font-family: "Perfidy Text", "Fira Math", KaTeX_Main; font-weight: 700; }
.katex .mathrm, .katex .textrm, .katex .mathsf, .katex .textsf { font-family: "Perfidy Text", "Fira Math", KaTeX_Main; }
.katex .mathtt, .katex .texttt { font-family: "Perfidy Mono", KaTeX_Typewriter; }
"""


def cmd_css(a):
    css, _ = build_css(a.roles.split(","), _weights(a.weights), not a.no_italics, a.prefix, a.math, a.inline, a.font_display)
    sys.stdout.write(css)
    return 0


def cmd_install(a):
    target = Path(a.target).resolve()
    if not target.is_dir():
        sys.exit(f"target not found: {target}")
    roles = a.roles.split(",")
    bad = set(roles) - set(ROLES)
    if bad:
        sys.exit(f"unknown role(s) {bad}; valid: {', '.join(ROLES)}")
    math = a.math or a.katex
    css, sel = build_css(roles, _weights(a.weights), not a.no_italics, "fonts/", math, a.inline, a.font_display)
    out = target / a.dest / "perfidy"
    fonts = out / "fonts"
    if a.dry_run:
        print(f"[dry-run] {len(sel)} faces -> {out}")
        return 0
    out.mkdir(parents=True, exist_ok=True)
    if fonts.exists() and (fonts / ".perfidykit").exists():
        shutil.rmtree(fonts)
    if not a.inline:
        fonts.mkdir(parents=True, exist_ok=True)
        (fonts / ".perfidykit").write_text("managed by perfidykit; safe to regenerate\n")
        for _, _, _, fname in sel:
            shutil.copy2(WEB / fname, fonts / fname)
        if math:
            shutil.copy2(WEB / "FiraMath-Regular.woff2", fonts / "FiraMath-Regular.woff2")
    (out / "perfidy.css").write_text(css, encoding="utf-8")
    if a.katex:
        (out / "perfidy-katex.css").write_text(KATEX_CSS, encoding="utf-8")
    (out / "LICENSE-NOTE.txt").write_text(
        "Perfidy fonts: SIL Open Font License 1.1. Derived from Merriweather Sans (Sorkin Type),\n"
        "iA Writer Quattro (Information Architects, based on IBM Plex) and IBM Plex Mono (IBM);\n"
        "math: Fira Math (Xiangdong Zeng), unmodified. Full texts: perfidy/licenses/ in the kit.\n")
    shutil.copy2(KIT / "licenses" / "OFL-MerriweatherSans.txt", out / "OFL.txt")
    manifest = {"generated": _dt.datetime.now().isoformat(timespec="seconds"), "kit": str(KIT), "roles": roles,
                "faces": [{"role": r, "weight": w, "italic": i, "file": f} for r, w, i, f in sel], "math": math}
    (out / "perfidy.manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    rel = os.path.relpath(out / "perfidy.css", target).replace("\\", "/")
    print(f"installed {len(sel)} faces{' + Fira Math' if math else ''} -> {rel}" + ("  (inlined)" if a.inline else ""))
    print('next: <link rel="stylesheet" href="perfidy/perfidy.css"> before the project CSS (path relative to the HTML),')
    print("      then point the project's font variables at var(--perfidy-text|display|mono|semimono). See AGENT.md.")
    return 0


# ----------------------------------------------------------------------------- audit
SKIP_DIRS = {"node_modules", ".git", "dist", "build", "bin", "obj", ".venv", "venv", "env", "__pycache__",
             "_backups", ".next", "out", "coverage", "perfidy", "ghost", "_snapshot", "cache", ".cache", "vendor"}
AUDIT_EXTS = {".css", ".scss", ".sass", ".less", ".html", ".htm", ".js", ".mjs", ".jsx", ".ts", ".tsx",
              ".vue", ".svelte", ".xaml", ".cs", ".py", ".json", ".tex", ".sty"}
GENERIC = r"(serif|sans-serif|monospace|system-ui|ui-monospace|ui-sans-serif|cursive|fantasy)"
RE_VARDEF = re.compile(r"(--[\w-]+)\s*:\s*([^;{}]*?(?:" + GENERIC + r"|\"[^\"]+\"|'[^']+')[^;{}]*?)\s*(?:;|$)")
RE_FAMILY = re.compile(r"font-family\s*:\s*([^;}\"']*(?:\"[^\"]*\"|'[^']*'|[^;}\"'])*?)\s*(?:;|}|$)", re.I)
RE_FONT_SHORT = re.compile(r"(?<![-\w])font\s*:\s*([^;}]+)", re.I)
RE_VAR_USE = re.compile(r"var\(\s*(--[\w-]+)")
RE_EXTERNAL = re.compile(r"(fonts\.googleapis\.com|fonts\.gstatic\.com|use\.typekit\.net|fonts\.bunny\.net|@fontsource)")
RE_MATHLIB = re.compile(r"(katex|mathjax|MathJax|<math[\s>])")


def suggest(name, value):
    s = f"{name} {value}".lower()
    if re.search(r"icon|material|awesome|symbols|codicon|segoe (mdl2|fluent)", s):
        return "LEAVE (icon font)"
    if re.search(r"old english|unifraktur|fraktur|blackletter|haettenschweiler|impact|brush|script", s):
        return "LEAVE? (decorative)"
    if re.search(r"mono|consolas|courier|menlo|cascadia|\bcode\b|\bkbd\b", s):
        return "mono"
    if re.search(r"display|head|title|hero|masthead|wordmark|\bh[1-3]\b|banner", s):
        return "display"
    return "text"


def cmd_audit(a):
    target = Path(a.target).resolve()
    vardefs, literals, uses, loaders, other = [], [], defaultdict(list), [], []
    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
        for fn in files:
            p = Path(root) / fn
            ext = p.suffix.lower()
            if ext not in AUDIT_EXTS or ".min." in fn:
                continue
            try:
                if p.stat().st_size > 2_000_000:
                    continue
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            rel = p.relative_to(target).as_posix()
            in_face = False
            for i, line in enumerate(text.splitlines(), 1):
                if len(line) > 3000:
                    continue
                loc = f"{rel}:{i}"
                if RE_MATHLIB.search(line):
                    other.append((loc, "math rendering", line.strip()[:90]))
                if ext in (".tex", ".sty"):
                    if re.search(r"\\(setmainfont|setsansfont|setmonofont|setmathfont|usepackage\{(fontspec|unicode-math|lmodern|mathpazo|fourier|newtx\w*|libertine)\})", line):
                        other.append((loc, "LaTeX font setup", line.strip()[:90]))
                    continue
                if ext in (".cs", ".json", ".xaml", ".py"):
                    for m in re.finditer(r"FontFamily\s*=\s*\"([^\"]+)\"|new\s+FontFamily\(\s*\"([^\"]+)\"|font\s*=\s*\(\s*[\"']([^\"']+)", line):
                        other.append((loc, "desktop font", next(g for g in m.groups() if g)))
                    if not (ext == ".py" and re.search(r"font-family|@font-face", line)):
                        continue
                if re.search(r"@font-face", line, re.I):
                    loaders.append((loc, "@font-face", line.strip()[:100]))
                    in_face = "}" not in line.split("@font-face", 1)[1]
                    continue
                if in_face:
                    if "}" in line:
                        in_face = False
                    continue
                if RE_EXTERNAL.search(line):
                    loaders.append((loc, "external font service", line.strip()[:110]))
                for m in RE_VARDEF.finditer(line):
                    name, val = m.group(1), m.group(2).strip()
                    if (re.search(r"(font|serif|sans|mono|display|head|body|ui|type|clue|black|title|text)", name, re.I)
                            or re.search(GENERIC + r"\s*$", val)) and not re.search(
                            r"#[0-9a-f]{3}\b|#[0-9a-f]{6}\b|rgba?\(|hsla?\(|\d(?:px|rem|em|%)|url\(", val, re.I):
                        vardefs.append((loc, name, val, suggest(name, val)))
                for m in RE_FAMILY.finditer(line):
                    val = m.group(1).strip()
                    if "var(" in val:
                        for v in RE_VAR_USE.findall(val):
                            uses[v].append(loc)
                    elif val and val.lower() not in ("inherit", "initial", "unset", "revert"):
                        literals.append((loc, val[:90], suggest(line, val)))
                for m in RE_FONT_SHORT.finditer(line):
                    val = m.group(1).strip()
                    vs = RE_VAR_USE.findall(val)
                    for v in vs:
                        uses[v].append(loc + " (font shorthand)")
                    if not vs and re.search(GENERIC + r"|\"|'", val):
                        literals.append((loc, "font: " + val[:84], suggest(line, val)))
                if ext in (".js", ".mjs", ".jsx", ".ts", ".tsx", ".html", ".htm", ".vue", ".svelte"):
                    if re.search(r"\.font\s*=\s*[`'\"]", line):
                        other.append((loc, "canvas ctx.font", line.strip()[:100]))
                    for m in re.finditer(r"fontFamily\s*[:=]\s*[`'\"]([^`'\"]+)", line):
                        other.append((loc, "JS fontFamily", m.group(1)[:80]))
    defined = {n for _, n, _, _ in vardefs}
    o = [f"# Font audit: {target.name}", "", f"_{target}_ - {_dt.date.today().isoformat()}", "",
         "## 1. Font-stack variables (primary remap points)", ""]
    if vardefs:
        o += ["| where | variable | current value | suggested Perfidy role | used |", "|---|---|---|---|---|"]
        o += [f"| {l} | `{n}` | `{v}` | {r} | {len(uses.get(n, []))}x |" for l, n, v, r in vardefs]
    else:
        o.append("None - fonts are set literally; see section 2.")
    o += ["", "## 2. Literal font-family / font declarations", ""]
    o += (["| where | value | suggested role |", "|---|---|---|"] + [f"| {l} | `{v}` | {r} |" for l, v, r in literals]) if literals else ["None."]
    o += ["", "## 3. Where each font variable is used", ""]
    o += [f"- `{v}` x{len(l)}{'' if v in defined else '  (defined elsewhere / not a font stack)'}: " + ", ".join(l[:25]) for v, l in sorted(uses.items())] or ["None."]
    o += ["", "## 4. Font loading to replace or remove", ""] + ([f"- {l}  {k}: `{s}`" for l, k, s in loaders] or ["None."])
    o += ["", "## 5. Other (math rendering, LaTeX, canvas, JS, desktop)", ""] + ([f"- {l}  {k}: `{s}`" for l, k, s in other] or ["None."])
    rep = "\n".join(o) + "\n"
    if a.out:
        Path(a.out).write_text(rep, encoding="utf-8"); print(f"wrote {a.out}")
    else:
        if hasattr(sys.stdout, "reconfigure"):
            sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        print(rep)
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="perfidykit", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    au = sub.add_parser("audit"); au.add_argument("target"); au.add_argument("--out")
    def opts(sp):
        sp.add_argument("--roles", default="text,display,mono")
        sp.add_argument("--weights")
        sp.add_argument("--no-italics", action="store_true")
        sp.add_argument("--math", action="store_true")
        sp.add_argument("--katex", action="store_true")
        sp.add_argument("--inline", action="store_true")
        sp.add_argument("--font-display", default="swap", choices=["auto", "block", "swap", "fallback", "optional"])
    i = sub.add_parser("install"); i.add_argument("target"); i.add_argument("--dest", required=True); i.add_argument("--dry-run", action="store_true"); opts(i)
    c = sub.add_parser("css"); c.add_argument("--prefix", default="fonts/"); opts(c)
    a = p.parse_args(argv)
    return {"audit": cmd_audit, "install": cmd_install, "css": cmd_css}[a.cmd](a)


if __name__ == "__main__":
    sys.exit(main())
