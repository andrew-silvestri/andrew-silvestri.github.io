// perfidy-check.js - paste into DevTools (or page.evaluate in Playwright) on a page using perfidy.css.
// Reports which Perfidy faces loaded, which failed, and visible text still rendered in a non-Perfidy font.
(async () => {
  await document.fonts.ready;
  const all = [...document.fonts].filter(f => /perfidy|fira math/i.test(f.family));
  const fmt = f => `${f.family} ${f.weight} ${f.style}`;
  const first = s => s.split(",")[0].trim().replace(/^["']|["']$/g, "");
  const offenders = new Map();
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  while (walker.nextNode()) {
    const t = walker.currentNode;
    if (!t.textContent.trim()) continue;
    const el = t.parentElement;
    if (!el || el.closest("script,style,noscript,svg,math,.katex")) continue;
    const cs = getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden") continue;
    const fam = first(cs.fontFamily);
    if (!/^perfidy/i.test(fam)) {
      const cls = typeof el.className === "string" && el.className.trim() ? "." + el.className.trim().split(/\s+/).join(".") : "";
      const key = `${fam} :: ${el.tagName.toLowerCase()}${cls}`;
      offenders.set(key, (offenders.get(key) || 0) + 1);
    }
  }
  const result = {
    loaded: all.filter(f => f.status === "loaded").map(fmt),
    failed: all.filter(f => f.status === "error").map(fmt),          // must be empty
    unusedOnThisScreen: all.filter(f => f.status === "unloaded").map(fmt),
    nonPerfidyText: Object.fromEntries([...offenders].sort((a, b) => b[1] - a[1])),  // should list only deliberate exceptions
  };
  console.log("[perfidy-check]", result);
  return result;
})();
