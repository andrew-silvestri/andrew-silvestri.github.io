# FONTLOG for Perfidy

## Basic information
Perfidy is a superfamily (Text, Display, SemiMono and Mono) derived from fonts released under the SIL Open Font License 1.1. It was made in 2026 by Andrew Silvestri, with weights, x-height and spacing calibrated to proportions measured from the published specimen of a commercial typeface (Ghost, Sharp Type, 2026). No data or outlines from that typeface are included. Under OFL section 3, the Modified Versions do not use any Reserved Font Name ("Merriweather", "Plex", "iA Writer").

## Sources
| Perfidy family | Source | Copyright |
|---|---|---|
| Perfidy Text, Perfidy Display (roman) | Merriweather Sans [wght] | Copyright 2019 The Merriweather Project Authors, RFN "Merriweather" |
| Perfidy Text, Perfidy Display (italic) | Merriweather Sans Italic [wght] | same |
| Perfidy SemiMono | iA Writer Quattro V [wght, SPCG] (roman and italic) | Copyright 2018 Information Architects Inc., RFN "iA Writer"; based on IBM Plex, Copyright 2017 IBM Corp., RFN "Plex" |
| Perfidy Mono | IBM Plex Mono (static) | Copyright 2017 IBM Corp., RFN "Plex" |
| Fira Math (bundled, unmodified) | Fira Math 0.3.4 | Copyright 2018-2023 Xiangdong Zeng |

## Modifications (2026-11-07, v1.000)
- Static instances taken from the variable sources at calibrated weight-axis values. SPCG is fixed at 0 for Quattro. Overlaps are removed.
- Linear extrapolation beyond a source's weight range for: Text and Display Light (roman wght≈240, italic wght≈268), and SemiMono Light (≈255) and ExtraBold (≈760).
- Glyphs scaled uniformly (Merriweather Sans ×0.900, Quattro ×0.971, Plex Mono ×0.973), so that every family's x-height is 0.50 em.
- Per-style tracking added to the advance widths. Combining marks and very narrow glyphs are excluded.
- Unified vertical metrics: typo and hhea ascender 0.96 em, descender −0.29 em, line gap 0. Win metrics cover the glyph bounds.
- Dehinted. DSIG, STAT, meta and HVAR tables dropped. Renamed throughout (name IDs 1–6, 16 and 17, vendor PRFD). Designer and URL credits kept.

## Rebuilding
`python build/fetch_sources.py` then `python build/build_perfidy.py`. The output is identical to the shipped fonts (glyf, hmtx, GPOS, GSUB and cmap tables verified byte-identical).
