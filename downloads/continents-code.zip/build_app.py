"""Write site/continents-app.html from app_template.html and the payload.

The reconstructions are precomputed and inlined. The app never queries the
GPlates Web Service: the service's default model is documented as liable to
change and named models' rotation files are updated in place, so a page whose
numbers move when someone else redeploys a server is not reproducible.

The payload carries only what the app draws - place, model, age, latitude and
longitude - not the whole build payload. Coordinates are rounded to two
decimals, which is about a kilometre and far finer than anything this app
claims. A model that places no crust at an age gets null, and the app renders
that as its own state rather than as an absence.

Run:  python3 build_app.py            report only
      python3 build_app.py --apply
"""
import argparse
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
SITE = os.path.join(ROOT, "site")
APP = os.path.join(SITE, "continents-app.html")
TEMPLATE = os.path.join(HERE, "app_template.html")
PAYLOAD = os.path.join(HERE, "outputs", "continents_payload.json")


def app_payload(P):
    past = P["past"]
    return {
        "fetched": past["fetched"],
        "ages": past["ages"],
        "models": [{"name": m["name"], "oldest_ma": m["oldest_ma"]}
                   for m in past["models"]],
        "tracks": [{"place": t["place"], "lon": t["lon"], "lat": t["lat"],
                    "models": {m: {"lat": t["models"][m]["lat"],
                                   "lon": t["models"][m]["lon"]}
                               for m in [x["name"] for x in past["models"]]}}
                   for t in past["tracks"]],
    }


def render(P):
    t = open(TEMPLATE, encoding="utf-8").read()
    data = app_payload(P)
    t = t.replace("{{fetched}}", data["fetched"])
    t = t.replace("{{payload}}", json.dumps(data, separators=(",", ":"),
                                            sort_keys=True))
    left = sorted(set(re.findall(r"{{(\w+)}}", t)))
    if left:
        raise SystemExit(f"app placeholders without a value: {left}")
    # the ?v= stamps bust_cache.py owns, if the app already ships
    if os.path.exists(APP):
        shipped = open(APP, encoding="utf-8").read()
        stamps = dict(re.findall(r'(?:href|src)="([^"?]+)\?v=([0-9a-f]+)"',
                                 shipped))

        def stamp(m):
            path = m.group(2)
            return (f'{m.group(1)}="{path}?v={stamps[path]}"'
                    if path in stamps else m.group(0))
        t = re.sub(r'(href|src)="([^"?]+\.(?:css|js))"', stamp, t)
    return t


def main(apply=False):
    P = json.load(open(PAYLOAD, encoding="utf-8"))
    t = render(P)
    if os.path.exists(APP):
        old = open(APP, encoding="utf-8").read()
        print("  continents-app.html: " + ("unchanged" if old == t
                                           else "would change" if not apply
                                           else "rewritten"))
    else:
        print("  continents-app.html: new"
              + ("" if apply else " (not written)"))
    if apply:
        open(APP, "w", encoding="utf-8").write(t)
    print(f"  payload {len(json.dumps(app_payload(P), separators=(',', ':'))):,}"
          f" bytes inline, app {len(t):,} bytes")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true")
    main(ap.parse_args().apply)
