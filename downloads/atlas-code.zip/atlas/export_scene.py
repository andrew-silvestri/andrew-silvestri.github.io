"""
v6 scene exporter.

Builds the calibrated model (folders 16 and 17) and gives every node a real
position:
  world tabs  -> Mercator projection of true longitude and latitude
  Texas tab   -> real plant coordinates from the EIA archive
  mind tab    -> Allen Brain Atlas regions on a clean sagittal layout
  climate tab -> the real CO2 and temperature series

Writes scene_v6.json for the HTML atlas.
"""
import os, sys, csv, json, math
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PARENT, "17 Julia Model", "calibrate"))
CAL = os.path.join(PARENT, "17 Julia Model", "calibrate", "out")
import verify_parity as M

SW, SH = 1600, 900
LAT_MAX, LAT_MIN = 78.0, -58.0

# tab index per node kind
TAB_OF_KIND = {"climate": 0, "event": 1, "market": 2, "supply": 2,
               "grid": 3, "district": 3, "station": 4, "consumer": 5,
               "psych": 6}
TABS = [
    dict(id="climate", name="Climate", sub="the slow variable"),
    dict(id="events", name="Events", sub="recorded disasters"),
    dict(id="markets", name="Markets and fuel", sub="prices and supply"),
    dict(id="grids", name="Grids", sub="214 power systems"),
    dict(id="plants", name="Power plants", sub="4,000 located units"),
    dict(id="demand", name="Demand", sub="districts and consumers"),
    dict(id="mind", name="Behaviour", sub="where demand is decided"),
]

# Small states and territories that the country polygon file does not carry.
# Longitude, latitude of the main settlement. WLD is the world aggregate row and
# is parked in the mid Atlantic so that it is visible and clearly not a country.
SMALL_STATES = {
 "ABW": (-69.97, 12.52), "ASM": (-170.70, -14.28), "ATG": (-61.80, 17.06),
 "BHR": (50.55, 26.07), "BRB": (-59.54, 13.19), "COK": (-159.78, -21.21),
 "COM": (43.33, -11.70), "CPV": (-23.51, 14.93), "CYM": (-81.25, 19.31),
 "DMA": (-61.37, 15.41), "FRO": (-6.91, 62.01), "GIB": (-5.35, 36.14),
 "GLP": (-61.55, 16.26), "GRD": (-61.68, 12.06), "GUM": (144.79, 13.44),
 "HKG": (114.17, 22.32), "KIR": (172.98, 1.45), "KNA": (-62.78, 17.36),
 "LCA": (-60.98, 13.91), "MAC": (113.54, 22.20), "MDV": (73.51, 4.18),
 "MSR": (-62.19, 16.74), "MTQ": (-61.02, 14.64), "MUS": (57.55, -20.35),
 "NRU": (166.93, -0.52), "PYF": (-149.57, -17.68), "REU": (55.54, -21.11),
 "SGP": (103.82, 1.35), "SHN": (-5.72, -15.97), "SPM": (-56.33, 46.94),
 "STP": (6.61, 0.19), "SYC": (55.49, -4.68), "TCA": (-71.80, 21.69),
 "TON": (-175.20, -21.18), "VCT": (-61.29, 13.16), "VGB": (-64.62, 18.42),
 "VIR": (-64.90, 18.34), "WSM": (-172.10, -13.76), "WLD": (-32.0, 8.0),
}

# country centroids for grid, supply, district and consumer nodes
CC = {}
def load_centroids():
    """Centroid of each country polygon from the vendored world geometry."""
    gj = json.load(open(os.path.join(HERE, "countries.geo.json")))
    out = {}
    for f in gj["features"]:
        iso = f.get("id") or f["properties"].get("iso_a3") or ""
        g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        best, area = None, -1
        for poly in polys:
            ring = poly[0]
            if len(ring) < 4:
                continue
            xs = [p[0] for p in ring]; ys = [p[1] for p in ring]
            a = (max(xs) - min(xs)) * (max(ys) - min(ys))
            if a > area:
                area = a
                best = (sum(xs) / len(xs), sum(ys) / len(ys))
        if iso and best:
            out[iso] = best
    for k, v in SMALL_STATES.items():
        out.setdefault(k, v)
    return out


def merc(lon, lat):
    lat = max(min(lat, LAT_MAX), LAT_MIN)
    x = (lon + 180.0) / 360.0 * SW
    y0 = math.log(math.tan(math.pi / 4 + math.radians(LAT_MAX) / 2))
    y1 = math.log(math.tan(math.pi / 4 + math.radians(LAT_MIN) / 2))
    yy = math.log(math.tan(math.pi / 4 + math.radians(lat) / 2))
    return round(x, 1), round((y0 - yy) / (y0 - y1) * SH, 1)


def simplify(ring, keep):
    if len(ring) <= keep:
        return ring
    step = len(ring) / keep
    return [ring[int(i * step)] for i in range(keep)]


def world_paths():
    gj = json.load(open(os.path.join(HERE, "countries.geo.json")))
    out = []
    for f in gj["features"]:
        g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        for poly in polys:
            ring = poly[0]
            if len(ring) < 10:
                continue
            pts = [merc(p[0], p[1]) for p in simplify(ring, max(10, min(140, len(ring) // 5)))]
            out.append(pts)
    return out


# Allen Brain Atlas regions, placed on a clean lateral schematic.
# Coordinates are a layout, not traced imagery. The structure names and ids are real.
BRAIN_XY = {"present_bias": (1180, 330), "dissonance": (900, 300),
            "norm": (610, 372), "status": (960, 452), "habit": (790, 470),
            "loss_aversion": (880, 540)}
BRAIN_LABEL = {"present_bias": "Prefrontal cortex", "dissonance": "Anterior cingulate",
               "norm": "Temporo-parietal", "status": "Ventral striatum",
               "habit": "Basal ganglia", "loss_aversion": "Amygdala"}


def read(name):
    p = os.path.join(CAL, name)
    if not os.path.exists(p):
        return []
    return list(csv.DictReader(open(p, encoding="utf8", errors="ignore")))


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


def main():
    web = M.build()
    n = len(web["ids"])
    ids, names, kinds = web["ids"], web["names"], web["kinds"]
    cc_xy = load_centroids()
    plants = {p["plant_id"]: p for p in read("us_plants.csv")}
    events = {e["id"]: e for e in read("events_energy_relevant.csv")}
    mixrows = {r["iso3"]: r for r in read("country_mix.csv")}

    # market benchmark locations (the physical trading points)
    MKT_LL = {"MKT_BRENT": (1.0, 60.5), "MKT_WTI": (-96.8, 36.0),
              "MKT_HH": (-92.0, 30.0), "MKT_GASOLINE": (-98.0, 39.0),
              "MKT_ELEC_RETAIL": (-90.0, 42.0), "MKT_CPI": (-77.0, 38.9)}

    nodes = []
    per_tab_counter = defaultdict(int)
    for i in range(n):
        k = kinds[i]
        nid = ids[i]
        tab = TAB_OF_KIND.get(k, 2)
        x = y = None
        lat = lon = None
        if k == "climate":
            j = per_tab_counter["climate"]; per_tab_counter["climate"] += 1
            x, y = 520 + j * 560, 430
        elif k == "market":
            ll = MKT_LL.get(nid)
            if ll:
                lon, lat = ll
                x, y = merc(*ll)
        elif k == "station":
            p = plants.get(nid.replace("PLANT_", ""))
            if p:
                lat, lon = num(p["lat"]), num(p["lon"])
                x, y = merc(lon, lat)
        elif k == "event":
            e = events.get(nid.replace("EVENT_", ""))
            if e:
                lat, lon = num(e["lat"]), num(e["lon"])
                if lat == 0 and lon == 0:
                    iso = e.get("iso3", "")
                    if iso in cc_xy:
                        lon, lat = cc_xy[iso]
                if lat or lon:
                    x, y = merc(lon, lat)
        elif k == "psych":
            ch = nid.replace("PSYCH_", "")
            x, y = BRAIN_XY.get(ch, (900, 400))
        else:
            # grid, supply, district, consumer -> country centroid, small offset
            parts = nid.split("_")
            iso = parts[1] if len(parts) > 1 else ""
            base = cc_xy.get(iso)
            if base:
                lon, lat = base
                jitter = {"supply": 4.0, "district": 6.0, "consumer": 8.0}.get(k, 0.0)
                if jitter:
                    h = abs(hash(nid))
                    lon += ((h % 100) / 100 - 0.5) * jitter
                    lat += (((h // 100) % 100) / 100 - 0.5) * jitter * 0.6
                x, y = merc(lon, lat)
        if x is None:
            x, y = 40, 860          # off-map holding position, visible and honest
        nodes.append(dict(i=i, id=nid, name=names[i][:70], kind=k, tab=tab,
                          x=x, y=y, res=round(web["res"][i], 3),
                          src=web["prov"][i][:90],
                          lat=round(lat, 3) if lat is not None else None,
                          lon=round(lon, 3) if lon is not None else None))

    edges = [dict(s=a, t=b, w=round(w, 4)) for a, b, w in web["edges"]]

    # climate series for the climate tab
    co2 = [[int(r["year"]), int(r["month"]), num(r["ppm"])] for r in read("co2_monthly.csv")]
    temp = [[int(r["year"]), num(r["anomaly_c"])] for r in read("temp_anomaly_annual.csv")]

    # top countries by demand, for the grids tab table
    top_countries = sorted(
        [[r["iso3"], num(r["demand_gw_avg"]), num(r["coal"]), num(r["gas"]),
          num(r["nuclear"]), num(r["hydro"]), num(r["renew"])]
         for r in mixrows.values()],
        key=lambda r: -r[1])[:24]

    scen = {k: dict(shocks=v, desc=d) for (k, v), d in zip(
        M.SCEN.items(),
        ["A large oil supply loss raises the crude benchmark.",
         "A gas price spike moves power costs everywhere.",
         "The climate system moves to a higher anomaly.",
         "The United States grid loses reserve margin.",
         "China loses part of its coal supply.",
         "A conservation wave enters through the behaviour layer."])}

    data = dict(scene=[SW, SH], tabs=TABS, nodes=nodes, edges=edges,
                world=world_paths(), brain=BRAIN_LABEL, brainXY=BRAIN_XY,
                co2=co2[-360:], temp=temp, topCountries=top_countries,
                scenarios=scen)
    p = os.path.join(HERE, "scene_v6.json")
    json.dump(data, open(p, "w"))
    print(f"nodes {len(nodes)}  edges {len(edges)}  coast paths {len(data['world'])}")
    placed = sum(1 for nd in nodes if nd["x"] != 40 or nd["y"] != 860)
    print(f"positioned on real coordinates: {placed} of {len(nodes)}")
    print("wrote", p)


if __name__ == "__main__":
    main()
