"""
The image library.

Produces a set of clean figures from the calibrated model and the feedstocks.
Each image gets a plain text file with the same name. The text file holds the
description. The description is not printed inside the image.

Method follows the comparison repository new-py-dataviz: matplotlib and seaborn
for statistical panels, plotnine for grammar-of-graphics panels, and plotly for
the interactive panels.

    python3 make_library.py

Writes to library/.
"""
import os, sys, csv, math, json, textwrap
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
CAL = os.path.join(PARENT, "17 Julia Model", "calibrate", "out")
FEED = os.path.join(PARENT, "16 Presentation Architecture", "feedstocks")
sys.path.insert(0, os.path.join(PARENT, "17 Julia Model", "calibrate"))
import verify_parity as M

LIB = os.path.join(HERE, "library")
os.makedirs(LIB, exist_ok=True)

INK = "#1b1b1b"; DIM = "#6d7278"; LINE = "#e2ded8"
KC = {"climate": "#4f8fbe", "event": "#c0554b", "market": "#c8922f",
      "supply": "#b3679b", "grid": "#4a9a6b", "station": "#4a6fa5",
      "district": "#3f9a9a", "consumer": "#8d6fb8", "psych": "#b8994a"}
KL = {"climate": "Climate system", "event": "Recorded event",
      "market": "Price benchmark", "supply": "Fuel supply",
      "grid": "National grid", "station": "Power plant",
      "district": "District", "consumer": "Consumer group",
      "psych": "Behaviour channel"}

sns.set_theme(style="whitegrid", rc={
    "axes.edgecolor": "#c9c5be", "grid.color": LINE, "axes.labelcolor": INK,
    "text.color": INK, "xtick.color": DIM, "ytick.color": DIM,
    "font.family": "DejaVu Sans", "axes.titleweight": "bold",
    "axes.titlesize": 12, "figure.facecolor": "white", "axes.facecolor": "white"})

MADE = []
# Rows that are aggregates, not countries. They are excluded from country charts.
AGGREGATES = {"WLD", "OWID_WRL", "EUU", "OECD"}


def save(fig, name, title, description, method):
    """Save the figure and write the matching text file."""
    png = os.path.join(LIB, name + ".png")
    fig.savefig(png, dpi=170, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    write_label(name, title, description, method)
    MADE.append(name)
    print("  ", name)


def write_label(name, title, description, method):
    txt = os.path.join(LIB, name + ".txt")
    body = textwrap.fill(" ".join(description.split()), 78)
    with open(txt, "w", encoding="utf8") as f:
        f.write(f"{title}\n{'=' * len(title)}\n\n{body}\n\n"
                f"Method: {method}\n"
                f"Model: 7,192 nodes, 13,826 links, built from public data.\n"
                f"File: {name}.png\n")


def read(fn):
    p = os.path.join(CAL, fn)
    return list(csv.DictReader(open(p, encoding="utf8", errors="ignore"))) \
        if os.path.exists(p) else []


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return 0.0


# ─────────────────────────────────────────────────────────── the model
print("building the model ...")
WEB = M.build()
NODES = len(WEB["ids"])
RUNS = {k: M.propagate(WEB, v) for k, v in M.SCEN.items()}


# 01 ── the world fuel mix ────────────────────────────────────────────────────
def fig_fuel_mix():
    rows = [r for r in read("country_mix.csv") if r["iso3"] not in AGGREGATES]
    df = pd.DataFrame([{
        "iso3": r["iso3"], "demand_gw": num(r["demand_gw_avg"]),
        "coal": num(r["coal"]), "gas": num(r["gas"]), "nuclear": num(r["nuclear"]),
        "hydro": num(r["hydro"]), "renew": num(r["renew"]), "oil": num(r["oil"])}
        for r in rows])
    top = df.nlargest(28, "demand_gw").sort_values("demand_gw")
    fig, ax = plt.subplots(figsize=(11, 9))
    cols = ["coal", "gas", "oil", "nuclear", "hydro", "renew"]
    palette = {"coal": "#6f6f6f", "gas": "#d08a4a", "oil": "#8c6a4f",
               "nuclear": "#9b6fbe", "hydro": "#4f8fbe", "renew": "#4a9a6b"}
    left = np.zeros(len(top))
    for cname in cols:
        ax.barh(top["iso3"], top[cname], left=left, color=palette[cname],
                label=cname, height=.74)
        left += top[cname].values
    ax.set_xlabel("share of electricity generation")
    ax.set_xlim(0, 1)
    ax.set_title("Electricity fuel mix of the 28 largest power systems")
    ax.legend(ncol=6, frameon=False, loc="upper center", bbox_to_anchor=(.5, -.06))
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    save(fig, "01_world_fuel_mix",
         "Electricity fuel mix of the 28 largest power systems",
         "Each bar is one country. The bar shows the share of that country's "
         "electricity that comes from each fuel. The countries are ordered by "
         "average demand, with the largest at the top. These shares are not "
         "estimates. They come from the Energy Institute Statistical Review and "
         "from Our World in Data. In the model, this share sets the strength of "
         "the link between a fuel supply and its national grid. A country with a "
         "high coal share therefore reacts more to a coal supply problem.",
         "matplotlib, stacked horizontal bar")


# 02 ── demand distribution ───────────────────────────────────────────────────
def fig_demand_dist():
    rows = [r for r in read("country_mix.csv") if r["iso3"] not in AGGREGATES]
    d = pd.DataFrame({"demand_gw": [num(r["demand_gw_avg"]) for r in rows]})
    d = d[d.demand_gw > 0]
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    sns.histplot(d, x="demand_gw", bins=40, log_scale=(True, False),
                 color="#4a6fa5", ax=axes[0])
    axes[0].set_title("How national demand is distributed")
    axes[0].set_xlabel("average demand, gigawatts, log scale")
    axes[0].set_ylabel("countries")
    sorted_d = np.sort(d.demand_gw.values)[::-1]
    cum = np.cumsum(sorted_d) / sorted_d.sum() * 100
    axes[1].plot(np.arange(1, len(cum) + 1), cum, lw=2.4, color="#c8922f")
    axes[1].axhline(80, ls="--", lw=1, color=DIM)
    n80 = int(np.argmax(cum >= 80) + 1)
    axes[1].axvline(n80, ls="--", lw=1, color=DIM)
    axes[1].annotate(f"{n80} countries reach 80 percent",
                     (n80 + 3, 62), fontsize=10, color=INK)
    axes[1].set_title("Concentration of world electricity demand")
    axes[1].set_xlabel("countries, ordered from largest")
    axes[1].set_ylabel("cumulative share, percent")
    for ax in axes:
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout()
    save(fig, "02_demand_distribution",
         "How world electricity demand is distributed and concentrated",
         "The left panel counts countries by their average electricity demand. "
         "The scale is logarithmic because the range is very wide. The right "
         "panel adds the countries together, starting with the largest. It shows "
         "how few countries hold most of the world demand. This concentration is "
         "the reason a change in one large system can move the world total.",
         "seaborn histogram and matplotlib cumulative curve")


# 03 ── price histories ───────────────────────────────────────────────────────
def fig_prices():
    rows = read("prices_long.csv")
    df = pd.DataFrame(rows)
    df["value"] = df["value"].map(num)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    keep = ["brent", "wti", "henry_hub", "us_gasoline_retail"]
    df = df[df.series.isin(keep)].dropna()
    labels = {"brent": "Brent crude, dollars per barrel",
              "wti": "WTI crude, dollars per barrel",
              "henry_hub": "Henry Hub gas, dollars per million Btu",
              "us_gasoline_retail": "US retail gasoline, dollars per gallon"}
    fig, axes = plt.subplots(2, 2, figsize=(13.5, 8))
    for ax, s in zip(axes.flat, keep):
        sub = df[df.series == s].sort_values("date")
        ax.plot(sub.date, sub.value, lw=1.0, color="#4a6fa5")
        ax.set_title(labels[s], fontsize=11)
        ax.set_xlabel(""); ax.set_ylabel("")
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.suptitle("The four price series that set market inertia in the model",
                 fontsize=13, fontweight="bold", y=1.01)
    fig.tight_layout()
    save(fig, "03_price_histories",
         "The four price series that set market inertia in the model",
         "Each panel is one traded price, taken from the Federal Reserve "
         "Economic Data service. The model does not use these prices to forecast. "
         "It uses their variation. A price that moves a great deal in the record "
         "is given a low inertia value, so it reacts quickly in the model. A "
         "steady price is given a high inertia value. This is how the real "
         "behaviour of each market enters the model.",
         "matplotlib, small multiples")


# 04 ── inertia by node type ──────────────────────────────────────────────────
def fig_inertia():
    df = pd.DataFrame({"kind": [KL[k] for k in WEB["kinds"]],
                       "inertia": WEB["res"]})
    order = df.groupby("kind")["inertia"].mean().sort_values().index
    fig, ax = plt.subplots(figsize=(11, 6))
    sns.boxplot(df, y="kind", x="inertia", order=order, ax=ax, width=.6,
                palette={KL[k]: KC[k] for k in KC}, fliersize=2)
    ax.set_xlabel("inertia: 0 reacts at once, 1 almost never moves")
    ax.set_ylabel("")
    ax.set_title("How strongly each type of node resists change")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    save(fig, "04_inertia_by_type",
         "How strongly each type of node resists change",
         "Inertia controls the speed of a node. A recorded event has the lowest "
         "inertia because a disaster happens at once. Behaviour channels have the "
         "highest inertia because habits change over years. Price benchmarks "
         "cover a range, because each one takes its value from its own measured "
         "volatility. This single parameter produces the order in which effects "
         "arrive across the model.",
         "seaborn box plot")


# 05 ── link weight structure ─────────────────────────────────────────────────
def fig_weights():
    ws = np.array([w for _, _, w in WEB["edges"]])
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    sns.histplot(ws[ws > 0], bins=45, color="#4a9a6b", ax=axes[0])
    axes[0].set_yscale("log")
    axes[0].set_title("Positive links: how strength is distributed")
    axes[0].set_xlabel("link weight"); axes[0].set_ylabel("links, log scale")
    pair = Counter()
    for a, b, w in WEB["edges"]:
        pair[(WEB["kinds"][a], WEB["kinds"][b])] += 1
    rows = [(f"{KL[a]} to {KL[b]}", v) for (a, b), v in pair.most_common(12)][::-1]
    axes[1].barh([r[0] for r in rows], [r[1] for r in rows], color="#4a6fa5",
                 height=.7)
    axes[1].set_xscale("log")
    axes[1].set_title("The twelve most common link types")
    axes[1].set_xlabel("number of links, log scale")
    axes[1].tick_params(labelsize=9)
    for ax in axes:
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout()
    save(fig, "05_link_structure",
         "The structure of the links between nodes",
         "The left panel counts links by their weight. Most links are weak. A "
         "small number are strong. This shape is expected, because each node "
         "connects strongly to a few neighbours and weakly to many others. The "
         "right panel shows which pairs of node types are joined most often. The "
         "model contains 13,826 links in total, of which 1,142 are negative. A "
         "negative link carries relief rather than stress.",
         "seaborn histogram and matplotlib bar")


# 06 ── scenario reach ────────────────────────────────────────────────────────
def fig_scenarios():
    rows = []
    for name, (s, hit) in RUNS.items():
        for i, k in enumerate(WEB["kinds"]):
            if abs(s[i]) >= 0.02:
                rows.append({"scenario": name.replace("_", " "),
                             "kind": KL[k], "effect": abs(s[i])})
    df = pd.DataFrame(rows)
    piv = df.pivot_table(index="scenario", columns="kind", values="effect",
                         aggfunc="mean").fillna(0)
    fig, ax = plt.subplots(figsize=(11, 5.4))
    sns.heatmap(piv, cmap="YlOrBr", annot=True, fmt=".3f", linewidths=.6,
                linecolor="white", cbar_kws={"label": "average effect"}, ax=ax)
    ax.set_title("Where each change lands, by node type")
    ax.set_xlabel(""); ax.set_ylabel("")
    plt.setp(ax.get_xticklabels(), rotation=32, ha="right")
    save(fig, "06_scenario_reach",
         "Where each change lands, by node type",
         "Each row is one change applied to the model. Each column is a type of "
         "node. The number is the average effect on the nodes of that type that "
         "changed. An empty cell means the change did not reach that type. The "
         "climate change reaches the widest set of types, because the climate "
         "connects to every country. A single national change stays close to its "
         "own country.",
         "seaborn heat map with annotations")


# 07 ── arrival order ─────────────────────────────────────────────────────────
def fig_arrival():
    s, hit = RUNS["oil_supply_shock"]
    rows = [{"kind": KL[WEB["kinds"][i]], "step": hit[i]}
            for i in range(NODES) if hit[i] >= 0 and abs(s[i]) >= 0.02]
    df = pd.DataFrame(rows)
    order = df.groupby("kind")["step"].median().sort_values().index
    fig, ax = plt.subplots(figsize=(11, 5.6))
    sns.stripplot(df, x="step", y="kind", order=order, ax=ax, size=4,
                  alpha=.55, jitter=.3,
                  palette={KL[k]: KC[k] for k in KC})
    med = df.groupby("kind")["step"].median()
    for i, k in enumerate(order):
        ax.scatter(med[k], i, marker="|", s=420, color=INK, zorder=5)
    ax.set_xlabel("step at which the node first changes")
    ax.set_ylabel("")
    ax.set_title("Order of arrival after a large oil supply loss")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    save(fig, "07_arrival_order",
         "Order of arrival after a large oil supply loss",
         "Each dot is one node that changed. Its position shows the step at "
         "which it first moved. The black bar marks the middle value for that "
         "type. Prices move first, in one step. Fuel supplies follow, then "
         "grids, then districts, then consumers. The model therefore reproduces "
         "the expected order: a market signal travels before a physical effect.",
         "seaborn strip plot with median markers")


# 08 ── the response curve ────────────────────────────────────────────────────
def fig_response():
    sizes = np.linspace(0.05, 1.0, 20)
    rows = []
    for sz in sizes:
        s, _ = M.propagate(WEB, {"MKT_BRENT": float(sz)})
        rows.append({"applied": sz,
                     "touched": sum(1 for x in s if abs(x) >= 0.02),
                     "mean_effect": float(np.mean([abs(x) for x in s]))})
    df = pd.DataFrame(rows)
    fig, ax1 = plt.subplots(figsize=(10, 5.6))
    ax1.plot(df.applied, df.touched, lw=2.6, color="#4a6fa5", marker="o", ms=4)
    ax1.set_xlabel("size of the change applied to the oil price")
    ax1.set_ylabel("nodes that changed", color="#4a6fa5")
    ax2 = ax1.twinx()
    ax2.plot(df.applied, df.mean_effect, lw=2.6, color="#c8922f", ls="--",
             marker="s", ms=4)
    ax2.set_ylabel("average effect across all nodes", color="#c8922f")
    ax2.grid(False)
    ax1.set_title("The model saturates: a larger cause does not give a "
                  "proportional effect")
    for sp in ("top",):
        ax1.spines[sp].set_visible(False); ax2.spines[sp].set_visible(False)
    save(fig, "08_response_curve",
         "The model saturates rather than growing without limit",
         "The change applied to the oil price is increased in steps from a small "
         "value to the maximum. The blue line counts how many nodes changed. The "
         "gold line gives the average size of the effect. Both lines bend and "
         "flatten. This is the effect of the limit function in the calculation. "
         "A real system behaves in the same way: a price cannot rise without end, "
         "and a grid cannot fail more than completely.",
         "matplotlib with twin axes")


# 09 ── plotnine grammar of graphics panel ────────────────────────────────────
def fig_plotnine():
    try:
        from plotnine import (ggplot, aes, geom_point, geom_smooth, labs,
                              theme_minimal, theme, element_text, scale_x_log10,
                              scale_color_manual)
    except Exception as e:
        print("   plotnine unavailable:", e); return
    rows = [r for r in read("country_mix.csv") if r["iso3"] not in AGGREGATES]
    df = pd.DataFrame([{
        "iso3": r["iso3"], "demand_gw": num(r["demand_gw_avg"]),
        "low_carbon": num(r["nuclear"]) + num(r["hydro"]) + num(r["renew"]),
        "co2_mt": num(r["co2_mt"])} for r in rows])
    df = df[(df.demand_gw > 0.5) & (df.low_carbon > 0)]
    df["size_band"] = pd.cut(df.demand_gw, [0, 5, 30, 200, 1e6],
                             labels=["under 5 GW", "5 to 30 GW",
                                     "30 to 200 GW", "over 200 GW"])
    p = (ggplot(df, aes("demand_gw", "low_carbon", color="size_band"))
         + geom_point(size=2.4, alpha=.75)
         + geom_smooth(method="lowess", se=False, color="#6d7278", size=.8)
         + scale_x_log10()
         + scale_color_manual(values=["#c0554b", "#c8922f", "#4a9a6b", "#4a6fa5"])
         + labs(x="average demand, gigawatts, log scale",
                y="share of electricity from low carbon sources",
                color="system size",
                title="System size against low carbon share")
         + theme_minimal()
         + theme(figure_size=(10, 6), plot_title=element_text(weight="bold",
                                                             size=13)))
    png = os.path.join(LIB, "09_size_vs_lowcarbon.png")
    p.save(png, dpi=170, verbose=False)
    write_label("09_size_vs_lowcarbon",
                "System size against low carbon share",
                "Each point is one country. The horizontal position is the size "
                "of its power system. The vertical position is the share of its "
                "electricity that comes from nuclear, hydro or other renewable "
                "sources. The grey line is a smoothed trend. The plot shows that "
                "size alone does not decide the low carbon share. Small systems "
                "occupy the full range, because a single large hydro station can "
                "supply most of a small country.",
                "plotnine, grammar of graphics")
    MADE.append("09_size_vs_lowcarbon")
    print("   09_size_vs_lowcarbon")


# 10 ── plotly interactive map ────────────────────────────────────────────────
def fig_plotly_map():
    try:
        import plotly.express as px
    except Exception as e:
        print("   plotly unavailable:", e); return
    plants = read("us_plants.csv")
    df = pd.DataFrame([{"name": p["name"], "lat": num(p["lat"]),
                        "lon": num(p["lon"]), "state": p["state"]}
                       for p in plants])
    df = df[(df.lat.between(18, 72)) & (df.lon.between(-180, -60))]
    fig = px.scatter_geo(df, lat="lat", lon="lon", hover_name="name",
                         scope="north america", opacity=.55,
                         title="United States power plants in the model")
    fig.update_traces(marker=dict(size=4, color="#4a6fa5"))
    fig.update_layout(font_family="DejaVu Sans", title_font_size=16,
                      margin=dict(l=0, r=0, t=48, b=0),
                      geo=dict(bgcolor="white", lakecolor="#eef2f5",
                               landcolor="#e4e7e3", showcountries=True))
    html = os.path.join(LIB, "10_us_plants_map.html")
    fig.write_html(html, include_plotlyjs="cdn")
    try:
        fig.write_image(os.path.join(LIB, "10_us_plants_map.png"),
                        width=1400, height=900, scale=2)
    except Exception:
        # static export needs kaleido; the interactive file is the deliverable
        pass
    write_label("10_us_plants_map",
                "United States power plants in the model",
                "Every point is one power plant that the model contains. The "
                "position is the plant's recorded coordinate, taken from the "
                "bulk archive of the Energy Information Administration. The model "
                "holds 4,000 of the 15,247 located plants by default. This map "
                "confirms that the station layer follows the real pattern of "
                "United States generation, with dense clusters along the Gulf "
                "coast, the Ohio valley and the coasts. Open the html file to "
                "pan, zoom and read plant names.",
                "plotly express, interactive map, html output")
    MADE.append("10_us_plants_map")
    print("   10_us_plants_map (html)")


# 11 ── climate record ────────────────────────────────────────────────────────
def fig_climate():
    co2 = read("co2_monthly.csv")
    temp = read("temp_anomaly_annual.csv")
    d1 = pd.DataFrame({"year": [num(r["year"]) + (num(r["month"]) - .5) / 12
                                for r in co2],
                       "ppm": [num(r["ppm"]) for r in co2]})
    d2 = pd.DataFrame({"year": [num(r["year"]) for r in temp],
                       "anom": [num(r["anomaly_c"]) for r in temp]})
    d2 = d2[d2.year >= 1958]
    fig, axes = plt.subplots(2, 1, figsize=(12, 7.6), sharex=True)
    axes[0].plot(d1.year, d1.ppm, lw=1.4, color="#4f8fbe")
    axes[0].set_ylabel("parts per million")
    axes[0].set_title("Carbon dioxide, monthly average, Mauna Loa")
    axes[1].bar(d2.year, d2.anom,
                color=["#c0554b" if v > 0 else "#4f8fbe" for v in d2.anom],
                width=.85)
    axes[1].axhline(0, color=DIM, lw=.9)
    axes[1].set_ylabel("degrees Celsius")
    axes[1].set_xlabel("year")
    axes[1].set_title("Global temperature anomaly against the 1951 to 1980 mean")
    for ax in axes:
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout()
    save(fig, "11_climate_record",
         "The two climate series that set the state of the model",
         "The upper panel is the carbon dioxide record from Mauna Loa. The saw "
         "pattern is the growing season of the northern hemisphere. The lower "
         "panel is the global temperature anomaly. Both series are read directly "
         "into the model. They set the starting state of the two climate nodes. "
         "The climate nodes then connect to every national grid, and to the gas "
         "and electricity prices, through heating and cooling demand.",
         "matplotlib, stacked time series")


# 12 ── recorded events ───────────────────────────────────────────────────────
def fig_events():
    rows = read("events_energy_relevant.csv")
    df = pd.DataFrame([{"year": num(r["year"]), "type": r["type"],
                        "damage": num(r["damage_k_usd_adj"]) / 1e6,
                        "country": r["country"]} for r in rows])
    df = df[df.damage > 0]
    fig, axes = plt.subplots(1, 2, figsize=(14, 5.6))
    dec = df.copy()
    dec["decade"] = (dec.year // 10 * 10).astype(int)
    piv = dec.pivot_table(index="decade", columns="type", values="damage",
                          aggfunc="sum").fillna(0)
    piv.plot(kind="bar", stacked=True, ax=axes[0], width=.8,
             color=["#4f8fbe", "#c0554b", "#c8922f", "#4a9a6b", "#8d6fb8", "#b3679b"])
    axes[0].set_title("Recorded damage by decade and type")
    axes[0].set_xlabel("decade"); axes[0].set_ylabel("billions of dollars, adjusted")
    axes[0].legend(frameon=False, fontsize=9)
    top = df.nlargest(12, "damage").sort_values("damage")
    axes[1].barh([f"{r.country} {int(r.year)}" for r in top.itertuples()],
                 top.damage, color="#c0554b", height=.7)
    axes[1].set_title("The twelve costliest events in the model")
    axes[1].set_xlabel("billions of dollars, adjusted")
    for ax in axes:
        for sp in ("top", "right"):
            ax.spines[sp].set_visible(False)
    fig.tight_layout()
    save(fig, "12_recorded_events",
         "Recorded disasters that the model contains",
         "The left panel adds the adjusted damage of every energy relevant "
         "disaster in each decade, and separates the total by disaster type. The "
         "right panel names the twelve costliest single events. These records "
         "come from the international disaster database. In the model, each event "
         "is a node. The recorded damage sets the strength of the link from that "
         "event to the national grid of the country it struck.",
         "pandas plotting on matplotlib axes")


# 13 ── provenance ────────────────────────────────────────────────────────────
def fig_provenance():
    prov = Counter()
    for p in WEB["prov"]:
        prov[("EIA bulk archive" if p.startswith("EIA") else
              "EM-DAT disasters" if p.startswith("EM-DAT") else
              "Statistical Review and Our World in Data" if p.startswith("EI/OWID") else
              "FRED price histories" if p.startswith("FRED") else
              "NOAA and NASA climate" if p.startswith(("NOAA", "NASA")) else
              "Allen Brain Atlas" if p.startswith("Allen") else
              "Published studies" if "elasticity" in p else
              "Derived from the above")] += 1
    df = pd.DataFrame({"source": list(prov), "nodes": list(prov.values())})
    df = df.sort_values("nodes")
    fig, ax = plt.subplots(figsize=(11, 5.4))
    bars = ax.barh(df.source, df.nodes, color="#4a6fa5", height=.68)
    for b, v in zip(bars, df.nodes):
        ax.text(v * 1.02, b.get_y() + b.get_height() / 2, f"{v:,}",
                va="center", fontsize=10)
    ax.set_xscale("log")
    ax.set_xlabel("nodes, log scale")
    ax.set_title("Every node names its source")
    for sp in ("top", "right"):
        ax.spines[sp].set_visible(False)
    save(fig, "13_provenance",
         "Every node names its source",
         "The model records where each node came from. This chart counts the "
         "nodes by source. The largest group is the plant list from the bulk "
         "archive of the Energy Information Administration. The group marked as "
         "published studies holds the consumer response values. These values are "
         "the only assumed parameters in the model, and they are labelled so that "
         "a reader can find them.",
         "matplotlib, horizontal bar, log scale")


if __name__ == "__main__":
    print("writing the image library ...")
    fig_fuel_mix(); fig_demand_dist(); fig_prices(); fig_inertia()
    fig_weights(); fig_scenarios(); fig_arrival(); fig_response()
    fig_plotnine(); fig_plotly_map(); fig_climate(); fig_events()
    fig_provenance()
    index = os.path.join(LIB, "INDEX.txt")
    with open(index, "w", encoding="utf8") as f:
        f.write("IMAGE LIBRARY\n=============\n\n")
        f.write("Each image has a text file with the same name. The text file "
                "holds the description of that image.\n\n")
        for name in MADE:
            title = ""
            tp = os.path.join(LIB, name + ".txt")
            if os.path.exists(tp):
                title = open(tp, encoding="utf8").readline().strip()
            f.write(f"{name}.png\n    {title}\n")
    print(f"\n{len(MADE)} images, each with a matching text file, in {LIB}")
