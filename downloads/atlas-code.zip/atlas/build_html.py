"""Injects scene_v6.json into the atlas template and writes atlas_v6.html."""
import os, json, re

HERE = os.path.dirname(os.path.abspath(__file__))
tpl = open(os.path.join(HERE, "atlas_v6_template.html"), encoding="utf8").read()
data = json.load(open(os.path.join(HERE, "scene_v6.json"), encoding="utf8"))
html = tpl.replace("/*__DATA__*/null", json.dumps(data, separators=(",", ":")))
out = os.path.join(HERE, "atlas_v6.html")
open(out, "w", encoding="utf8").write(html)
print(f"wrote {out}  ({len(html) // 1024} KB, {len(data['nodes']):,} nodes)")
