# Atlas v6 and the image library

Built from the calibrated model in folders 16 and 17. Every node holds a real
coordinate. Every parameter holds a source.

| Item | File | Rebuild with |
|---|---|---|
| Layered interactive atlas | `atlas_v6.html` | `python3 export_scene.py` then `build_html.py` |
| Image library, 13 items | `library/` | `python3 make_library.py` |

## 1. The atlas

`atlas_v6.html` is one file. Open it in a browser. Nothing is installed.

Seven layers, selected by the tabs at the foot of the page:

| Tab | Nodes | What you see |
|---|---|---|
| Climate | 2 | The measured carbon dioxide curve, 360 months |
| Events | 526 | Every recorded disaster at its true coordinate |
| Markets and fuel | 731 | Price benchmarks at their trading points, and every national fuel supply |
| Grids | 785 | 214 national grids and their districts |
| Power plants | 4,000 | Real United States plants at their recorded coordinates |
| Demand | 1,142 | Household and industry groups |
| Behaviour | 6 | The behaviour channels on Allen Brain Atlas regions |

All 7,192 nodes are placed on a real coordinate. There are no invented positions.

**Backgrounds.** The world tabs use a true Mercator projection of the country
polygon set, drawn as filled land with a coastline stroke and a graticule. The
climate tab draws the measured series directly. The behaviour tab uses a clean
lateral schematic with the six real Allen Brain Atlas regions labelled. The
schematic is a layout, not a traced image; the region names and identifiers are
real.

**Controls.** Choose a scenario, then press Run. The result panel reports how
many nodes changed, how many steps the model needed to settle, and the largest
single effect. Red counts appear on the other tabs to show where the change
landed. Click any node to read its source and apply your own change there.
Scroll to zoom, drag to pan. The view cannot be lost; zoom and pan are bounded.

## 2. The image library

Thirteen items in `library/`. **Each image has a plain text file with the same
name.** The text file holds the description. No description is printed inside an
image. `INDEX.txt` lists every item.

| File | Subject |
|---|---|
| 01 world fuel mix | Fuel shares of the 28 largest power systems |
| 02 demand distribution | How national demand is spread and concentrated |
| 03 price histories | The four price series that set market inertia |
| 04 inertia by type | How strongly each node type resists change |
| 05 link structure | Weight distribution and the most common link types |
| 06 scenario reach | Where each change lands, by node type |
| 07 arrival order | The order in which effects arrive |
| 08 response curve | Evidence that the model saturates |
| 09 size against low carbon share | System size against clean share |
| 10 United States plants map | Interactive map, html |
| 11 climate record | Carbon dioxide and temperature |
| 12 recorded events | Disaster damage by decade and the costliest events |
| 13 provenance | How many nodes come from each source |

**Method.** The library follows the comparison in the repository
`new-py-dataviz`: matplotlib and seaborn for the statistical panels, plotnine
for the grammar-of-graphics panel, and plotly for the interactive map. Each text
file names the method used for that image.

## 3. Rebuilding

```
python3 export_scene.py     # positions every node on a real coordinate
python3 build_html.py       # injects the data into the atlas template
python3 make_library.py     # writes the 13 images and their text files
```

## Honest notes

- Country level nodes sit at the centroid of the country, with a small offset so
  that a grid, its supplies, its districts and its consumers do not overlap.
  Plant and event nodes sit at their own recorded coordinates.
- 39 small states and territories are not in the country polygon file. Their
  coordinates are listed in `export_scene.py` and taken from the main
  settlement.
- The behaviour tab is a schematic. It is not a medical image.
