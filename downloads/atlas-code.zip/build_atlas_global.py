"""
Rebuild the atlas payload with a world set of power plants and a wider
behaviour layer.

Two things were wrong with the previous build, and both were invisible until
somebody turned the globe.

The plant layer came from the United States Energy Information Administration,
so all four thousand of its units sat between longitude -167 and -68. Fifty-six
per cent of the atlas was one country. Rotating the globe therefore did not
reveal a world model; it revealed North America and then a lot of ocean. The
World Resources Institute's global database carries 34,936 plants in 167
countries with coordinates, capacity and fuel, which is the same quantity of
information about the whole planet rather than about one part of it. Above a
ten-megawatt floor it holds 21,337 units, 163 countries and 99.1% of world
generating capacity, and the United States falls back to its real share, which
is about a fifth.

The behaviour layer had six channels. Six is enough to say the layer exists and
too few to say anything with it, so it is widened here to a full set of
behavioural mechanisms placed on named Allen Brain Atlas regions.

Everything else in the scene, the grids and markets and disasters and demand
cohorts, is carried across unchanged from the model of record.

Run:  python3 build_atlas_global.py
"""

import json
import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
SCENE = os.path.join(PARENT, "19 Atlas v6", "scene_v6.json")
PLANTS = os.path.join(PARENT, "19 Atlas v6", "raw",
                      "global_power_plant_database.csv")
OUT = os.path.join(HERE, "site", "assets", "atlas-data.js")

sys.path.insert(0, HERE)
from build_atlas import coastlines, KINDS            # noqa: E402

MIN_MW = 10.0          # below this the database is thin and uneven by country

# ------------------------------------------------------------------ brain ---
# Behavioural mechanisms, each placed on a named region. The regions are real
# and the assignment is defensible rather than measured: this is a model of
# where demand decisions are made, not a claim about neuroanatomy, and the
# application says so on screen.
BRAIN = [
    ("present_bias",   "CTXpl: Cortical plate",                  [0.00,  0.42,  0.62]),
    ("dissonance",     "ACAd: Anterior cingulate, dorsal",       [0.00,  0.30,  0.20]),
    ("norm",           "TEa: Temporal association areas",        [0.66,  0.02, -0.05]),
    ("loss_aversion",  "BLA: Basolateral amygdalar nucleus",     [0.52, -0.28,  0.12]),
    ("habit",          "STRd: Striatum, dorsal region",          [0.34, -0.02,  0.16]),
    ("status",         "ACB: Nucleus accumbens",                 [0.22, -0.20,  0.34]),
    ("salience",       "AId: Agranular insular, dorsal",         [0.60,  0.10,  0.28]),
    ("effort_cost",    "ACAv: Anterior cingulate, ventral",      [0.00,  0.18,  0.30]),
    ("risk_appetite",  "ORBl: Orbital area, lateral",            [0.30,  0.30,  0.58]),
    ("delay_discount", "PL: Prelimbic area",                     [0.10,  0.34,  0.44]),
    ("social_proof",   "TEa: Temporal association, ventral",     [0.70, -0.10, -0.18]),
    ("identity",       "RSPd: Retrosplenial, dorsal",            [0.08, -0.10, -0.62]),
    ("threat",         "CEA: Central amygdalar nucleus",         [0.46, -0.34,  0.06]),
    ("reward_learn",   "VTA: Ventral tegmental area",            [0.14, -0.42, -0.16]),
    ("attention",      "SSp: Primary somatosensory",             [0.56,  0.34,  0.10]),
    ("memory_recall",  "CA1: Field CA1, hippocampus",            [0.48, -0.14, -0.32]),
    ("planning",       "MOs: Secondary motor area",              [0.24,  0.44,  0.44]),
    ("inhibition",     "ORBm: Orbital area, medial",             [0.06,  0.26,  0.56]),
    ("valuation",      "OFC: Orbitofrontal cortex",              [0.22,  0.34,  0.60]),
    ("arousal",        "LC: Locus coeruleus",                    [0.10, -0.46, -0.44]),
    ("satiety",        "ARH: Arcuate hypothalamic nucleus",      [0.06, -0.40,  0.08]),
    ("thermal_comfort","POA: Preoptic area",                     [0.12, -0.30,  0.26]),
    ("routine",        "STRv: Striatum, ventral region",         [0.28, -0.24,  0.24]),
    ("novelty",        "SNc: Substantia nigra, compact part",    [0.20, -0.38, -0.10]),
]


def load_plants():
    import csv
    rows = []
    with open(PLANTS, newline="", encoding="utf-8", errors="replace") as fh:
        for r in csv.DictReader(fh):
            try:
                mw = float(r["capacity_mw"])
                la = float(r["latitude"])
                lo = float(r["longitude"])
            except (TypeError, ValueError, KeyError):
                continue
            if mw < MIN_MW or not (-90 <= la <= 90) or not (-180 <= lo <= 180):
                continue
            rows.append({
                "name": (r.get("name") or "").strip() or "unnamed plant",
                "country": (r.get("country_long") or "").strip(),
                "iso": (r.get("country") or "").strip(),
                "fuel": (r.get("primary_fuel") or "").strip() or "Other",
                "mw": mw, "lat": la, "lon": lo,
                "year": (r.get("commissioning_year") or "").split(".")[0],
            })
    return rows


def resonance(mw, world_max):
    """How hard a plant rings when the system is shocked.

    Capacity spans five orders of magnitude, so a linear map would give every
    plant below a gigawatt the same invisible value. The cube root compresses
    it into a range the eye and the propagation engine can both use, and it is
    the same transform the rest of this project uses for the same reason.
    """
    return round(0.12 + 0.62 * (mw / world_max) ** (1.0 / 3.0), 4)


def main():
    d = json.load(open(SCENE, encoding="utf-8"))
    old = d["nodes"]
    old_edges = d["edges"]

    # keep every layer except the American plant set and the six-channel brain
    keep, remap = [], {}
    for n in old:
        if n["kind"] in ("station", "psych"):
            continue
        remap[n["i"]] = len(keep)
        keep.append(n)
    print(f"  carried over {len(keep):,} nodes from the model of record")

    # grids, so a plant can be wired to the system it feeds
    grid_by_iso = {}
    for i, n in enumerate(keep):
        if n["kind"] == "grid":
            iso = (n.get("id") or "").replace("GRID_", "")[:3]
            grid_by_iso.setdefault(iso, i)

    plants = load_plants()
    world_max = max(p["mw"] for p in plants)
    print(f"  {len(plants):,} plants at or above {MIN_MW:.0f} MW across "
          f"{len({p['country'] for p in plants})} countries")

    nodes = list(keep)
    edges = [{"s": remap[e["s"]], "t": remap[e["t"]], "w": e["w"]}
             for e in old_edges
             if e["s"] in remap and e["t"] in remap]
    print(f"  {len(edges):,} edges survive the removal")

    unwired = 0
    for p in plants:
        idx = len(nodes)
        nodes.append({
            "i": idx, "id": f"PP_{idx}",
            "name": f"{p['name']} ({p['fuel']}, {p['mw']:.0f} MW)",
            "kind": "station", "tab": 4,
            "res": resonance(p["mw"], world_max),
            "src": f"WRI Global Power Plant Database v1.3 · {p['country']}"
                   + (f" · commissioned {p['year']}" if p["year"] else ""),
            "lat": round(p["lat"], 4), "lon": round(p["lon"], 4),
            "mw": p["mw"],
        })
        g = grid_by_iso.get(p["iso"])
        if g is None:
            unwired += 1
            continue
        # a plant's grip on its grid scales with its share of a large plant
        edges.append({"s": idx, "t": g,
                      "w": round(0.20 + 0.55 * (p["mw"] / world_max) ** 0.5, 4)})
    print(f"  {unwired:,} plants had no matching grid node and stand alone")

    # the behaviour layer, wired into demand the way the six-channel one was
    demand = [i for i, n in enumerate(nodes) if n["kind"] == "consumer"]
    brain = []
    for k, (key, region, xyz) in enumerate(BRAIN):
        idx = len(nodes)
        nodes.append({
            "i": idx, "id": "PSYCH_" + key, "name": f"{key} ({region})",
            "kind": "psych", "tab": 6, "res": round(0.30 + 0.02 * k, 4),
            "src": "Allen Brain Atlas region; channel assignment is a model "
                   "of where demand is decided, not a measurement",
            "lat": 0.0, "lon": 0.0,
        })
        brain.append({"id": "PSYCH_" + key, "key": key, "region": region,
                      "xyz": xyz, "i": idx})
        # each channel touches a slice of the demand cohorts
        for j in range(k, len(demand), max(1, len(BRAIN))):
            edges.append({"s": idx, "t": demand[j], "w": 0.28})
    print(f"  behaviour layer: {len(brain)} channels on named regions")

    # ------------------------------------------------------------- emit ----
    lat, lon, kind, tab, res, name, src, ident, mw = ([] for _ in range(9))
    for n in nodes:
        lat.append(round(n.get("lat") or 0.0, 3))
        lon.append(round(n.get("lon") or 0.0, 3))
        kind.append(KINDS.index(n["kind"]))
        tab.append(int(n["tab"]))
        res.append(round(float(n["res"]), 4))
        name.append(n["name"])
        src.append(n.get("src", ""))
        ident.append(n["id"])
        mw.append(round(n.get("mw", 0.0), 1))

    # The provenance string is identical for every plant in a country and a
    # commissioning year, so it is stored once and referenced by index. Twenty
    # thousand copies of the same seventy characters is two thirds of the file.
    srcDict, seen, srcIdx = [], {}, []
    for s in src:
        if s not in seen:
            seen[s] = len(srcDict)
            srcDict.append(s)
        srcIdx.append(seen[s])
    print(f"  provenance strings: {len(srcDict):,} distinct of {len(src):,}")

    # Node ids are only used to look a node up; a plant's id carries no
    # information the index does not already carry, so they are dropped for
    # plants and kept where something references them.
    referenced = {b["id"] for b in brain}
    ident = [x if (not x.startswith("PP_") or x in referenced) else ""
             for x in ident]

    tabs = json.loads(json.dumps(d["tabs"]))
    for t in tabs:
        if t["id"] == "plants":
            t["sub"] = f"{len(plants):,} units, {len({p['country'] for p in plants})} countries"
        if t["id"] == "mind":
            t["sub"] = f"{len(brain)} behavioural channels"

    
    payload = {
        "kinds": KINDS, "tabs": tabs, "scenarios": d["scenarios"],
        "n": len(nodes),
        "lat": lat, "lon": lon, "kind": kind, "tab": tab, "res": res,
        "name": name, "srcDict": srcDict, "src": srcIdx, "id": ident,
        "mw": mw,
        "es": [e["s"] for e in edges], "et": [e["t"] for e in edges],
        "ew": [round(float(e["w"]), 4) for e in edges],
        "coast": coastlines(),
        "brain": brain,
        "co2": d.get("co2", []), "temp": d.get("temp", []),
    }
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as fh:
        fh.write("window.ATLAS=")
        json.dump(payload, fh, separators=(",", ":"), ensure_ascii=False)
        fh.write(";\n")

    by_tab = {}
    for t in tab:
        by_tab[t] = by_tab.get(t, 0) + 1
    print(f"\n  {'tab':22s}{'nodes':>8s}")
    for i, t in enumerate(tabs):
        print(f"  {t['name']:22s}{by_tab.get(i, 0):8,d}")
    print(f"\n  {len(nodes):,} nodes · {len(edges):,} edges")
    print(f"  written: {OUT} ({os.path.getsize(OUT)/1024:.0f} kB)")


if __name__ == "__main__":
    main()
