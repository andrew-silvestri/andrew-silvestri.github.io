"""
Batch runner: builds the web, runs every scenario, writes figures, CSV impact
tables, GEXF (Gephi) + JSON exports, and the results workbook feed.

    python3 run_all.py            # everything
    python3 run_all.py hormuz_closure texas_uri_repeat   # subset
"""
import os, sys, csv, json
import numpy as np
import networkx as nx
from energyweb.build import build
from energyweb.engine import Engine
from energyweb.scenarios import SCENARIOS, resolve_shocks
from energyweb import viz

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "outputs")
os.makedirs(OUT, exist_ok=True)


def main():
    G = build(station_density=3.0, district_density=1.2)
    eng = Engine(G)
    print(f"web: {G.number_of_nodes():,} nodes, {G.number_of_edges():,} edges, "
          f"{G.graph['n_stations']:,} stations")

    viz.fig_overview(G, os.path.join(OUT, "fig0_web_overview.png"))

    # ---- exports for external interactive platforms
    H = nx.DiGraph()
    for n, d in G.nodes(data=True):
        H.add_node(n, label=d["name"], kind=d["kind"], layer=int(d["layer"]),
                   country=d.get("country", ""), region=d.get("region", ""),
                   size=float(d.get("size", 1.0)))
    for u, v, d in G.edges(data=True):
        H.add_edge(u, v, weight=abs(float(d["w"])), sign=1 if d["w"] >= 0 else -1,
                   kind=d["kind"])
    nx.write_gexf(H, os.path.join(OUT, "energy_web.gexf"))
    with open(os.path.join(OUT, "energy_web.json"), "w") as f:
        json.dump({
            "nodes": [dict(id=n, name=d["name"], kind=d["kind"],
                           layer=int(d["layer"]), country=d.get("country", ""),
                           resilience=float(d.get("resilience", 0.35)),
                           size=float(d.get("size", 1)))
                      for n, d in G.nodes(data=True)],
            "edges": [dict(source=u, target=v, w=float(d["w"]), kind=d["kind"])
                      for u, v, d in G.edges(data=True)],
        }, f)
    print("exports: energy_web.gexf (Gephi), energy_web.json (Julia runtime)")

    wanted = sys.argv[1:] or list(SCENARIOS)
    kinds = list(viz.KIND_COLOR)
    matrix, scen_names = [], []
    long_rows = []
    for name in wanted:
        sc = SCENARIOS[name]
        shocks = resolve_shocks(G, sc["shocks"])
        s, fh = eng.run(shocks)
        summ = eng.layer_summary(s)
        touched = int((np.abs(s) >= 0.02).sum())
        print(f"  {name:28s} [{sc['category']:10s}] touched {touched:4d} nodes")
        title = f"{name}  ({sc['category']}): {sc['description']}"
        viz.fig_ripple(G, eng, s, shocks, title, os.path.join(OUT, f"ripple_{name}.png"))
        viz.fig_cascade(G, eng, s, fh, shocks, name, os.path.join(OUT, f"cascade_{name}.png"))
        if name in ("hormuz_closure", "texas_uri_repeat", "ttf_squeeze", "ercot_largest_trip"):
            viz.fig_wavefront(G, eng, fh, s, name, os.path.join(OUT, f"wavefront_{name}.png"))
        matrix.append([summ.get(k, {}).get("mean", 0) for k in kinds])
        scen_names.append(f"{name} [{sc['category'][0].upper()}]")
        with open(os.path.join(OUT, f"impacts_{name}.csv"), "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["node", "name", "kind", "country", "impact", "hit_round"])
            for r in eng.report(s, fh, top=150):
                w.writerow([r["id"], r["name"], r["kind"], r["country"],
                            r["impact"], r["hit_round"]])
        for r in eng.report(s, fh, top=60):
            long_rows.append([name, sc["category"], r["id"], r["name"], r["kind"],
                              r["country"], r["impact"], r["hit_round"]])

    viz.fig_scenario_matrix(np.array(matrix), scen_names, kinds,
                            os.path.join(OUT, "fig_scenario_matrix.png"))
    with open(os.path.join(OUT, "all_scenarios_long.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scenario", "category", "node", "name", "kind", "country",
                    "impact", "hit_round"])
        w.writerows(long_rows)
    print("done →", OUT)


if __name__ == "__main__":
    main()
