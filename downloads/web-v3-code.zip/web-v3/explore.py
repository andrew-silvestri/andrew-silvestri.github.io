"""
Interactive explorer — a REPL over the world energy web.

    python3 explore.py

Commands:
    find <text>                 search nodes by name/id
    shock <node_id> [mag]       stage a shock (default 0.8); repeatable
    relief <node_id> [mag]      stage a relief (negative shock)
    run                         propagate staged shocks
    scenario <name>             load + run a library scenario
    scenarios                   list library scenarios
    top [n]                     top impacted nodes of last run
    layer                       per-layer summary of last run
    trace <node_id>             strongest propagation paths from shocks to node
    plot [file]                 render ripple figure of last run
    neighbors <node_id>         what a node directly touches / is touched by
    reset                       clear staged shocks
    info                        web size stats
    quit
"""
import os, sys
import numpy as np
from energyweb.build import build
from energyweb.engine import Engine
from energyweb.scenarios import SCENARIOS, resolve_shocks
from energyweb import viz

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    print("building web ...")
    G = build(station_density=3.0, district_density=1.2)
    eng = Engine(G)
    print(f"ready: {G.number_of_nodes():,} nodes, {G.number_of_edges():,} edges, "
          f"{G.graph['n_stations']:,} stations. type 'help'.")
    staged, last = {}, None
    while True:
        try:
            line = input("web> ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not line:
            continue
        cmd, *args = line.split()
        cmd = cmd.lower()
        if cmd in ("quit", "exit", "q"):
            break
        elif cmd == "help":
            print(__doc__)
        elif cmd == "info":
            from collections import Counter
            c = Counter(d["kind"] for _, d in G.nodes(data=True))
            print(dict(c))
        elif cmd == "find":
            q = " ".join(args).lower()
            hits = [(n, d["name"]) for n, d in G.nodes(data=True)
                    if q in n.lower() or q in d["name"].lower()][:25]
            for n, nm in hits:
                print(f"  {n:34s} {nm}")
            if not hits:
                print("  no match")
        elif cmd in ("shock", "relief"):
            if not args:
                print("  usage: shock <node_id> [mag]")
                continue
            nid = args[0]
            mag = float(args[1]) if len(args) > 1 else 0.8
            if cmd == "relief":
                mag = -abs(mag)
            if nid not in G:
                print(f"  unknown node {nid} — try: find")
                continue
            staged[nid] = mag
            print(f"  staged: {nid} = {mag:+.2f}  ({len(staged)} staged)")
        elif cmd == "reset":
            staged = {}
            print("  cleared")
        elif cmd == "scenarios":
            for k, v in SCENARIOS.items():
                print(f"  {k:26s} [{v['category']:10s}] {v['description'][:70]}")
        elif cmd == "scenario":
            name = args[0] if args else ""
            if name not in SCENARIOS:
                print("  unknown — try: scenarios")
                continue
            staged = resolve_shocks(G, SCENARIOS[name]["shocks"])
            s, fh = eng.run(staged)
            last = (s, fh, dict(staged), name)
            print(f"  ran {name}: {(np.abs(s) >= 0.02).sum()} nodes touched")
        elif cmd == "run":
            if not staged:
                print("  nothing staged")
                continue
            s, fh = eng.run(staged)
            last = (s, fh, dict(staged), "custom")
            print(f"  ran custom: {(np.abs(s) >= 0.02).sum()} nodes touched")
        elif cmd == "top":
            if last is None:
                print("  run something first")
                continue
            n = int(args[0]) if args else 20
            s, fh, sh, _ = last
            for r in eng.report(s, fh, top=n, exclude_shocked=set(sh)):
                print(f"  {r['impact']:+.3f}  r{r['hit_round']:<3d} {r['kind']:10s} {r['name'][:62]}")
        elif cmd == "layer":
            if last is None:
                print("  run something first")
                continue
            for k, v in eng.layer_summary(last[0]).items():
                print(f"  {k:11s} mean {v['mean']:.4f}  max {v['max']:.3f}  "
                      f"touched {v['touched']}/{v['n']}")
        elif cmd == "trace":
            if last is None or not args:
                print("  usage (after a run): trace <node_id>")
                continue
            for wprod, path in eng.trace_paths(last[2], args[0]):
                names = " → ".join(G.nodes[p]["name"][:28] for p in path)
                print(f"  strength {wprod:.4f}: {names}")
        elif cmd == "neighbors":
            if not args or args[0] not in G:
                print("  usage: neighbors <node_id>")
                continue
            nid = args[0]
            print("  → downstream:")
            for _, v, d in sorted(G.out_edges(nid, data=True), key=lambda e: -abs(e[2]["w"]))[:12]:
                print(f"     {d['w']:+.2f} [{d['kind']}] {G.nodes[v]['name'][:56]}")
            print("  ← upstream:")
            for u, _, d in sorted(G.in_edges(nid, data=True), key=lambda e: -abs(e[2]["w"]))[:12]:
                print(f"     {d['w']:+.2f} [{d['kind']}] {G.nodes[u]['name'][:56]}")
        elif cmd == "prices":
            # prices [grid ...]  — calibrated benchmarks + merit-order deltas of last run
            if last is None:
                print("  run something first")
                continue
            from energyweb.units import PriceModel
            from energyweb.dispatch import price_deltas
            if not hasattr(main, "_pm"):
                print("  calibrating price model against anchor events ...")
                main._pm = PriceModel(eng)
            pm = main._pm
            s = last[0]
            print("  calibrated benchmarks:")
            for r in pm.table(s)[:10]:
                print(f"    {r['name']:22s} {r['base']:>8} -> {r['price']:>10} {r['unit']}")
            print("  merit-order grid deltas (real fleets):")
            grids = args if args else None
            for r in price_deltas(eng, s, pm, grids)[:12]:
                print(f"    {r['grid']:10s} ${r['base_price']:>8} -> ${r['scen_price']:>8}  "
                      f"margin {r['reserve_margin']:+.2f}  marginal={r['marginal']}")
        elif cmd == "addplant":
            # addplant <grid_id> <fuel> <GW>   e.g. addplant ERCOT nuclear 2.5
            if len(args) < 3:
                print("  usage: addplant <grid_id> <fuel> <GW>  (e.g. addplant ERCOT nuclear 2.5)")
                continue
            try:
                r = eng.intervention_add_capacity(args[0], args[1], float(args[2]))
            except Exception as e:
                print(f"  error: {e}")
                continue
            last = (r["state"], r["first_hit"], r["shocks"], f"addplant_{args[0]}_{args[1]}")
            print(f"  {r['verdict']}")
            print(f"  avg new supply {r['avg_gw']} GW | rebound {r['rebound_gw']} GW "
                  f"({r['rebound_frac']:.0%}) from {r['consumers_responding']} consumer groups")
            print(f"  displaced {r['displaced_gw']} GW of {r['displaced_fuel']} | "
                  f"CO2 {r['co2_delta_mt_per_yr']:+.2f} Mt/yr")
            print(f"  grid price relief {r['grid_price_relief']:.3f} | fuel relief "
                  f"{r['fuel_price_relief']:.3f} | markets {r['market_relief']}")
            print(f"  new mix: {r['new_mix']}")
        elif cmd == "plot":
            if last is None:
                print("  run something first")
                continue
            s, fh, sh, name = last
            path = args[0] if args else os.path.join(HERE, "outputs", f"ripple_{name}_interactive.png")
            os.makedirs(os.path.dirname(path), exist_ok=True)
            viz.fig_ripple(G, eng, s, sh, f"interactive: {name}", path)
            print(f"  wrote {path}")
        else:
            print("  unknown command — 'help'")


if __name__ == "__main__":
    main()
