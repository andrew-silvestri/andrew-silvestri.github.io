# 10 — World Energy Web (v3: granular + real data + units + dispatch)

A spider-web model of the global energy chain, now at **52,804 nodes / 222,240 edges**:
**31,416 real named power plants** (WRI Global Power Plant Database, with lat/lon),
2,974 procedural districts under every grid on Earth, 11,896 consumer groups (income ×
mentality × car-culture archetypes), 3,186 weather/cloud cells, and a Sun→insolation-belt
→cloud-cell→panel chain. Thirteen layers from the solar cycle down to a single district's
cloud cover.

## v3 upgrades (the "ladder" rungs 1–4)

1. **Units** (`energyweb/units.py`): stress→real prices, calibrated so replaying
   Uri / the 2021-22 gas crisis / the 2022 oil shock through THIS graph reproduces the
   observed peaks ($9,000 ERCOT, $90 TTF, $23 HH, $128 Brent). Any scenario then reads
   out in $/MWh, $/MMBtu, $/bbl (`prices` command). Factor-~2 error bars, documented.
2. **Real assets** (`energyweb/real_data.py` + `data/`): every plant ≥1 MW in 45
   countries is its own node — South Texas Project, W A Parish, Comanche Peak, etc. —
   geo-assigned to grids from lat/lon.
3. **Real weather grounding**: per-plant solar CF from a latitude GHI climatology,
   hurricane/typhoon-belt exposure from lat/lon boxes; ERA5/NASA-POWER loader stubs for
   full reanalysis when off-sandbox.
4. **Dispatch core** (`energyweb/dispatch.py`): merit-order clearing per grid from the
   real fleet + calibrated fuel prices → baseline vs scenario $/MWh (Uri: SPP $29→$601,
   MISO $29→$445 in the merit view; the calibrated propagation view hits the $9,000 cap).

Rung 5 (PyPSA optimization core coupled to this web) lives in folder
`11 Energy Web x PyPSA Hybrid` — this folder stays the standalone rungs-1-4 version.

## Interventions — add a nuclear plant, watch the system respond

`addplant ERCOT nuclear 2.5` in the explorer (or `Engine.intervention_add_capacity`):
propagates the new supply as price relief; consumer nodes convert relief into added
demand through elasticity × mentality (**the Jevons machinery**); reports rebound
fraction, displaced fuel, new mix, CO₂ delta, and market relief. Demo result: 2.5 GW
nuclear in ERCOT → substitution-dominated, ~7-8% rebound across ~500-800 consumer
groups, −7.7 MtCO₂/yr, relief visible at HH/TTF/JKM.

The original v1 description (still accurate for the architecture):

```
policy → chokepoints → basins → midstream → markets → national supply
                                                → stations → grids → demand
                                        weather ↗ (hits basins, terminals, grids, fleets)
```

Everything real is anchored to real entities: 9 maritime chokepoints (Hormuz, Malacca,
Suez, Bab el-Mandeb...), 38 named basins/fields (Permian → Ghawar → South Pars →
Kuzbass), 14 pipelines, 32 LNG terminals, 14 price benchmarks (Brent, TTF, JKM, HH,
Newcastle, EUA, freight...), 8 policy actors (OPEC+, SPR, sanctions regimes), 66 grids
with interties, 45 countries × 5 demand sectors, 14 macro weather systems + 198 local
weather cells (each grid gets storm/heatwave/cold-snap cells with a storm *propensity*
parameter). Station fleets are procedurally generated per grid from national fuel mixes.

## How ripples work

Stress s ∈ [0,1] per node. Each round: `s_i ← (1-λ)s_i + λ·tanh(shock_i + (1-resilience_i)·Σ w_ji s_j)`.
Signed edges: substitution (gas stress tightens coal), reroutes (Bab el-Mandeb → Cape),
relief (SPR release is negative), demand destruction (feedback from stressed industry).
`first_hit` tracks the round each node first moves — the wavefront you see in figures.

Three shock directions, as requested — all in `energyweb/scenarios.py` (20 scenarios):

- **Top-down:** `hormuz_closure` (984 nodes touched), `russia_full_cutoff` (946),
  `gulf_major_hurricane` (622), `texas_uri_repeat` (268), `european_wind_drought` (462)
- **Middle-out:** `ttf_squeeze` (447), `jkm_bidding_war` (1,019 — the biggest cascade in
  the library), `coal_export_ban` (581), `carbon_price_doubling` (123)
- **Bottom-up:** `ercot_largest_trip` (7), `freeport_explosion` (63),
  `colonial_cyberattack` (23) — single-asset shocks stay local *by design* (reserve
  margins absorb them). Stack them on a stressed system in the explorer and watch the
  compounding: hormuz + heat dome + unit trip pushed ERCOT's fleet from 212 to 657
  stations touched in testing.
- **Relief:** `spr_release` runs Hormuz *with* SPR+IEA action for the counterfactual.

## How to interact (no HTML anywhere)

1. **REPL explorer** — `python3 explore.py` →
   `find hormuz` · `scenario hormuz_closure` · `top 20` · `layer` · `prices` (calibrated
   benchmarks + merit-order grid deltas) · `addplant ERCOT nuclear 2.5` (intervention) ·
   `trace ERCOT` · `neighbors MKT_TTF` · shock stacking with `shock`/`relief`/`run` · `plot`
2. **Gephi** — open `outputs/energy_web.gexf` in [Gephi](https://gephi.org) (free
   desktop app): force-atlas layout, color by `kind`, size by `size`, and fly through
   the whole web interactively. This is the best way to *feel* the scale.
3. **Julia** — `julia/engine.jl` loads `outputs/energy_web.json` and runs the identical
   propagation (`Pkg.instantiate()`, then `include("engine.jl")`). Untested in this
   sandbox (Julia blocked), mirrors the verified Python engine op-for-op.
4. **Excel** — `energy_web_results.xlsx`: full 4,265-node registry, 1,200-row scenario
   impact table, live formula summary.

## Files

| | |
|---|---|
| `energyweb/world_data.py` | All editable data tables — add a country, basin, or chokepoint and rebuild |
| `energyweb/build.py` | Graph assembly + procedural fleets/weather cells |
| `energyweb/engine.py` | Vectorized propagation, reports, path tracing |
| `energyweb/scenarios.py` | 20-scenario library incl. placeholder resolvers (`__LARGEST_STATION_ERCOT__`) |
| `energyweb/viz.py` | Layered web renderings |
| `run_all.py` / `explore.py` | Batch runner / interactive REPL |
| `outputs/` | fig0 full-web overview · per-scenario `ripple_*` + `cascade_*` + `wavefront_*` PNGs · scenario matrix · impact CSVs · GEXF/JSON exports |

## Honest limitations

Weights are structural estimates (traceable in `world_data.py`/`build.py`), not fitted
elasticities — the model is for *topology of contagion*, not price forecasting. Stress is
unitless; there's no clearing, storage dynamics, or time-of-year seasonality. Each is a
clean extension: the roadmap move is calibrating market-layer edges against 2021–22
TTF/JKM history and Uri.
