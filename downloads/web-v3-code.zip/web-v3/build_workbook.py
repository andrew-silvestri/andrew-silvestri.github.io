"""Builds energy_web_results.xlsx: node registry + all-scenario impacts + live summary."""
import openpyxl
from openpyxl.styles import Font, PatternFill
import csv, os
from energyweb.build import build

HERE = os.path.dirname(os.path.abspath(__file__))
A = "Arial"
BOLD = Font(name=A, bold=True)
H1 = Font(name=A, bold=True, size=13)
GRAY = PatternFill("solid", fgColor="DDDDDD")

wb = openpyxl.Workbook()

# ---------------- node registry
G = build(station_density=2.0)
ws = wb.active
ws.title = "Nodes"
hdr = ["id", "name", "kind", "layer", "country", "region", "size", "resilience"]
for j, h in enumerate(hdr, 1):
    c = ws.cell(row=1, column=j, value=h)
    c.font = BOLD
    c.fill = GRAY
for i, (n, d) in enumerate(sorted(G.nodes(data=True), key=lambda t: (t[1]["layer"], t[0])), start=2):
    for j, v in enumerate([n, d["name"], d["kind"], d["layer"], d.get("country", ""),
                           d.get("region", ""), round(float(d.get("size", 1)), 3),
                           d.get("resilience", 0.35)], start=1):
        ws.cell(row=i, column=j, value=v).font = Font(name=A, size=9)
nrows = i
for col, w in zip("ABCDEFGH", (30, 52, 11, 6, 8, 13, 8, 10)):
    ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"

# ---------------- scenario impacts (long)
imp = wb.create_sheet("Impacts")
with open(os.path.join(HERE, "outputs", "all_scenarios_long.csv")) as f:
    for i, row in enumerate(csv.reader(f), start=1):
        for j, v in enumerate(row, start=1):
            try:
                v = float(v) if j in (7, 8) and i > 1 else v
            except ValueError:
                pass
            c = imp.cell(row=i, column=j, value=v)
            c.font = Font(name=A, size=9, bold=(i == 1))
            if i == 1:
                c.fill = GRAY
irows = i
for col, w in zip("ABCDEFGH", (24, 11, 26, 48, 11, 8, 9, 9)):
    imp.column_dimensions[col].width = w
imp.freeze_panes = "A2"

# ---------------- live summary
s = wb.create_sheet("Summary")
s["A1"] = "World Energy Web — scenario summary (formulas over Impacts sheet)"
s["A1"].font = H1
s["A3"], s["B3"], s["C3"], s["D3"] = "Scenario", "Mean |impact| (top-60)", "Max impact", "Rows"
for cell in ("A3", "B3", "C3", "D3"):
    s[cell].font = BOLD
    s[cell].fill = GRAY
scens = []
with open(os.path.join(HERE, "outputs", "all_scenarios_long.csv")) as f:
    next(f)
    for row in csv.reader(f):
        if row and row[0] not in scens:
            scens.append(row[0])
R = f"Impacts!$A$2:$A${irows}"
V = f"Impacts!$G$2:$G${irows}"
for i, sc in enumerate(scens, start=4):
    s.cell(row=i, column=1, value=sc).font = Font(name=A)
    s.cell(row=i, column=2, value=f'=ROUND(AVERAGEIFS({V},{R},"{sc}"),4)').font = Font(name=A)
    s.cell(row=i, column=3, value=f'=ROUND(_xlfn.MAXIFS({V},{R},"{sc}"),4)').font = Font(name=A)
    s.cell(row=i, column=4, value=f'=COUNTIF({R},"{sc}")').font = Font(name=A)
last = i
s.cell(row=last + 2, column=1, value="Total nodes / edges / stations").font = BOLD
s.cell(row=last + 2, column=2,
       value=f"{G.number_of_nodes()} / {G.number_of_edges()} / {G.graph['n_stations']}").font = Font(name=A)
for col, w in zip("ABCD", (26, 20, 12, 8)):
    s.column_dimensions[col].width = w

wb.save(os.path.join(HERE, "energy_web_results.xlsx"))
print("wrote energy_web_results.xlsx  nodes-rows:", nrows, " impact-rows:", irows)
