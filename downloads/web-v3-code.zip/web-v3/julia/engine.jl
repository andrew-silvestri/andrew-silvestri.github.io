# World Energy Web — Julia runtime
# Reads ../outputs/energy_web.json (written by run_all.py) and runs the same
# damped stress propagation as energyweb/engine.py.
#
#   julia> using Pkg; Pkg.activate("."); Pkg.instantiate()
#   julia> include("engine.jl")
#   julia> web = load_web();
#   julia> s, fh = propagate(web, Dict("CHK_HORMUZ" => 1.0));
#   julia> report(web, s, fh)
#
# Untested in the build sandbox (Julia unavailable there); mirrors the verified
# Python engine operation-for-operation.

using JSON, Printf

struct Web
    ids::Vector{String}
    names::Vector{String}
    kinds::Vector{String}
    res::Vector{Float64}
    rows::Vector{Int}
    cols::Vector{Int}
    ws::Vector{Float64}
    idx::Dict{String,Int}
end

function load_web(path = joinpath(@__DIR__, "..", "outputs", "energy_web.json"))
    d = JSON.parsefile(path)
    ids = String[n["id"] for n in d["nodes"]]
    idx = Dict(id => i for (i, id) in enumerate(ids))
    Web(ids,
        String[n["name"] for n in d["nodes"]],
        String[n["kind"] for n in d["nodes"]],
        Float64[n["resilience"] for n in d["nodes"]],
        Int[idx[e["target"]] for e in d["edges"]],
        Int[idx[e["source"]] for e in d["edges"]],
        Float64[e["w"] for e in d["edges"]],
        idx)
end

function propagate(web::Web, shocks::Dict{String,<:Real};
                   rounds = 60, lam = 0.55, thresh = 0.02)
    n = length(web.ids)
    b = zeros(n)
    for (k, v) in shocks
        haskey(web.idx, k) && (b[web.idx[k]] = v)
    end
    s = copy(b)
    fh = fill(-1, n)
    fh[abs.(s) .>= thresh] .= 0
    for r in 1:rounds
        inflow = zeros(n)
        @inbounds for e in eachindex(web.ws)
            inflow[web.rows[e]] += web.ws[e] * s[web.cols[e]]
        end
        target = tanh.(b .+ (1 .- web.res) .* inflow)
        s_new = (1 - lam) .* s .+ lam .* target
        @inbounds for i in 1:n
            fh[i] < 0 && abs(s_new[i]) >= thresh && (fh[i] = r)
        end
        maximum(abs.(s_new .- s)) < 1e-5 && (s = s_new; break)
        s = s_new
    end
    clamp.(s, -1, 1), fh
end

function report(web::Web, s, fh; top = 25)
    order = sortperm(abs.(s); rev = true)
    shown = 0
    for i in order
        @printf "%+.3f  r%-3d %-10s %s\n" s[i] fh[i] web.kinds[i] first(web.names[i], 60)
        (shown += 1) >= top && break
    end
end

function layer_summary(web::Web, s)
    acc = Dict{String,Vector{Float64}}()
    for (i, k) in enumerate(web.kinds)
        push!(get!(acc, k, Float64[]), abs(s[i]))
    end
    for (k, v) in sort(collect(acc))
        @printf "%-11s mean %.4f  max %.3f  touched %d/%d\n" k sum(v)/length(v) maximum(v) count(>=(0.02), v) length(v)
    end
end

if abspath(PROGRAM_FILE) == @__FILE__
    web = load_web()
    println("nodes: ", length(web.ids), "  edges: ", length(web.ws))
    s, fh = propagate(web, Dict("CHK_HORMUZ" => 1.0))
    report(web, s, fh; top = 15)
    layer_summary(web, s)
end
