"""
v5 spine: loads energy_ghg_driver_taxonomy.xlsx (the user's 32-sheet, ~1,900-row
driver taxonomy) and turns every driver row into a model node.

Row semantics -> model parameters:
  Leverage  -> edge weight   (Foundational .6, Very high .5, High .35, Medium .2, Low .1)
  Timescale -> resilience/inertia (Instant .08 ... Centuries .9)
  Direction -> edge sign     (Increases +, Decreases -, Either + with flag)

Edit the spreadsheet, rebuild, and the web regrows. That's the point.
"""
import os
import openpyxl

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
XLSX = os.path.join(PARENT, "energy_ghg_driver_taxonomy.xlsx")

LEVERAGE_W = {"foundational": 0.60, "very high": 0.50, "high": 0.35,
              "medium": 0.20, "moderate": 0.20, "low": 0.10}
TIMESCALE_R = [("instant", 0.08), ("hour", 0.10), ("day", 0.15), ("week", 0.2),
               ("purchase", 0.3), ("month", 0.3), ("season", 0.35), ("year", 0.45),
               ("decade", 0.65), ("generation", 0.8), ("centur", 0.9)]


def _lev(x):
    return LEVERAGE_W.get(str(x or "").strip().lower(), 0.2)


def _res(x):
    s = str(x or "").lower()
    for key, v in TIMESCALE_R:
        if key in s:
            return v
    return 0.4


def _sign(x):
    s = str(x or "").lower()
    if "decrease" in s:
        return -1.0
    return 1.0


def load_taxonomy(path=XLSX):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    sheets, drivers = [], []
    for sn in wb.sheetnames:
        if sn.startswith("00"):
            continue
        num = sn.split()[0]
        ws = wb[sn]
        rows = [r for r in ws.iter_rows(values_only=True)]
        # find header row (starts with '#')
        h = next((i for i, r in enumerate(rows) if r and str(r[0]).strip() == "#"), None)
        sheet = dict(num=num, name=sn, drivers=[])
        if sn.startswith("22"):                      # country-profile sheet
            for r in rows[(h or 0) + 1:]:
                if not r or r[1] is None:
                    continue
                sheet["drivers"].append(dict(
                    n=str(r[0]), name=str(r[1]), mechanism=str(r[4] or ""),
                    direction="Either", leverage="High", timescale="Years",
                    metric=str(r[6] or ""), w=0.35, res=0.45, sign=1.0,
                    country=str(r[1])))
        elif h is not None:
            for r in rows[h + 1:]:
                if not r or r[1] is None:
                    continue
                sheet["drivers"].append(dict(
                    n=str(r[0]), name=str(r[1])[:80], mechanism=str(r[2] or "")[:200],
                    direction=str(r[3] or ""), leverage=str(r[4] or ""),
                    timescale=str(r[5] or ""), metric=str(r[6] or "")[:80],
                    w=_lev(r[4]), res=_res(r[5]), sign=_sign(r[3])))
        sheets.append(sheet)
        drivers.extend(sheet["drivers"])
    return sheets


if __name__ == "__main__":
    sh = load_taxonomy()
    n = sum(len(s["drivers"]) for s in sh)
    print(f"{len(sh)} sheets, {n} drivers")
    for s in sh[:3]:
        print(" ", s["name"], len(s["drivers"]), "->",
              s["drivers"][0]["name"] if s["drivers"] else "-")
