# v5 driver-subweb engine — Julia runtime
# Reads ../outputs/driver_subweb.json (taxonomy drivers + hubs + anchors) and runs
# the same damped propagation as the Python Engine4. Full ~1M-node web stays in
# Python (array-native); this gives you the taxonomy cortex in Julia.
#   julia> using Pkg; Pkg.activate("."); Pkg.instantiate(); include("engine.jl")
# Untested in the build sandbox (Julia unavailable); mirrors the verified engine.

using JSON, Printf

function load_subweb(path = joinpath(@__DIR__, "..", "outputs", "driver_subweb.json"))
    d = JSON.parsefile(path)
    ids = [n["id"] for n in d["nodes"]]
    idx = Dict(id => i for (i, id) in enumerate(ids))
    names = [n["name"] for n in d["nodes"]]
    kinds = [n["kind"] for n in d["nodes"]]
    res = Float64[n["res"] for n in d["nodes"]]
    rows = Int[]; cols = Int[]; ws = Float64[]
    for e in d["edges"]
        haskey(idx, e["source"]) && haskey(idx, e["target"]) || continue
        push!(cols, idx[e["source"]]); push!(rows, idx[e["target"]]); push!(ws, e["w"])
    end
    (; ids, idx, names, kinds, res, rows, cols, ws)
end

function propagate(web, shocks::Dict{Int,<:Real}; rounds=60, lam=0.55)
    n = length(web.ids)
    b = zeros(n)
    for (k, v) in shocks
        haskey(web.idx, k) && (b[web.idx[k]] = v)
    end
    s = copy(b)
    for _ in 1:rounds
        inflow = zeros(n)
        @inbounds for e in eachindex(web.ws)
            inflow[web.rows[e]] += web.ws[e] * s[web.cols[e]]
        end
        s_new = (1 - lam) .* s .+ lam .* tanh.(b .+ (1 .- web.res) .* inflow)
        maximum(abs.(s_new .- s)) < 1e-5 && (s = s_new; break)
        s = s_new
    end
    clamp.(s, -1, 1)
end

function top(web, s; k=20)
    for i in sortperm(abs.(s); rev=true)[1:k]
        @printf "%+.3f  %-9s %s\n" s[i] web.kinds[i] first(web.names[i], 62)
    end
end

if abspath(PROGRAM_FILE) == @__FILE__
    web = load_subweb()
    println("subweb: ", length(web.ids), " nodes, ", length(web.ws), " edges")
    # shock the first 'driver' node found (swap in any node id from the JSON)
    di = findfirst(==("driver"), web.kinds)
    s = propagate(web, Dict(web.ids[di] => 0.9))
    println("shocked: ", web.names[di])
    top(web, s)
end
