"""Exports the curated multi-scale slice of the v5 web for the zoom explorer:
7 levels, Sun -> Earth system -> world fuel/geopolitics -> grids -> ERCOT region
-> community cohorts -> the mind. Every included node carries a description
(taxonomy mechanism text where a matching driver row exists)."""
import sys, os, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "13 World Energy Web v4"))
sys.path.insert(0, HERE)
from build5 import build_v5, KINDS

LEVELS = ["Sun & Cosmos", "Earth System", "World Fuel & Geopolitics",
          "Grids & Nations", "Region: ERCOT", "Community", "The Mind"]

# bespoke prose for marquee nodes (matched by core id or name substring)
PROSE = {
    "SUN": "Everything below this point is a footnote to a fusion reactor ninety-three million miles away. Its output varies by a tenth of a percent across an eleven-year cycle — small, until you own a terawatt of glass angled at it.",
    "CHK_HORMUZ": "Twenty-one miles of navigable water between Iran and Oman, through which a fifth of everything that burns must pass. No single geography carries more leverage per kilometer; every tanker war, sanction regime, and insurance premium in the Gulf prices this strait first.",
    "MKT_BRENT": "The world's oil clock. Brent is less a place than an agreement — a North Sea blend whose price is the reference gravity for two-thirds of global crude. When it moves, import bills, airline fares, and fertilizer contracts move within the week.",
    "MKT_TTF": "A virtual trading point on the Dutch gas network that became, in 2022, the fever chart of European industry. At €340 per megawatt-hour it idled smelters, shuttered greenhouses, and rewrote a continent's energy politics in a single season.",
    "MKT_JKM": "The Japan-Korea Marker prices spot LNG for Asia — the bid that decides which continent a cargo sails toward. In a tight year, JKM is the auctioneer of the world's marginal molecule.",
    "MKT_HH": "Henry Hub, Louisiana: a physical junction of thirteen pipelines that lends its name to the price of American gas. Shale kept it cheap for fifteen years; every LNG terminal built since is an arbitrage against it.",
    "ERCOT": "The Texas interconnection — an island grid by political choice, settling its own scarcity at prices that can touch $9,000 a megawatt-hour. February 2021 showed what four cold days can do to an island.",
    "POL_OPEC": "A cartel's standing meeting: a dozen ministries deciding, quarter by quarter, whether the marginal barrel exists. Its communiqués move more energy than most power plants produce.",
    "CLIMATE_SYS": "The slow variable under everything: an ocean-atmosphere system integrating two centuries of combustion. It does not negotiate, and its feedback loops — ice, vapor, carbon — run on their own clock.",
    "GLOBAL_TEMP": "The single number the whole system is unintentionally optimizing. Every node in this web pushes it, and it pushes back through every weather layer above.",
    "AI_DEMAND": "The demand story of the decade: compute. After fifteen years of efficiency holding datacenter power flat, training runs broke the truce — load growth has returned to grids that had forgotten it.",
    "BAS_GHAWAR": "The largest conventional oil field ever found, producing since 1951. Ghawar is the quiet constant of the oil age; its decline rate is one of the most consequential unpublished numbers on Earth.",
    "BAS_PERMIAN": "West Texas shale: the swing producer that ended OPEC's monopoly on the margin. Its rigs respond to price in months, not decades — the cobweb theorem with a drill bit.",
    "FERT_MARKET": "Where natural gas becomes bread. Half the nitrogen in your body passed through a Haber-Bosch reactor; when gas spikes, this market decides which hemisphere's farmers skip a season.",
    "GRAIN_MARKET": "The last stop of the energy system before it becomes dinner. Grain prices carry gas prices, diesel prices, and drought — and they are the oldest political commodity there is.",
    "PSYCH HUB: dissonance": "Festinger's engine: the tension of a green conscience in a heavy car. It accumulates quietly under sustained price stress and discharges suddenly — as an EV purchase, a diet change, a vote. Crises change habits; blips never do.",
    "PSYCH HUB: habit": "Seventy percent of energy use is nobody deciding anything. Habit is the system's damping term — the reason short-run elasticities are tiny and revolutions in demand take a decade.",
    "PSYCH HUB: loss_aversion": "Kahneman and Tversky's asymmetry: a price rise wounds roughly twice as much as the equivalent saving pleases. It is why gas lines form, why hoarding happens, and why relief never feels like the shock did.",
    "PSYCH HUB: present_bias": "The efficiency gap made flesh: households discounting tomorrow at twenty percent while mortgages price at five. Positive-NPV insulation dies here, quietly, every year.",
    "WX_GULF_HURR": "The hurricane alley that runs through the heart of American energy: offshore platforms, LNG terminals, and refinery row all share a coastline with the season.",
    "WX_TX_FREEZE": "The Uri pattern: Arctic air over unwinterized infrastructure. Wellheads freeze, plants trip, demand spikes — supply and demand fail in the same hour, which is the definition of a grid emergency.",
}

DESC_BY_KIND = {
    "chokepoint": "Maritime chokepoint: a narrow sea lane carrying a share of global oil/LNG/coal trade. Closure reroutes or strands flows.",
    "basin": "Upstream production basin/field: supply loss here propagates into benchmark prices and national fuel supplies.",
    "market": "Price benchmark: the system's broadcast tower — stress here transmits to every consumer of the commodity.",
    "grid": "Synchronous power system: balances its fleet against demand every second; scarcity prices are set here.",
    "supply": "National fuel supply: the mixing point of domestic production, imports, and world prices for one country and fuel.",
    "policy": "Policy actor: OPEC+ decisions, strategic reserves, sanctions — discretionary shocks and reliefs.",
    "midstream": "Midstream asset: pipeline or LNG terminal; a physical bottleneck between basins and markets.",
    "weather": "Weather system: a realized event pattern hitting fleets, basins, and demand simultaneously.",
    "sun": "Solar/irradiance layer: the ultimate energy input; variability cascades through every solar panel downstream.",
    "station": "Generation station (real unit, WRI database): capacity, fuel, and grid assignment from the record.",
    "district": "Sub-grid district: a procedurally scaled slice of a grid's demand with its own weather cell and cohorts.",
    "consumer": "Consumer group: income x mentality archetype with elasticity — where price becomes behavior.",
    "sector": "Demand sector: aggregate residential/commercial/industrial/transport load of a grid.",
    "household": "Household income-decile cohort: decile-specific price elasticity and weather exposure.",
    "car": "Vehicle cohort: model-year x fuel x class chunk of the fleet with era-correct efficiency.",
    "transit": "Transit cohort: rail commuters (grid-fed), bus riders, air travelers (jet-fuel-fed).",
    "farm": "Farm: nitrogen fertilizer demand fed by gas -> Haber-Bosch -> fertilizer market (cobweb-lagged).",
    "diet": "Diet cohort: meat intensity couples food energy/land footprint to the grain market.",
    "datacenter": "Datacenter: conventional or AI-era; the load-growth story of the 2020s.",
    "climate_cell": "District climate-anomaly cell: local expression of the global climate system.",
    "psych": "Unconscious-mind node: a district's behavioral substrate (habit, loss aversion, dissonance...).",
    "psych_hub": "Global psychological channel: broadcasts one bias into every district's consumers.",
    "chain": "Global chain node: ammonia complexes, fertilizer/grain markets, climate system, AI demand.",
    "tax_hub": "Taxonomy sheet hub: the two-way port between a driver sheet and its node family.",
    "driver": "Taxonomy driver row: a single row of energy_ghg_driver_taxonomy.xlsx, live in the model.",
}


def main():
    w = build_v5(verbose=False)
    idx = w.idx
    drv_by_kw = {d["name"].lower(): d for d in w.drivers}

    picks = []  # (array_index, level)
    def add(i, lvl):
        if i is not None:
            picks.append((int(i), lvl))

    for nid, i in idx.items():
        kk = w.core_kinds[i]
        if kk == "sun":
            add(i, 0)
        elif nid.startswith("WX_"):
            add(i, 1)
        elif kk in ("chokepoint", "basin", "market", "policy", "midstream"):
            add(i, 2)
        elif kk in ("grid",) or (kk == "supply"):
            add(i, 3)
        elif kk == "district" and nid.startswith("DIS_ERCOT"):
            add(i, 4)
        elif kk == "sector" and "_ERCOT_" in nid:
            add(i, 4)
        elif kk == "consumer" and nid.startswith("CON_DIS_ERCOT_00"):
            add(i, 5)
    # chain nodes
    for j, c in enumerate(["AMMONIA_USGULF", "AMMONIA_EUROPE", "FERT_MARKET",
                           "GRAIN_MARKET", "CLIMATE_SYS", "GLOBAL_TEMP", "AI_DEMAND"]):
        from v4.build4 import CHAIN
        add(w.n_core + CHAIN.index(c), 1 if "CLIMATE" in c or "TEMP" in c else 2)
    # ERCOT real stations: top 25 by capacity
    st = [(w.size[i], i) for nid, i in idx.items()
          if w.core_kinds[i] == "station" and nid.startswith("ST_")
          and "ERCOT" in str(w.core_names[i][:0]) ]  # names lack grid; use decode below
    st = []
    for nid, i in idx.items():
        if w.core_kinds[i] == "station":
            # grid attr lost in arrays; approximate: US stations near ERCOT via name in fig? skip
            pass
    # instead: stations that feed ERCOT = predecessors via edges
    er = idx["ERCOT"]
    srcs, dsts, wws = w.edges
    feeders = srcs[(dsts == er)]
    st_idx = [int(i) for i in feeders if w.kind[i] == 0 and w.core_kinds[i] == "station"]
    st_idx.sort(key=lambda i: -float(w.size[i]))
    for i in st_idx[:25]:
        add(i, 4)
    # community cohorts of 3 ERCOT districts (district ordinals 0-2)
    kmap = {k: j for j, k in enumerate(KINDS)}
    for kname, lvl, cap in [("household", 5, 30), ("diet", 5, 12), ("transit", 5, 9),
                            ("farm", 5, 15), ("datacenter", 5, 6), ("car", 5, 24),
                            ("climate_cell", 5, 3), ("psych", 6, 18)]:
        ids = np.where(w.kind == kmap[kname])[0]
        ids = [int(i) for i in ids if 0 <= w.district[i] <= 2]
        for i in ids[:cap]:
            add(i, lvl)
    # psych hubs + neuro drivers + a few other drivers/hubs
    for i, name in w.v5_names.items():
        if name.startswith("PSYCH HUB"):
            add(i, 6)
        elif name.startswith("[06:"):
            add(i, 6)
        elif name.startswith("[31:") or name.startswith("[01:"):
            add(i, 1)
        elif name.startswith("[29:") or name.startswith("[23:"):
            add(i, 2)
        elif name.startswith("[07:") and int(name.split(":")[1].split("]")[0]) <= 8:
            add(i, 5)

    # ---------------- all 20 scenarios from folder 10 as runnable presets:
    # ensure every shock-target node is in the slice, then export shock dicts
    sys.path.insert(0, os.path.join(os.path.dirname(HERE), "10 World Energy Web"))
    from energyweb.scenarios import SCENARIOS
    LEVEL_OF_KIND = dict(sun=0, weather=1, chokepoint=2, basin=2, market=2,
                         policy=2, midstream=2, grid=3, supply=3, district=4,
                         sector=4, station=4, consumer=5)
    scen_shocks = {}
    for sname, sc in SCENARIOS.items():
        resolved = {}
        for key, mag in sc["shocks"].items():
            targets = []
            if key == "__LARGEST_STATION_ERCOT__" and st_idx:
                targets = [st_idx[0]]
            elif key == "__LARGEST_STATION_ERCOT_nuclear__":
                nuc = [i for i in st_idx if w.core_fuels[i] == "nuclear"]
                targets = nuc[:1] or st_idx[:1]
            elif key == "__STATIONS_DE_gas_5__":
                de = sorted([i for nid, i in idx.items() if w.core_kinds[i] == "station"
                             and w.core_countries[i] == "DE" and w.core_fuels[i] == "gas"],
                            key=lambda i: -float(w.size[i]))[:5]
                targets = de
            elif key == "__CONSUMERS_US_20__":
                us = sorted([i for nid, i in idx.items() if w.core_kinds[i] == "consumer"
                             and w.core_countries[i] == "US"],
                            key=lambda i: -float(w.size[i]))[:20]
                targets = us
            elif key in idx:
                targets = [idx[key]]
            for t in targets:
                kk = w.core_kinds[t] if t < w.n_core else "chain"
                picks.append((int(t), LEVEL_OF_KIND.get(kk, 2)))
                resolved[int(t)] = mag
        if resolved:
            scen_shocks[sname] = dict(shocks=resolved, desc=sc["description"],
                                      category=sc["category"])

    seen = {}
    for i, lvl in picks:
        seen.setdefault(i, lvl)
    keep = np.array(sorted(seen), dtype=np.int64)
    karr = np.zeros(len(w.kind), dtype=bool); karr[keep] = True
    m = karr[srcs] & karr[dsts]
    remap = {int(i): j for j, i in enumerate(keep)}

    rev = {j: nid for nid, j in idx.items()}
    nodes = []
    for i in keep:
        i = int(i)
        kname = w.core_kinds[i] if i < w.n_core else KINDS[w.kind[i]]
        name = w.decode_name(i)
        desc = DESC_BY_KIND.get(kname, "")
        if kname == "driver":
            key = name.split("] ", 1)[-1].lower()
            d = drv_by_kw.get(key)
            if d:
                desc = f"{d['mechanism']} — leverage {d['leverage']}, timescale {d['timescale']}. Metric: {d['metric']}"
        # bespoke prose overrides
        nid_str = rev.get(i, "")
        if nid_str in PROSE:
            desc = PROSE[nid_str]
        elif name in PROSE:
            desc = PROSE[name]
        nodes.append(dict(i=remap[i], level=seen[i], kind=kname,
                          name=name[:90], desc=desc, res=float(w.res[i])))
    edges = [dict(s=remap[int(a)], t=remap[int(b)], w=round(float(c), 4))
             for a, b, c in zip(srcs[m], dsts[m], wws[m])]
    # presets: ALL scenarios from folder 10, remapped into slice indices
    from v4.build4 import CHAIN as CH
    presets = {}
    for sname, sc in scen_shocks.items():
        sh = {remap[t]: mag for t, mag in sc["shocks"].items() if t in remap}
        if sh:
            presets[sname] = dict(shocks=sh, desc=sc["desc"], category=sc["category"])
    presets["climate_system_forcing"] = dict(
        shocks={remap[w.n_core + CH.index("CLIMATE_SYS")]: 0.8},
        desc="Accelerating climate-system anomaly forcing every weather layer below.",
        category="top-down")
    presets["dim_solar_cycle"] = dict(
        shocks={remap[idx["SUN"]]: 0.6},
        desc="Prolonged irradiance anomaly cascading through every solar panel on Earth.",
        category="top-down")
    data = dict(levels=LEVELS, nodes=nodes, edges=edges, presets=presets)
    out = os.path.join(HERE, "outputs", "zoom_data.json")
    json.dump(data, open(out, "w"))
    print(f"zoom slice: {len(nodes)} nodes, {len(edges)} edges -> {out}")
    from collections import Counter
    print(Counter(n["level"] for n in nodes))


if __name__ == "__main__":
    main()
