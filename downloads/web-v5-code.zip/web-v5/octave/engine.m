% v5 driver-subweb engine — MATLAB/GNU Octave runtime
% Reads ../outputs/driver_subweb.json via jsondecode (Octave >= 7 / any MATLAB).
% Same damped propagation as the Python Engine4; taxonomy cortex scale.
% Run: octave engine.m

d = jsondecode(fileread(fullfile(fileparts(mfilename("fullpath")), "..", "outputs", "driver_subweb.json")));
ids = [d.nodes.id];
n = numel(ids);
idx = containers.Map(num2cell(ids), num2cell(1:n));
res = [d.nodes.res]';
srcs = zeros(numel(d.edges),1); dsts = srcs; ws = srcs;
kept = 0;
for e = 1:numel(d.edges)
  if isKey(idx, d.edges(e).source) && isKey(idx, d.edges(e).target)
    kept = kept + 1;
    srcs(kept) = idx(d.edges(e).source);
    dsts(kept) = idx(d.edges(e).target);
    ws(kept) = d.edges(e).w;
  end
end
W = sparse(dsts(1:kept), srcs(1:kept), ws(1:kept), n, n);
printf("subweb: %d nodes, %d edges\n", n, kept);

% shock the first driver node
kinds = {d.nodes.kind};
di = find(strcmp(kinds, "driver"), 1);
b = zeros(n,1); b(di) = 0.9;
s = b; lam = 0.55;
for r = 1:60
  s_new = (1-lam)*s + lam*tanh(b + (1-res).*(W*s));
  if max(abs(s_new - s)) < 1e-5, s = s_new; break; end
  s = s_new;
end
printf("shocked: %s\n", d.nodes(di).name);
[~, order] = sort(abs(s), "descend");
for i = order(1:15)'
  printf("%+.3f  %-9s %s\n", s(i), kinds{i}, d.nodes(i).name(1:min(60,end)));
end
