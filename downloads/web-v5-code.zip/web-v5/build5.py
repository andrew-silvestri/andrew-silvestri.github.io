"""
v5 = v4 mega-web + the taxonomy driver cortex.

Appends to the v4 arrays: 32 sheet-hub nodes, 6 global psych hubs, and one node
per taxonomy driver row (~1,900). Each driver wires: driver -> its sheet hub
(w = leverage), and each hub broadcasts into its mapped v4 node family with
per-family normalized weights. Neuro drivers route keyword-matched into the six
psych hubs, which fan out to every district's unconscious-mind nodes. Country
rows link to their national supply nodes. Cross-scale feedback rows couple into
the climate system with the row's sign.
"""
import sys, os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PARENT, "13 World Energy Web v4"))
sys.path.insert(0, HERE)

from v4.build4 import build_v4, KINDS as K4, KIND_CODE as KC4, CHAIN
from taxonomy_loader import load_taxonomy

KINDS = K4 + ["tax_hub", "driver", "psych_hub"]
KIND_CODE = {k: i for i, k in enumerate(KINDS)}
PSYCH_KEYS = [("discount", 5), ("present", 5), ("loss", 1), ("prospect", 1),
              ("default", 0), ("status quo", 0), ("habit", 0), ("dissonance", 3),
              ("norm", 4), ("social", 4), ("identity", 2), ("status", 2),
              ("signal", 2)]
COUNTRY_CC = {"China": "CN", "United States": "US", "India": "IN", "Russia": "RU",
              "Japan": "JP", "Germany": "DE", "Brazil": "BR", "Canada": "CA",
              "South Korea": "KR", "Saudi Arabia": "SA", "Australia": "AU",
              "Mexico": "MX", "Indonesia": "ID", "United Kingdom": "GB",
              "France": "FR", "Italy": "IT", "Turkey": "TR", "Poland": "PL",
              "Spain": "ES", "Netherlands": "NL", "Argentina": "AR", "Egypt": "EG",
              "Nigeria": "NG", "South Africa": "ZA", "Ukraine": "UA",
              "Kazakhstan": "KZ", "Iran": "IR", "Iraq": "IQ", "Qatar": "QA",
              "Kuwait": "KW", "Israel": "IL", "Algeria": "DZ", "Libya": "LY",
              "Norway": "NO", "Sweden": "SE", "Chile": "CL", "Colombia": "CO",
              "Malaysia": "MY", "Vietnam": "VN", "Thailand": "TH",
              "Pakistan": "PK", "Bangladesh": "BD", "New Zealand": "NZ",
              "Taiwan": "TW", "United Arab Emirates": "AE"}


def _family(w, sel):
    """Node-index arrays for named v4 families."""
    k = w.kind
    if sel == "households": return np.where(k == KC4["household"])[0]
    if sel == "cars": return np.where(k == KC4["car"])[0]
    if sel == "transit": return np.where(k == KC4["transit"])[0]
    if sel == "farms": return np.where(k == KC4["farm"])[0]
    if sel == "diets": return np.where(k == KC4["diet"])[0]
    if sel == "datacenters": return np.where(k == KC4["datacenter"])[0]
    if sel == "climate_cells": return np.where(k == KC4["climate_cell"])[0]
    if sel == "psych": return np.where(k == KC4["psych"])[0]
    # core selections by id prefix / kind string
    ids = []
    for nid, i in w.idx.items():
        kk = w.core_kinds[i]
        if sel == "grids" and kk == "grid": ids.append(i)
        elif sel == "districts" and kk == "district": ids.append(i)
        elif sel == "markets" and kk == "market": ids.append(i)
        elif sel == "basins" and kk == "basin": ids.append(i)
        elif sel == "midstream" and kk == "midstream": ids.append(i)
        elif sel == "chokepoints" and kk == "chokepoint": ids.append(i)
        elif sel == "policy" and kk == "policy": ids.append(i)
        elif sel == "weather" and nid.startswith("WX_"): ids.append(i)
        elif sel == "sun" and kk == "sun": ids.append(i)
        elif sel == "consumers" and kk == "consumer": ids.append(i)
        elif sel == "industrial" and nid.startswith("DEM_") and nid.endswith("_industrial"): ids.append(i)
        elif sel == "buildings" and nid.startswith("DEM_") and (nid.endswith("_residential") or nid.endswith("_commercial")): ids.append(i)
        elif sel == "commercial" and nid.startswith("DEM_") and nid.endswith("_commercial"): ids.append(i)
        elif sel == "clean_stations" and kk == "station" and w.core_fuels[i] in ("solar", "wind", "nuclear", "hydro"): ids.append(i)
        elif sel == "fossil_stations" and kk == "station" and w.core_fuels[i] in ("coal", "gas", "oil"): ids.append(i)
    return np.array(ids, dtype=np.int64)


SHEET_FAMILIES = {
    "01": ["sun"], "02": [("chain", "CLIMATE_SYS"), ("chain", "GLOBAL_TEMP")],
    "03": [("chain", "GRAIN_MARKET"), "climate_cells"], "04": ["weather"],
    "05": ["industrial"], "06": ["PSYCH_HUBS"], "07": ["households"],
    "08": ["buildings"], "09": ["households"], "10": ["cars", "transit"],
    "11": ["datacenters", ("chain", "AI_DEMAND")], "12": ["commercial"],
    "13": ["industrial"], "14": ["farms", "diets", ("chain", "FERT_MARKET")],
    "15": ["basins", "midstream"], "16": ["clean_stations"], "17": ["grids"],
    "18": [("chain", "CLIMATE_SYS"), ("core", "MKT_EUA")], "19": ["districts"],
    "20": ["districts"], "21": ["policy"], "22": ["COUNTRY"],
    "23": ["chokepoints", "policy"], "24": ["markets"],
    "25": ["industrial", "fossil_stations"], "26": ["consumers"],
    "27": ["clean_stations", ("core", "MKT_URANIUM")],
    "28": [], "29": ["chokepoints", "markets"],
    "30": [("chain", "CLIMATE_SYS"), "policy"],
    "31": [("chain", "CLIMATE_SYS"), ("chain", "GLOBAL_TEMP"), ("core", "WX_ENSO")],
}


def build_v5(verbose=True):
    w = build_v4(verbose=verbose)
    sheets = load_taxonomy()
    n0 = len(w.kind)
    ch = {c: w.n_core + i for i, c in enumerate(CHAIN)}

    new_kind, new_res, new_size = [], [], []
    names = {}                      # appended-node index -> display name
    src, dst, ww = [list(a) for a in ([], [], [])]
    nxt = n0

    def add_node(kname, name, res, size):
        nonlocal nxt
        new_kind.append(KIND_CODE[kname]); new_res.append(res); new_size.append(size)
        names[nxt] = name
        nxt += 1
        return nxt - 1

    def add_edge(a, b, weight):
        if a is None or b is None or abs(weight) < 1e-6:
            return
        src.append(a); dst.append(b); ww.append(weight)

    # psych hubs fan out to district psych nodes by archetype
    psych_all = _family(w, "psych")
    psych_hubs = []
    for pi, pname in enumerate(["habit", "loss_aversion", "status", "dissonance",
                                "norm", "present_bias"]):
        h = add_node("psych_hub", f"PSYCH HUB: {pname}", 0.3, 1.0)
        psych_hubs.append(h)
        members = psych_all[w.sub[psych_all] == pi]
        for m in members:
            add_edge(h, int(m), 0.45)   # coherent broadcast: hubs are 1->many, no pile-up
    # sheet hubs + drivers
    hub_of = {}
    all_drivers = []
    for s in sheets:
        hub = add_node("tax_hub", f"TAXONOMY {s['name']}", 0.35, 1.4)
        hub_of[s["num"]] = hub
        fams = SHEET_FAMILIES.get(s["num"], [])
        for f in fams:
            if f == "PSYCH_HUBS" or f == "COUNTRY":
                continue
            if isinstance(f, tuple) and f[0] == "chain":
                add_edge(hub, ch[f[1]], 0.3)
            elif isinstance(f, tuple) and f[0] == "core":
                add_edge(hub, w.idx.get(f[1]), 0.3)
            else:
                fam = _family(w, f)
                if len(fam):
                    # coherent broadcast: every family member feels the driver hub
                    # weakly-but-visibly; very large families are sampled in chunks
                    wgt = 0.25
                    for i in (fam if len(fam) <= 12000 else
                              fam[np.random.default_rng(3).choice(len(fam), 12000, replace=False)]):
                        add_edge(hub, int(i), wgt)
        # hubs also LISTEN: a sampled slice of the family + single anchors feed
        # back into the hub, so real-world events light up taxonomy rows.
        for f in fams:
            if isinstance(f, tuple):
                node = ch.get(f[1]) if f[0] == "chain" else w.idx.get(f[1])
                add_edge(node, hub, 0.25)
            elif f not in ("PSYCH_HUBS", "COUNTRY"):
                fam = _family(w, f)
                if len(fam):
                    pick = fam if len(fam) <= 150 else \
                        fam[np.random.default_rng(7).choice(len(fam), 150, replace=False)]
                    for i in pick:
                        add_edge(int(i), hub, 0.30 / len(pick))
        for d in s["drivers"]:
            di = add_node("driver", f"[{s['num']}:{d['n']}] {d['name']}",
                          d["res"], 0.5 + d["w"])
            add_edge(hub_of[s["num"]], di, 0.20)   # hub broadcasts back into rows
            d["_i"] = di
            d["sheet"] = s["name"]
            all_drivers.append(d)
            add_edge(di, hub, d["sign"] * d["w"])
            if s["num"] == "06":     # neuro -> psych hubs by keyword
                low = d["name"].lower()
                for key, pi in PSYCH_KEYS:
                    if key in low:
                        add_edge(di, psych_hubs[pi], d["sign"] * d["w"])
                        break
            if s["num"] == "22":     # country rows -> national supply nodes
                cc = COUNTRY_CC.get(d.get("country", ""))
                if cc:
                    for fuel in ("oil", "gas", "coal"):
                        add_edge(di, w.idx.get(f"SUP_{cc}_{fuel}"), 0.25)

    w.kind = np.concatenate([w.kind, np.array(new_kind, dtype=np.int8)])
    w.res = np.concatenate([w.res, np.array(new_res, dtype=np.float32)])
    w.size = np.concatenate([w.size, np.array(new_size, dtype=np.float32)])
    w.district = np.concatenate([w.district, np.full(len(new_kind), -1, dtype=np.int32)])
    w.sub = np.concatenate([w.sub, np.zeros(len(new_kind), dtype=np.int32)])
    s0, d0, w0 = w.edges
    w.edges = (np.concatenate([s0, np.array(src, dtype=np.int64)]),
               np.concatenate([d0, np.array(dst, dtype=np.int64)]),
               np.concatenate([w0, np.array(ww, dtype=np.float32)]))
    w.v5_names = names
    w.sheets = sheets
    w.drivers = all_drivers
    w.hub_of = hub_of
    w.KINDS5 = KINDS

    _decode4 = w.decode_name
    w.decode_name = lambda i: names.get(i) or _decode4(i)
    if verbose:
        print(f"v5 web: {len(w.kind):,} nodes, {len(w.edges[2]):,} edges "
              f"({len(all_drivers):,} taxonomy drivers, {len(sheets)} sheets)")
    return w
