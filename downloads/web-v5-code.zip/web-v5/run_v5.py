"""
v5 final assembly:  python3 run_v5.py
Builds the taxonomy-driven web, runs driver-native scenarios + the v4 historical
replays, writes figures, CSVs, driver-subweb exports (JSON + GEXF for Gephi and
the Julia/Octave engines), the results workbook feed, and navigator5.html.
"""
import os, sys, json, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(PARENT, "13 World Energy Web v4"))
sys.path.insert(0, HERE)
OUT = os.path.join(HERE, "outputs")
os.makedirs(OUT, exist_ok=True)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from build5 import build_v5, KINDS
from v4.engine4 import Engine4
from v4 import history

DRIVER_SCENARIOS = [
    ("household_size_shift", "Household size", 0.8,
     "Demographic driver 07: shrinking households raise per-capita energy"),
    ("appliance_discounting_fix", "Hyperbolic", -0.8,
     "Policy neutralizes hyperbolic discounting (green defaults) — relief through the unconscious-mind layer"),
    ("ice_albedo_acceleration", "Ice-albedo", 0.85,
     "Cross-scale feedback 31: ice-albedo loop accelerates"),
    ("taxonomy_oil_shock", "Oil price shock (upward)", 0.9,
     "Shock sheet 29's own oil-shock driver — the taxonomy's meta-row moves the market layer"),
    ("ai_electricity_demand", "AI ", 0.8,
     "Digital/ICT driver: AI electricity demand growth (sheet 11)"),
    ("china_driver_row", "China", 0.6,
     "Country sheet 22: stress the China profile row -> national fuel supplies"),
]


def main():
    w = build_v5()
    eng = Engine4(w)

    # ---------------- driver-native scenarios
    nav_runs = []
    for name, key, mag, desc in DRIVER_SCENARIOS:
        d = next((x for x in w.drivers if key.lower() in x["name"].lower()), None)
        if d is None:
            continue
        s, fh = eng.run({d["_i"]: mag})
        touched = int((np.abs(s) >= 0.02).sum())
        top = eng.top(s, fh, k=20, exclude={d["_i"]})
        ls = eng.layer_summary(s)
        print(f"  {name:28s} touched {touched:>7,}")
        nav_runs.append(dict(id=name, driver=d["name"], sheet=d["sheet"], mag=mag,
                             desc=desc, touched=touched, top=top, layers=ls))
        with open(os.path.join(OUT, f"impacts_{name}.csv"), "w", newline="") as f:
            cw = csv.writer(f)
            cw.writerow(["name", "kind", "impact", "round"])
            [cw.writerow([r["name"], r["kind"], r["impact"], r["round"]]) for r in top]

    # ---------------- v4 historical replays on the v5 web
    nav_events = []
    for name, ev in history.EVENTS.items():
        shocks = history.resolve(w, w.idx, ev["shocks"])
        s, fh = eng.run(shocks)
        touched = int((np.abs(s) >= 0.02).sum())
        drv = eng.layer_summary(s).get("driver", {})
        nav_events.append(dict(id=name, year=ev["year"], desc=ev["description"],
                               touched=touched,
                               drivers_lit=drv.get("touched", 0)))
        print(f"  {name:28s} {ev['year']} touched {touched:>7,} "
              f"(taxonomy drivers lit: {drv.get('touched', 0)})")

    # ---------------- figures
    census = {k: int((w.kind == i).sum()) for i, k in enumerate(KINDS)}
    fig, ax = plt.subplots(figsize=(11, 5.5))
    ks = sorted(census, key=lambda k: -census[k])
    ax.bar(ks, [census[k] for k in ks], color="#4C72B0")
    for i, k in enumerate(ks):
        ax.text(i, census[k] * 1.12, f"{census[k]:,}", ha="center", fontsize=8, rotation=30)
    ax.set_yscale("log"); ax.grid(axis="y", alpha=0.3)
    ax.set_title(f"v5 census — {len(w.kind):,} nodes / {len(w.edges[2]):,} edges "
                 f"(incl. {len(w.drivers):,} taxonomy drivers on 31 sheets)")
    plt.setp(ax.get_xticklabels(), rotation=35, ha="right")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig1_census_v5.png"), dpi=150)
    plt.close(fig)

    # taxonomy composition heatmap: sheet × leverage
    levs = ["Foundational", "Very high", "High", "Medium", "Low"]
    M = []
    snames = []
    for s in w.sheets:
        snames.append(s["name"][:30])
        row = [sum(1 for d in s["drivers"]
                   if str(d["leverage"]).strip().lower() == l.lower()) for l in levs]
        M.append(row)
    fig, ax = plt.subplots(figsize=(9, 11))
    im = ax.imshow(np.array(M), cmap="inferno_r", aspect="auto")
    ax.set_xticks(range(len(levs))); ax.set_xticklabels(levs, rotation=30, ha="right")
    ax.set_yticks(range(len(snames))); ax.set_yticklabels(snames, fontsize=8)
    fig.colorbar(im, label="drivers")
    ax.set_title("The taxonomy: 1,842 drivers × leverage class")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig2_taxonomy_heatmap.png"), dpi=150)
    plt.close(fig)

    # driver scenario reach comparison
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh([r["id"] for r in nav_runs], [r["touched"] for r in nav_runs], color="#DD8452")
    ax.set_xlabel("nodes touched"); ax.grid(axis="x", alpha=0.3)
    ax.set_title("Single-driver shocks from the spreadsheet, propagated through 959k nodes")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig3_driver_reach.png"), dpi=150)
    plt.close(fig)

    # ---------------- driver-subweb export (drivers + hubs + single anchors;
    # the huge hub->family fans are sampled to keep the file Gephi-sized)
    sub_nodes, sub_edges = [], []
    keep = set(int(i) for i in w.v5_names)
    for i in keep:
        sub_nodes.append(dict(id=i, name=w.v5_names[i],
                              kind=KINDS[w.kind[i]], res=float(w.res[i])))
    srcs, dsts, wws = w.edges
    karr = np.zeros(len(w.kind), dtype=bool)
    karr[list(keep)] = True
    both = karr[srcs] & karr[dsts]
    one = (karr[srcs] ^ karr[dsts])
    one_idx = np.where(one)[0]
    if len(one_idx) > 20000:
        one_idx = np.random.default_rng(1).choice(one_idx, 20000, replace=False)
    sel = np.concatenate([np.where(both)[0], one_idx])
    anchor_ids = set()
    for j in sel:
        a, b, ew = int(srcs[j]), int(dsts[j]), float(wws[j])
        sub_edges.append(dict(source=a, target=b, w=ew))
        anchor_ids.update([a, b])
    for i in anchor_ids - keep:
        sub_nodes.append(dict(id=i, name=w.decode_name(i)[:70],
                              kind=KINDS[w.kind[i]], res=float(w.res[i])))
    with open(os.path.join(OUT, "driver_subweb.json"), "w") as f:
        json.dump(dict(nodes=sub_nodes, edges=sub_edges), f)
    try:
        import networkx as nx
        H = nx.DiGraph()
        for nd in sub_nodes[:20000]:
            H.add_node(nd["id"], label=nd["name"], kind=nd["kind"])
        for e in sub_edges[:60000]:
            if H.has_node(e["source"]) and H.has_node(e["target"]):
                H.add_edge(e["source"], e["target"], weight=abs(e["w"]))
        nx.write_gexf(H, os.path.join(OUT, "driver_subweb.gexf"))
    except Exception as ex:
        print("gexf skipped:", ex)
    print(f"driver subweb: {len(sub_nodes):,} nodes, {len(sub_edges):,} edges exported")

    # ---------------- navigator data
    tax = [dict(sheet=s["name"],
                drivers=[{k: d[k] for k in ("n", "name", "mechanism", "direction",
                                            "leverage", "timescale", "metric")}
                         for d in s["drivers"]])
           for s in w.sheets]
    data = dict(meta=dict(nodes=int(len(w.kind)), edges=int(len(w.edges[2])),
                          drivers=len(w.drivers), sheets=len(w.sheets)),
                census=census, taxonomy=tax, runs=nav_runs, events=nav_events)
    with open(os.path.join(OUT, "navigator5_data.json"), "w") as f:
        json.dump(data, f)
    tpl = open(os.path.join(HERE, "navigator5_template.html")).read()
    open(os.path.join(HERE, "navigator5.html"), "w").write(
        tpl.replace("/*__DATA__*/null", json.dumps(data)))
    print("wrote navigator5.html →", HERE)


if __name__ == "__main__":
    main()
