# 14 — World Energy Web v5: the Taxonomy-Driven Web

**959,229 nodes / ~2.64M edges**, with the defining v5 feature: the model's semantic
spine is **your own spreadsheet** — `energy_ghg_driver_taxonomy.xlsx` (31 driver sheets,
01 Solar & Astronomical → 31 Cross-Scale Feedback Loops, **1,842 driver rows**). The
loader maps every row into a live node:

- **Leverage** → edge weight (Foundational 0.6 … Low 0.1)
- **Timescale** → inertia/resilience (Instant 0.08 … Centuries 0.9)
- **Direction** → edge sign

**Edit the spreadsheet, rebuild, and the web regrows.** Each sheet gets a hub wired
two-way into its v4 node family (sheet 07 ↔ 29,740 households, sheet 10 ↔ car/transit
cohorts, sheet 14 ↔ farms + fertilizer chain, sheet 06 ↔ the unconscious-mind layer via
six psych hubs, sheet 22's country rows ↔ national fuel supplies, sheet 31 ↔ the
climate system with per-row sign).

## What that buys

- **Shock a spreadsheet row, watch the world**: `household_size_shift` touches 12k
  household nodes; the sheet-29 "oil price shock" *meta-row* reaches 491k nodes through
  the market layer; `china_driver_row` (sheet 22) hits 21k via national supplies;
  `appliance_discounting_fix` propagates *relief through the unconscious-mind layer*.
- **History annotates the taxonomy**: replaying v4's ten events on v5, each event
  "lights up" 50–138 driver rows — the model telling you which parts of your taxonomy
  each crisis actually exercised (OPEC '73: 114 rows; COVID: 77; Fukushima: 0 outside
  its narrow channel).

## Outputs (the v1–v4 families, all present)

| | |
|---|---|
| `taxonomy_loader.py` / `build5.py` / `run_v5.py` | loader → builder → final assembly (verified end-to-end) |
| `navigator5.html` | self-contained explorer: **Taxonomy Browser** (search all 1,842 rows by text/sheet/leverage), Driver Shocks, Historical Replays, census |
| `outputs/fig1-3` | v5 census · taxonomy × leverage heatmap · driver-shock reach |
| `outputs/impacts_*.csv`, `navigator5_data.json` | per-run tables + full navigator data |
| `outputs/driver_subweb.json` + `.gexf` | the driver cortex (21k nodes) for Gephi and the alternate runtimes |
| `julia/engine.jl` + `Project.toml`, `octave/engine.m` | Julia and MATLAB/Octave propagation engines over the exported subweb (untested in sandbox — Julia/Octave unavailable there; mirror the verified Python engine) |
| `v5_results.xlsx` | taxonomy composition + run reach, live formulas, verified |

Depends on `../13 World Energy Web v4` (imports the v4 builder/engine — v5 is a layer,
not a fork). Sheet 28 (Measurement & Accounting) is intentionally left dynamic-free:
it's bookkeeping, not physics.

## Honest notes

Hub↔family coupling constants are structural (tuned so single-driver shocks are visible
without resonance — the two-way coupling was calibrated by damping until historical
events kept their v4 rank-order). Family fans over very large layers (761k cars) are
12k-node samples. Countries beyond the 45 modeled map only into their taxonomy row.
