"""
Atlas exporter, full coverage. Rebuilds the interactive slice from the v5 arrays:
  - EVERY taxonomy driver row (all 31 sheets, 1,842 rows) with its edges
  - all chokepoints, basins, pipelines, LNG terminals, markets, policy, weather,
    grids, national fuel supplies, chain nodes, psych hubs and cells, ERCOT
    region detail, community cohorts
Driver rows are placed on organized "ledger" cards below each scene.
All text follows ASD-STE100 style: short sentences, active voice, no idioms.
"""
import sys, os, json, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(HERE), "13 World Energy Web v4"))
sys.path.insert(0, HERE)
from build5 import build_v5, KINDS
from v4.build4 import CHAIN

SW, ART_H = 1600, 860
LAT_MAX, LAT_MIN = 74, -60

SHEET_TAB = {"01": 0, "02": 1, "03": 1, "04": 1, "18": 1, "31": 1,
             "15": 2, "22": 2, "23": 2, "24": 2, "28": 2, "29": 2, "30": 2,
             "05": 3, "16": 3, "17": 3, "21": 3, "27": 3,
             "19": 4, "20": 4,
             "07": 5, "08": 5, "09": 5, "10": 5, "11": 5, "12": 5, "13": 5,
             "14": 5, "25": 5, "26": 5,
             "06": 6}

LEVELS = ["Sun and Space", "Earth and Climate", "Fuel and Geopolitics",
          "Grids and Nations", "Region: ERCOT", "One Community", "The Mind"]

# ---------------- STE descriptions (short sentences, active voice)
KIND_STE = {
 "chokepoint": "This is a narrow sea passage. A large part of world oil and gas trade moves through it. If it closes, ships must use longer routes. Prices increase quickly.",
 "basin": "This is an oil or gas production area. A supply loss here changes world prices. It also changes the fuel supply of its country.",
 "market": "This is a price benchmark. Many contracts use this price as a reference. A change here moves costs for all users of the commodity.",
 "grid": "This is a power system. It must balance supply and demand at all times. When capacity is low, prices increase.",
 "supply": "This is the fuel supply of one country. It mixes domestic production, imports, and world prices.",
 "policy": "This is a government or group decision point. Its actions can add or remove supply. Its actions can also change prices directly.",
 "midstream": "This is a pipeline or an LNG terminal. It moves fuel from producers to users. It is a possible bottleneck.",
 "weather": "This is a weather pattern. It can reduce power output and fuel production. It can also increase demand at the same time.",
 "sun": "This is part of the solar resource. Its output changes slowly. All solar power depends on it.",
 "station": "This is a power plant from the WRI world database. The record gives its fuel, capacity, and location.",
 "district": "This is one part of a power grid. It has its own demand, weather, and consumers.",
 "consumer": "This is a group of consumers. The group has an income level and a mentality. Prices change the behavior of the group.",
 "sector": "This is a demand sector of a grid. Examples are homes, industry, and transport.",
 "household": "This is a group of households in one income band. Lower income bands react more to prices. They are also more exposed to weather.",
 "car": "This is a group of vehicles of one model year, fuel, and type. Its efficiency matches its model year.",
 "transit": "This is a group of travelers. Rail users depend on the grid. Air travelers depend on jet fuel.",
 "farm": "This is a farm. It buys nitrogen fertilizer. Fertilizer is made from natural gas. A gas price change reaches this farm.",
 "diet": "This is a diet group. More meat in a diet needs more energy and land. The group connects to the grain market.",
 "datacenter": "This is a datacenter. New AI computers increase its power demand. This demand grows fast.",
 "climate_cell": "This is the local climate signal of one district. The global climate system drives it. It changes farm output and household demand.",
 "psych": "This is one part of the unconscious mind of a district. It changes how consumers react to prices.",
 "psych_hub": "This is a global behavior channel. It sends one bias to all districts.",
 "chain": "This is a global supply chain node. Examples are ammonia plants and the grain market.",
 "tax_hub": "This is the hub of one taxonomy sheet. It connects the sheet rows to the model.",
 "driver": "This is one row of the driver taxonomy. Shock it to test its effect on the system.",
}
PROSE_STE = {
 "SUN": "The Sun supplies almost all energy on Earth. Its output changes by about 0.1 percent in an 11-year cycle. All solar power depends on this input.",
 "CHK_HORMUZ": "The Strait of Hormuz is a narrow passage between Iran and Oman. About one fifth of world oil trade moves through it. Also about one fifth of LNG trade. If it closes, prices increase in days.",
 "MKT_BRENT": "Brent is the reference price for most world oil. Import costs, fuel costs, and fertilizer costs follow it.",
 "MKT_TTF": "TTF is the reference price for gas in Europe. In 2022 it increased about ten times. Factories closed because of this price.",
 "MKT_JKM": "JKM is the reference price for LNG in Asia. It decides where LNG ships go.",
 "MKT_HH": "Henry Hub is the reference price for gas in the United States. It is a pipeline junction in Louisiana.",
 "ERCOT": "ERCOT is the power grid of Texas. It is not connected strongly to other grids. Its price can go to 9000 dollars per megawatt-hour. This happened in February 2021.",
 "POL_OPEC": "OPEC+ is a group of oil producing countries. It sets production limits. Its decisions change world supply.",
 "CLIMATE_SYS": "This is the climate system of Earth. It changes slowly. It has feedback loops that make warming stronger or weaker.",
 "GLOBAL_TEMP": "This is the global temperature signal. All emissions push it up. It pushes back through the weather.",
 "AI_DEMAND": "This is the power demand of AI computers. Datacenter power was almost flat for 15 years. AI training ended that. Demand now grows about 20 percent each year.",
 "BAS_GHAWAR": "Ghawar in Saudi Arabia is the largest conventional oil field. It has produced since 1951.",
 "BAS_PERMIAN": "The Permian Basin in West Texas is the largest shale oil area. Its output reacts to price in months. Other supply reacts in years.",
 "FERT_MARKET": "This is the world fertilizer market. Fertilizer is made from natural gas. High gas prices make fertilizer costly. Farmers then use less.",
 "GRAIN_MARKET": "This is the world grain market. It carries gas costs, diesel costs, and weather effects into food prices.",
 "PSYCH HUB: dissonance": "This channel models cognitive dissonance (Festinger, 1957). A person with green values and high fuel use feels tension. Long price stress increases the tension. The person then changes behavior, for example buys an electric car.",
 "PSYCH HUB: habit": "This channel models habit (Becker and Murphy, 1988). Most energy use is habit. Habit makes short-term reactions small.",
 "PSYCH HUB: loss_aversion": "This channel models loss aversion (Kahneman and Tversky, 1979). A price increase feels about two times worse than an equal saving feels good. This causes hoarding and fast conservation.",
 "PSYCH HUB: present_bias": "This channel models present bias (Laibson, 1997). People value today much more than next year. Good insulation projects fail because of this.",
 "PSYCH HUB: status": "This channel models status signals (Veblen, 1899). People buy vehicles to show status. Price alone does not explain these purchases.",
 "PSYCH HUB: norm": "This channel models social norms (Cialdini). People follow their neighbors. Utility reports that compare neighbors reduce use by about 2 percent.",
 "WX_GULF_HURR": "This is the hurricane region of the US Gulf Coast. Offshore platforms, LNG terminals, and refineries are all in this region.",
 "WX_TX_FREEZE": "This is a deep freeze pattern in Texas. In 2021 it stopped gas wells and power plants. Demand increased at the same time. This caused long outages.",
}

GAZ = {
 "CHK_HORMUZ": (56.5, 26.6), "CHK_MALACCA": (100.5, 3.0), "CHK_SUEZ": (32.5, 30.0),
 "CHK_BABELMANDEB": (43.3, 12.6), "CHK_BOSPORUS": (29.0, 41.1), "CHK_DANISH": (11.0, 56.0),
 "CHK_PANAMA": (-79.6, 9.0), "CHK_GIBRALTAR": (-5.6, 36.0), "CHK_CAPE": (18.5, -34.4),
 "BAS_PERMIAN": (-102.0, 31.8), "BAS_EAGLEFORD": (-98.5, 28.8), "BAS_BAKKEN": (-103.0, 47.8),
 "BAS_APPALACHIA": (-79.0, 40.5), "BAS_HAYNESVILLE": (-93.9, 32.2), "BAS_GOM": (-90.5, 27.5),
 "BAS_OILSANDS": (-111.5, 57.0), "BAS_MONTNEY": (-121.5, 56.0), "BAS_GHAWAR": (49.6, 25.4),
 "BAS_SAFANIYA": (48.8, 28.0), "BAS_RUMAILA": (47.3, 30.3), "BAS_IRANFIELDS": (49.5, 31.5),
 "BAS_SOUTHPARS": (52.5, 26.8), "BAS_NORTHFIELD": (51.9, 26.2), "BAS_ZAKUM": (53.5, 25.0),
 "BAS_BURGAN": (47.9, 29.0), "BAS_WSIBERIA": (76.0, 63.0), "BAS_VOLGA": (50.0, 54.0),
 "BAS_TENGIZ": (53.5, 46.0), "BAS_NCS": (3.0, 61.0), "BAS_UKNS": (1.5, 57.5),
 "BAS_GRONINGEN": (6.7, 53.3), "BAS_HASSI": (6.0, 31.7), "BAS_SIRTE": (18.0, 30.5),
 "BAS_NIGERDELTA": (6.5, 4.8), "BAS_ZOHR": (31.5, 31.8), "BAS_SANTOS": (-43.5, -25.0),
 "BAS_STABROEK": (-57.0, 8.5), "BAS_ORINOCO": (-64.0, 8.5), "BAS_VACA": (-69.0, -38.5),
 "BAS_NWS": (116.0, -20.0), "BAS_BOWEN": (148.5, -22.5), "BAS_KALIMANTAN": (116.0, -1.0),
 "BAS_SHANXI": (112.0, 37.5), "BAS_TARIM": (84.0, 40.5), "BAS_JHARIA": (86.4, 23.7),
 "BAS_KUZBASS": (86.1, 54.5), "BAS_MPUMALANGA": (29.5, -26.0),
 "MKT_BRENT": (1.0, 60.5), "MKT_WTI": (-96.8, 36.0), "MKT_DUBAI": (55.3, 25.2),
 "MKT_HH": (-92.0, 30.0), "MKT_TTF": (5.2, 52.2), "MKT_NBP": (-1.5, 52.5),
 "MKT_JKM": (135.0, 35.0), "MKT_API2": (4.4, 51.9), "MKT_NEWC": (151.8, -33.0),
 "MKT_EUA": (4.35, 50.85), "MKT_FREIGHT_LNG": (-30.0, 20.0),
 "MKT_FREIGHT_TANKER": (60.0, 5.0), "MKT_URANIUM": (66.0, 49.0), "MKT_DIESEL": (-15.0, 40.0),
 "POL_OPEC": (16.4, 48.2), "POL_SPR": (-77.0, 38.9), "POL_IEA": (2.35, 48.85),
 "POL_SANCTIONS_RU": (37.6, 55.7), "POL_SANCTIONS_IR": (51.4, 35.7),
 "POL_EU_STORAGE": (4.35, 50.85), "POL_CN_EXPORT": (116.4, 39.9), "POL_45Q_IRA": (-77.0, 38.9),
 "PIP_DRUZHBA": (30.0, 52.0), "PIP_TURKSTREAM": (33.0, 43.0), "PIP_POWERSIB": (110.0, 52.0),
 "PIP_TANAP": (35.0, 39.5), "PIP_BTC": (44.0, 41.0), "PIP_ESPO": (120.0, 54.0),
 "PIP_KEYSTONE": (-100.0, 45.0), "PIP_COLONIAL": (-84.0, 34.0), "PIP_TRANSMED": (11.0, 36.0),
 "PIP_MAGHREB": (-4.0, 35.5), "PIP_NORDSTREAM": (14.0, 55.0), "PIP_UKRTRANSIT": (32.0, 49.0),
 "PIP_LANGELED": (3.5, 58.5), "PIP_ROCKIES": (-100.0, 31.0),
 "WX_GULF_HURR": (-90.0, 26.0), "WX_ATL_HURR": (-72.0, 30.0), "WX_TX_HEAT": (-99.0, 31.5),
 "WX_TX_FREEZE": (-101.0, 34.5), "WX_CA_FIRE": (-121.0, 38.5), "WX_EU_BLOCK": (7.0, 52.5),
 "WX_EU_COLD": (15.0, 56.0), "WX_NORDIC_DRY": (9.0, 62.0), "WX_SIBERIA_COLD": (95.0, 62.0),
 "WX_ENSO": (-150.0, -2.0), "WX_MONSOON": (77.0, 21.0), "WX_TYPHOON": (132.0, 18.0),
 "WX_AU_DROUGHT": (134.0, -25.0), "WX_SAHEL_DRY": (12.0, 14.0),
}
CC_CENTER = {"US": (-98, 39), "CA": (-106, 56), "MX": (-102, 23), "BR": (-52, -11),
 "AR": (-65, -35), "CL": (-71, -32), "CO": (-73, 4), "GB": (-1.5, 53), "DE": (10, 51),
 "FR": (2.5, 46.5), "ES": (-3.5, 40), "IT": (12.5, 42.5), "PL": (19.5, 52), "NL": (5.5, 52.2),
 "NO": (9, 61), "SE": (16, 62), "UA": (31, 49), "TR": (35, 39), "RU": (60, 57),
 "KZ": (67, 48), "SA": (45, 24), "AE": (54, 24), "IR": (53, 32.5), "IQ": (43.5, 33),
 "QA": (51.2, 25.3), "KW": (47.6, 29.3), "IL": (34.9, 31.4), "EG": (30, 26.5),
 "DZ": (3, 28), "NG": (8, 9.5), "ZA": (25, -29), "LY": (17, 27), "CN": (104, 35),
 "IN": (79, 22), "JP": (138, 37), "KR": (127.8, 36.3), "TW": (121, 23.8),
 "ID": (113, -2), "MY": (102, 4), "VN": (106, 16), "TH": (101, 15), "PK": (69.5, 30),
 "BD": (90.3, 23.8), "AU": (134, -25), "NZ": (172, -42)}
GRID_POS = {"ERCOT": (-99, 31), "PJM": (-79, 40), "MISO": (-92, 43), "CAISO": (-120, 36.5),
 "SPP": (-98, 36.5), "NYISO": (-75.5, 43), "ISONE": (-71.5, 44), "SERC": (-84, 33.5),
 "WECCNW": (-114, 44), "CN_N": (114, 39), "CN_E": (120, 31), "CN_S": (112, 23.5),
 "CN_C": (112, 30.5), "CN_NE": (125, 44), "CN_NW": (95, 41), "IN_N": (77, 28.5),
 "IN_W": (73.5, 20), "IN_S": (78, 12.5), "IN_E": (86, 23), "JP_E": (140, 36.5),
 "JP_W": (134, 34.5), "NEM": (146, -33), "WEM": (116, -31), "CA_QC": (-72, 48),
 "CA_ON": (-80, 46), "CA_W": (-114, 53), "RU_EU": (42, 56), "RU_SIB": (92, 57), "SIN": (-48, -16)}
MAPG = {"ERCOT": "ERCOT", "PJM": "PJM", "MISO": "MISO", "CAISO": "CAISO",
 "Southwest Power Pool": "SPP", "NYISO": "NYISO", "ISO New England": "ISONE",
 "Southeast": "SERC", "Western non-CA": "WECCNW", "North China": "CN_N",
 "East China": "CN_E", "China Southern": "CN_S", "Central China": "CN_C",
 "Northeast China": "CN_NE", "Northwest China": "CN_NW", "Northern Region": "IN_N",
 "Western Region": "IN_W", "Southern Region": "IN_S", "Eastern+NE Region": "IN_E",
 "East Japan": "JP_E", "West Japan": "JP_W", "National Electricity Market": "NEM",
 "WA Wholesale": "WEM", "Hydro-Quebec": "CA_QC", "IESO Ontario": "CA_ON",
 "AESO": "CA_W", "IPS European": "RU_EU", "IPS Siberia": "RU_SIB",
 "Sistema Interligado": "SIN"}
CHAIN_POS = {"AMMONIA_USGULF": (-92, 30.2), "AMMONIA_MIDEAST": (51.5, 25.8),
 "AMMONIA_CHINA": (117, 36), "AMMONIA_EUROPE": (4.3, 51.5), "FERT_MARKET": (-25, 5),
 "GRAIN_MARKET": (-94, 41.5), "CLIMATE_SYS": (-160, 62), "GLOBAL_TEMP": (-160, 47),
 "AI_DEMAND": (-122, 37.4)}
BRAIN = {"habit": (760, 470), "loss_aversion": (860, 520), "status": (930, 445),
         "dissonance": (860, 330), "norm": (620, 360), "present_bias": (1105, 330)}
BRAIN_LABELS = [("Prefrontal cortex: present bias and planning", 1130, 250),
                ("Anterior cingulate: dissonance", 855, 285),
                ("Temporo-parietal: social norms", 575, 320),
                ("Basal ganglia: habit", 735, 505),
                ("Amygdala: loss and fear", 872, 562),
                ("Ventral striatum: status and reward", 965, 415)]


def merc(lon, lat):
    lat = max(min(lat, LAT_MAX), LAT_MIN)
    x = (lon + 180) / 360 * SW
    y0 = math.log(math.tan(math.pi / 4 + math.radians(LAT_MAX) / 2))
    y1 = math.log(math.tan(math.pi / 4 + math.radians(LAT_MIN) / 2))
    yy = math.log(math.tan(math.pi / 4 + math.radians(lat) / 2))
    return round((x), 1), round((y0 - yy) / (y0 - y1) * ART_H, 1)


def simplify(ring, keep):
    if len(ring) <= keep:
        return ring
    step = len(ring) / keep
    return [ring[int(i * step)] for i in range(keep)]


def main():
    w = build_v5(verbose=True)
    idx = w.idx
    rev = {j: nid for nid, j in idx.items()}
    rng = np.random.default_rng(21)
    jit = lambda s=10: float(rng.uniform(-s, s))

    picks = {}   # array index -> (tab)
    def add(i, tab):
        if i is not None and i not in picks:
            picks[int(i)] = tab

    # ---- core coverage
    for nid, i in idx.items():
        kk = w.core_kinds[i]
        if kk == "sun": add(i, 0)
        elif nid.startswith("WX_") or nid.startswith("WXL_") or nid.startswith("CLD_DIS_ERCOT"):
            add(i, 1)
        elif kk in ("chokepoint", "basin", "market", "policy", "midstream"): add(i, 2)
        elif kk in ("grid", "supply"): add(i, 3)
        elif kk == "district" and nid.startswith("DIS_ERCOT"): add(i, 4)
        elif kk == "sector" and "_ERCOT_" in nid: add(i, 4)
        elif kk == "consumer" and nid.startswith("CON_DIS_ERCOT_00"): add(i, 5)
    for j, c in enumerate(CHAIN):
        add(w.n_core + j, 1 if c in ("CLIMATE_SYS", "GLOBAL_TEMP") else 2)
    srcs, dsts, wws = w.edges
    er = idx["ERCOT"]
    feeders = [int(i) for i in srcs[dsts == er]
               if w.kind[i] == 0 and w.core_kinds[i] == "station"]
    feeders.sort(key=lambda i: -float(w.size[i]))
    for i in feeders[:40]:
        add(i, 4)
    kmap = {k: j for j, k in enumerate(KINDS)}
    for kname, cap in [("household", 30), ("diet", 12), ("transit", 9), ("farm", 18),
                       ("datacenter", 6), ("car", 32), ("climate_cell", 3), ("psych", 18)]:
        ids = np.where(w.kind == kmap[kname])[0]
        ids = [int(i) for i in ids if 0 <= w.district[i] <= 2]
        for i in ids[:cap]:
            add(i, 6 if kname == "psych" else 5)
    # ---- ALL drivers + hubs
    for i, name in w.v5_names.items():
        if name.startswith("PSYCH HUB"):
            add(i, 6)
        elif name.startswith("TAXONOMY"):
            num = name.split()[1]
            add(i, SHEET_TAB.get(num, 2))
        elif name.startswith("["):
            num = name[1:3]
            add(i, SHEET_TAB.get(num, 2))
    # scenario shock targets
    sys.path.insert(0, os.path.join(os.path.dirname(HERE), "10 World Energy Web"))
    from energyweb.scenarios import SCENARIOS
    scen = {}
    for sname, sc in SCENARIOS.items():
        resolved = {}
        for key, mag in sc["shocks"].items():
            targets = []
            if key == "__LARGEST_STATION_ERCOT__": targets = feeders[:1]
            elif key == "__LARGEST_STATION_ERCOT_nuclear__":
                targets = [i for i in feeders if w.core_fuels[i] == "nuclear"][:1] or feeders[:1]
            elif key == "__STATIONS_DE_gas_5__":
                de = sorted([i for nid, i in idx.items() if w.core_kinds[i] == "station"
                             and w.core_countries[i] == "DE" and w.core_fuels[i] == "gas"],
                            key=lambda i: -float(w.size[i]))[:5]
                targets = de
                for t in de: add(t, 3)
            elif key == "__CONSUMERS_US_20__":
                us = sorted([i for nid, i in idx.items() if w.core_kinds[i] == "consumer"
                             and w.core_countries[i] == "US"],
                            key=lambda i: -float(w.size[i]))[:20]
                targets = us
                for t in us: add(t, 5)
            elif key in idx:
                targets = [idx[key]]
            for t in targets:
                resolved[int(t)] = mag
        if resolved:
            scen[sname] = dict(shocks=resolved, desc=sc["description"],
                               category=sc["category"])
    scen["climate_forcing"] = dict(
        shocks={w.n_core + CHAIN.index("CLIMATE_SYS"): 0.8},
        desc="The climate system moves to a higher anomaly. All weather layers feel it.",
        category="top-down")
    scen["dim_solar_cycle"] = dict(
        shocks={idx["SUN"]: 0.6},
        desc="The Sun gives less irradiance for some years. All solar power feels it.",
        category="top-down")

    keep = sorted(picks)
    remap = {i: j for j, i in enumerate(keep)}

    # ---- geometry ---------------------------------------------------------
    world = []
    gj = json.load(open("/tmp/worldgeo/countries.geo.json"))
    for f in gj["features"]:
        g = f["geometry"]
        polys = g["coordinates"] if g["type"] == "MultiPolygon" else [g["coordinates"]]
        for poly in polys:
            ring = poly[0]
            if len(ring) < 12:
                continue
            pts = [merc(p[0], p[1]) for p in simplify(ring, max(8, min(120, len(ring) // 6)))]
            world.append(pts)
    tg = json.load(open("/tmp/usstates/texas.geojson"))
    g = tg["geometry"] if "geometry" in tg else tg["features"][0]["geometry"]
    ring = g["coordinates"][0]
    if isinstance(ring[0][0], list):
        ring = ring[0]
    tex = [(float(p[0]), float(p[1])) for p in simplify(ring, 160)]
    tb = (min(p[0] for p in tex), max(p[0] for p in tex),
          min(p[1] for p in tex), max(p[1] for p in tex))
    def tx_proj(lon, lat):
        return (250 + (lon - tb[0]) / (tb[1] - tb[0]) * 1100,
                90 + (tb[3] - lat) / (tb[3] - tb[2]) * 660)
    texas_poly = [[round(x, 1), round(y, 1)] for x, y in (tx_proj(a, b) for a, b in tex)]

    # ---- name->coord helpers
    from energyweb import world_data as WD
    NAME2GAZ = {}
    for cid, cname, *_ in WD.CHOKEPOINTS: NAME2GAZ[cname] = GAZ.get(cid)
    for bid, bname, cc, *_ in WD.BASINS: NAME2GAZ[bname] = GAZ.get(bid)
    for pid, pname, *_ in WD.PIPELINES: NAME2GAZ[pname] = GAZ.get(pid)
    for mid, mname, *_ in WD.MARKETS: NAME2GAZ[mname] = GAZ.get(mid)
    for pid, pname, _t in WD.POLICY: NAME2GAZ[pname] = GAZ.get(pid)
    for wid, wname, *_ in WD.WEATHER_MACRO: NAME2GAZ[wname] = GAZ.get(wid)
    for tid, tname, cc, s in WD.LNG_EXPORT + WD.LNG_IMPORT:
        c = CC_CENTER.get(cc, (0, 0)); NAME2GAZ[tname] = (c[0] + 3, c[1] - 3)
    CNAMES = {c[1]: c[0] for c in WD.COUNTRIES}

    # ---- driver ledger layout per tab
    sheets_by_tab = {}
    for s in w.sheets:
        sheets_by_tab.setdefault(SHEET_TAB.get(s["num"], 2), []).append(s)
    ledger = {t: [] for t in range(7)}      # cards: {name,x,y,w,h}
    driver_pos = {}                          # driver name -> (tab,x,y)
    tab_height = {t: ART_H for t in range(7)}
    for t, sheets in sheets_by_tab.items():
        cx0, cy0 = 40, ART_H + 70
        row_h = 0
        for s in sheets:
            n = len(s["drivers"])
            cols = 10
            rows = math.ceil(n / cols)
            cw, chh = cols * 30 + 30, rows * 26 + 52
            if cx0 + cw > SW - 20:
                cx0 = 40; cy0 += row_h + 26; row_h = 0
            ledger[t].append(dict(name=s["name"], x=cx0, y=cy0, w=cw, h=chh))
            for k, d in enumerate(s["drivers"]):
                driver_pos[f"[{s['num']}:{d['n']}]"] = (
                    t, cx0 + 24 + (k % cols) * 30, cy0 + 44 + (k // cols) * 26)
            row_h = max(row_h, chh)
            cx0 += cw + 24
        tab_height[t] = cy0 + row_h + 60

    # ---- node emit --------------------------------------------------------
    counters = {}
    nodes = []
    anch = [(-95.4, 29.8), (-97.0, 32.8), (-97.7, 30.3), (-98.5, 29.4), (-102.0, 31.9),
            (-94.1, 30.1), (-97.4, 27.8), (-101.8, 35.2)]
    st_i = 0
    for i in keep:
        tab = picks[i]
        kname = w.core_kinds[i] if i < w.n_core else KINDS[w.kind[i]]
        name = w.decode_name(i)
        nid = rev.get(i, "")
        desc = KIND_STE.get(kname, "")
        if kname == "driver":
            key = name.split("] ", 1)[-1].lower()
            d = next((x for x in w.drivers if x["name"].lower() == key), None)
            if d:
                desc = (f"{d['mechanism']} Leverage: {d['leverage']}. "
                        f"Timescale: {d['timescale']}. Data: {d['metric']}.")
        if nid in PROSE_STE: desc = PROSE_STE[nid]
        elif name in PROSE_STE: desc = PROSE_STE[name]
        x = y = None
        if kname in ("driver",):
            tag = name.split("]")[0] + "]"
            t2, x, y = driver_pos.get(tag, (tab, 60, ART_H + 80))
            tab = t2
        elif kname == "tax_hub":
            num = name.split()[1]
            card = next((c for c in ledger[tab] if c["name"].startswith(num)), None)
            if card: x, y = card["x"] + card["w"] / 2, card["y"] + 16
            else: x, y = 100, ART_H + 40
        elif tab == 0:
            k0 = counters.get("sun", 0); counters["sun"] = k0 + 1
            if "variability" in name: x, y = 430, 430
            else:
                a = -1.05 + k0 * 0.22
                x, y = 430 + 520 * math.cos(a), 430 + 300 * math.sin(a)
        elif tab == 6:
            if kname == "psych_hub":
                x, y = BRAIN.get(name.split(": ")[-1], (800, 400))
            elif kname == "psych":
                base = None
                for bk, pos in BRAIN.items():
                    if bk.split("_")[0] in name: base = pos; break
                hx, hy = base or (800, 400)
                x, y = hx + jit(42), hy + jit(30)
        elif tab == 4:
            k4 = counters.get("t4" + kname, 0); counters["t4" + kname] = k4 + 1
            if kname == "station":
                a = anch[st_i % len(anch)]; st_i += 1
                x, y = tx_proj(a[0] + jit(0.9), a[1] + jit(0.7))
            elif kname == "district":
                x, y = 430 + (k4 % 9) * 118 + jit(20), 200 + (k4 // 9) * 82 + jit(14)
            elif kname == "sector": x, y = 130, 150 + k4 * 56
            else: x, y = 1400, 150 + k4 * 56
        elif tab == 5:
            k5 = counters.get("t5" + kname, 0); counters["t5" + kname] = k5 + 1
            if kname == "farm": x, y = 90 + (k5 % 6) * 56, 470 + (k5 // 6) * 78
            elif kname == "household": x, y = 470 + (k5 % 10) * 62, 445 + (k5 // 10) * 128
            elif kname == "car": x, y = 430 + (k5 % 16) * 55, 655 + (k5 // 16) * 40
            elif kname == "transit": x, y = 1330 + (k5 % 3) * 60, 650
            elif kname == "diet": x, y = 1150 + (k5 % 4) * 58, 430
            elif kname == "datacenter": x, y = 1330 + (k5 % 2) * 100, 280
            elif kname == "climate_cell": x, y = 300 + k5 * 170, 120
            elif kname == "consumer": x, y = 470 + (k5 % 10) * 62, 290 + (k5 // 10) * 52
            else: x, y = 100, 120 + k5 * 40
        if x is None:      # world map tabs
            ll = NAME2GAZ.get(name) or (CHAIN_POS.get(name) if kname == "chain" else None)
            if ll is None:
                for frag, gid in MAPG.items():
                    if frag.lower() in name.lower():
                        ll = GRID_POS[gid]; break
            if ll is None:
                for cname, cc in CNAMES.items():
                    if name.startswith(cname):
                        b = CC_CENTER[cc]
                        off = {"oil": (-5, -3), "gas": (0, -5), "coal": (5, -3), "nuclear": (3, 3)}
                        for f, o in off.items():
                            if f" {f} " in name or name.endswith(f + " supply"):
                                ll = (b[0] + o[0], b[1] + o[1]); break
                        ll = ll or (b[0] + jit(3), b[1] + jit(2))
                        break
            if ll is None:
                ll = (-172 + jit(3), -52 + jit(3))
            x, y = merc(ll[0] + jit(1.0), ll[1] + jit(0.7))
        nodes.append(dict(i=remap[i], level=tab, kind=kname, name=name[:90],
                          desc=desc, res=float(w.res[i]),
                          x=round(float(x), 1), y=round(float(y), 1),
                          fuel=w.core_fuels[i] if i < w.n_core else ""))
    karr = np.zeros(len(w.kind), dtype=bool); karr[keep] = True
    m = karr[srcs] & karr[dsts]
    edges = [dict(s=remap[int(a)], t=remap[int(b)], w=round(float(c), 4))
             for a, b, c in zip(srcs[m], dsts[m], wws[m])]
    presets = {}
    for sname, sc in scen.items():
        sh = {remap[t]: mag for t, mag in sc["shocks"].items() if t in remap}
        if sh:
            presets[sname] = dict(shocks=sh, desc=sc["desc"], category=sc["category"])
    data = dict(levels=LEVELS, nodes=nodes, edges=edges, presets=presets,
                world=world, texas=texas_poly, brainLabels=BRAIN_LABELS,
                ledger=ledger, tabHeight=tab_height, scene=[SW, ART_H])
    json.dump(data, open(os.path.join(HERE, "outputs", "atlas_data.json"), "w"))
    print(f"atlas: {len(nodes)} nodes, {len(edges)} edges, {len(presets)} presets")
    from collections import Counter
    print("per tab:", dict(Counter(n['level'] for n in nodes)))
    print("drivers included:", sum(1 for n in nodes if n['kind'] == 'driver'))


if __name__ == "__main__":
    main()
