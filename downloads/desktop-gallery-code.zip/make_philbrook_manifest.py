#!/usr/bin/env python3
"""Convert the existing philbrook_artworks.json into a collection manifest.

Reads the scrape output from the philbrook_museum project (sibling of
this project under PyProjects) and writes collections/philbrook/manifest.json.
Images are NOT copied; the manifest's images_hint points wallpaper.py at
the existing images_full folder.
"""

import json
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))

DEFAULT_SOURCE = os.path.normpath(os.path.join(
    SCRIPT_DIR, "..", "PyProjects", "philbrook_museum",
    "philbrook_artworks.json"))
OUT_PATH = os.path.join(SCRIPT_DIR, "collections", "philbrook",
                        "manifest.json")

# Relative path from collections/philbrook/ to the existing image folder.
IMAGES_HINT = "../../../PyProjects/philbrook_museum/images_full"


def main():
    source = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_SOURCE
    with open(source, "r", encoding="utf-8") as f:
        artworks = json.load(f)

    works = []
    for art in artworks:
        did = art.get("dispatcher_id")
        if not did:
            continue
        works.append({
            "id": did,
            "title": art.get("title", "Unknown"),
            "creator": art.get("creator", "Unknown"),
            "date": art.get("date", ""),
            "medium": art.get("medium", ""),
            "file": f"{did}.jpg",
            "url": art.get("source_url", ""),
        })

    manifest = {
        "name": "Philbrook Museum of Art",
        "source": "philbrook.emuseum.com",
        "license_note": ("Images fetched from the museum's public collection "
                         "site for personal desktop use; not redistributed."),
        "default_filter": "paintings",
        "images_hint": IMAGES_HINT,
        "works": works,
    }

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
    print(f"Wrote {OUT_PATH} ({len(works)} works)")


if __name__ == "__main__":
    main()
