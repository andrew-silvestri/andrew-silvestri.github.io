#!/usr/bin/env python3
"""Museum wallpaper generator.

Renders a dark "gallery wall" wallpaper from a collection manifest:
one or three artworks on a near-black canvas, each with a museum
plaque (title / artist / date - medium) underneath.

Usage:
    python wallpaper.py --collection collections/philbrook
        [--size 2560x1440] [--mode triptych|single] [--out file.png]
        [--filter paintings|none] [--seed N] [--images DIR] [--set] [--undo]

Only stdlib + Pillow. --set / --undo touch exactly one state file
(undo_wallpaper.json next to this script) and are fully reversible.
"""

import argparse
import json
import os
import random
import re
import sys

from PIL import Image, ImageDraw, ImageFont

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
UNDO_FILE = os.path.join(SCRIPT_DIR, "undo_wallpaper.json")

BACKGROUND = (18, 18, 18)
PLAQUE_BG = (30, 30, 30)
TITLE_FG = (230, 230, 230)
CREATOR_FG = (200, 200, 200)
INFO_FG = (170, 170, 170)

# Media that count as "paintings" for --filter paintings.
PAINTING_RE = re.compile(
    r"oil|acrylic|tempera|canvas|panel|watercolor|gouache|fresco", re.IGNORECASE
)

# Serif candidates first (museum plaques), then anything legible.
FONT_CANDIDATES = [
    "DejaVuSerif.ttf", "Georgia.ttf", "georgia.ttf",
    "Times New Roman.ttf", "times.ttf", "DejaVuSans.ttf", "arial.ttf",
]
FONT_BOLD_CANDIDATES = [
    "DejaVuSerif-Bold.ttf", "Georgia Bold.ttf", "georgiab.ttf",
    "timesbd.ttf", "DejaVuSans-Bold.ttf", "arialbd.ttf",
]


# ---------------------------------------------------------------- fonts

def load_font(candidates, size):
    for name in candidates:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)  # Pillow >= 9.2 scalable default
    except TypeError:
        return ImageFont.load_default()


def line_height(font):
    ascent, descent = font.getmetrics()
    return ascent + descent


def wrap_text(text, font, max_px, max_lines=3):
    """Greedy word wrap by measured pixel width; ellipsize past max_lines."""
    words = text.split()
    lines, current = [], ""
    for word in words:
        trial = (current + " " + word).strip()
        if font.getlength(trial) <= max_px or not current:
            current = trial
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        while lines[-1] and font.getlength(lines[-1] + "…") > max_px:
            lines[-1] = lines[-1][:-1].rstrip()
        lines[-1] += "…"
    return lines


# ---------------------------------------------------------------- manifest

def load_collection(collection_dir, images_override):
    manifest_path = os.path.join(collection_dir, "manifest.json")
    if not os.path.isfile(manifest_path):
        sys.exit(f"No manifest.json in {collection_dir}")
    with open(manifest_path, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    # Image dir: explicit override, then <collection>/images, then the
    # manifest's images_hint (lets philbrook reuse the existing 60 MB
    # folder in PyProjects instead of copying it here).
    candidates = []
    if images_override:
        candidates.append(images_override)
    candidates.append(os.path.join(collection_dir, "images"))
    hint = manifest.get("images_hint")
    if hint:
        candidates.append(os.path.normpath(os.path.join(collection_dir, hint)))

    images_dir = next((c for c in candidates if os.path.isdir(c)), None)
    if images_dir is None:
        sys.exit(
            "No image folder found. Tried:\n  " + "\n  ".join(candidates)
            + "\nRun this collection's fetch.py first, or pass --images DIR."
        )
    return manifest, images_dir


def select_works(manifest, images_dir, mode, filter_name, rng):
    works = manifest.get("works", [])
    if filter_name == "paintings":
        works = [w for w in works if PAINTING_RE.search(w.get("medium", ""))]
    works = [w for w in works
             if os.path.isfile(os.path.join(images_dir, w.get("file", "")))]
    if not works:
        sys.exit(f"No usable works (after filter '{filter_name}') with images "
                 f"in {images_dir}")
    count = 3 if mode == "triptych" else 1
    if len(works) < count:
        count = len(works)  # e.g. single-work collections
    return rng.sample(works, count)


# ---------------------------------------------------------------- rendering

def resize_to_fit(img, max_w, max_h):
    w, h = img.size
    scale = min(max_w / w, max_h / h, 1.0)  # never upscale past native size
    if scale >= 1.0:
        return img
    return img.resize((max(1, int(w * scale)), max(1, int(h * scale))),
                      Image.LANCZOS)


class PlaqueRenderer:
    def __init__(self, canvas_h, canvas_w):
        self.title_font = load_font(FONT_BOLD_CANDIDATES, max(14, canvas_h // 42))
        self.body_font = load_font(FONT_CANDIDATES, max(12, canvas_h // 52))
        self.small_font = load_font(FONT_CANDIDATES, max(11, canvas_h // 60))
        self.pad = max(10, canvas_h // 110)
        self.min_width = canvas_w // 8

    def layout(self, work, img_width):
        width = max(img_width, self.min_width)
        inner = width - 2 * self.pad
        title_lines = wrap_text(work.get("title", "Unknown"),
                                self.title_font, inner)
        height = (self.pad
                  + len(title_lines) * line_height(self.title_font) + 4
                  + line_height(self.body_font) + 2
                  + line_height(self.small_font)
                  + self.pad)
        return width, height, title_lines

    def draw(self, draw, work, x, y, width, title_lines):
        _, height, _ = self.layout(work, width)
        draw.rectangle([x, y, x + width, y + height], fill=PLAQUE_BG)
        tx, ty = x + self.pad, y + self.pad
        for line in title_lines:
            draw.text((tx, ty), line, font=self.title_font, fill=TITLE_FG)
            ty += line_height(self.title_font)
        ty += 4
        draw.text((tx, ty), work.get("creator", "Unknown"),
                  font=self.body_font, fill=CREATOR_FG)
        ty += line_height(self.body_font) + 2
        info = " — ".join(p for p in (work.get("date", ""),
                                           work.get("medium", "")) if p)
        info = wrap_text(info, self.small_font, width - 2 * self.pad,
                         max_lines=1)[0] if info else ""
        draw.text((tx, ty), info, font=self.small_font, fill=INFO_FG)


def render(works, images_dir, size, mode):
    W, H = size
    canvas = Image.new("RGB", (W, H), BACKGROUND)
    draw = ImageDraw.Draw(canvas)
    plaques = PlaqueRenderer(H, W)
    gap = max(8, H // 120)          # image-to-plaque gap
    spacing = int(W * 0.035)        # between triptych works

    # Zone sizes as fractions of the canvas, so any --size lays out the
    # same way (the old script hardcoded pixel zones for 3840x2400).
    if mode == "triptych" and len(works) == 3:
        zones = [(int(W * 0.44), int(H * 0.60)),   # center, larger
                 (int(W * 0.24), int(H * 0.42)),   # left
                 (int(W * 0.24), int(H * 0.42))]   # right
    else:
        zones = [(int(W * 0.62), int(H * 0.70))] * len(works)

    images = []
    for work, (mw, mh) in zip(works, zones):
        img = Image.open(os.path.join(images_dir, work["file"])).convert("RGB")
        images.append(resize_to_fit(img, mw, mh))

    def place(work, img, x_img):
        pw, ph, title_lines = plaques.layout(work, img.width)
        block_h = img.height + gap + ph
        y = (H - block_h) // 2
        canvas.paste(img, (x_img, y))
        px = x_img + (img.width - pw) // 2  # center plaque under artwork
        plaques.draw(draw, work, px, y + img.height + gap, pw, title_lines)

    center_x = (W - images[0].width) // 2
    place(works[0], images[0], center_x)
    if len(works) == 3:
        place(works[1], images[1], center_x - spacing - images[1].width)
        place(works[2], images[2], center_x + images[0].width + spacing)
    return canvas


# ------------------------------------------------------- Windows wallpaper

SPI_SETDESKWALLPAPER = 20
SPIF_UPDATEINIFILE_SENDCHANGE = 3


def _apply_wallpaper(path):
    import ctypes
    ok = ctypes.windll.user32.SystemParametersInfoW(
        SPI_SETDESKWALLPAPER, 0, path, SPIF_UPDATEINIFILE_SENDCHANGE)
    if not ok:
        sys.exit("SystemParametersInfoW failed to set the wallpaper.")


def set_wallpaper(image_path):
    if os.name != "nt":
        sys.exit("--set only works on Windows.")
    # Save the current wallpaper once, so --undo can restore it. Never
    # overwrite an existing snapshot: repeated --set runs must not lose
    # the user's original wallpaper.
    if not os.path.exists(UNDO_FILE):
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                            r"Control Panel\Desktop") as key:
            previous, _ = winreg.QueryValueEx(key, "WallPaper")
        with open(UNDO_FILE, "w", encoding="utf-8") as f:
            json.dump({"previous_wallpaper": previous}, f, indent=2)
        print(f"Saved previous wallpaper to {UNDO_FILE}")
    _apply_wallpaper(os.path.abspath(image_path))
    print("Wallpaper set.")


def undo_wallpaper():
    if os.name != "nt":
        sys.exit("--undo only works on Windows.")
    if not os.path.exists(UNDO_FILE):
        sys.exit(f"Nothing to undo ({UNDO_FILE} not found).")
    with open(UNDO_FILE, "r", encoding="utf-8") as f:
        previous = json.load(f).get("previous_wallpaper", "")
    _apply_wallpaper(previous)
    os.remove(UNDO_FILE)
    print(f"Restored previous wallpaper: {previous or '(none)'}")


# ---------------------------------------------------------------- main

def parse_size(text):
    m = re.fullmatch(r"(\d+)x(\d+)", text.strip().lower())
    if not m:
        raise argparse.ArgumentTypeError("size must look like 2560x1440")
    return int(m.group(1)), int(m.group(2))


def detect_size():
    if os.name == "nt":
        import ctypes
        w = ctypes.windll.user32.GetSystemMetrics(0)
        h = ctypes.windll.user32.GetSystemMetrics(1)
        if w and h:
            return w, h
    sys.exit("Cannot detect screen size on this platform; pass --size WxH.")


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--collection",
                    default=os.path.join(SCRIPT_DIR, "collections", "philbrook"))
    ap.add_argument("--size", type=parse_size, default=None,
                    help="canvas size WxH; auto-detected on Windows")
    ap.add_argument("--mode", choices=["triptych", "single"], default=None,
                    help="default: manifest default_mode, else triptych")
    ap.add_argument("--out", default=os.path.join(SCRIPT_DIR, "wallpaper.png"))
    ap.add_argument("--filter", dest="filter_name",
                    choices=["paintings", "none"], default=None,
                    help="default: manifest default_filter, else none")
    ap.add_argument("--seed", type=int, default=None,
                    help="deterministic artwork selection")
    ap.add_argument("--images", default=None,
                    help="override image folder for the collection")
    ap.add_argument("--set", action="store_true", dest="set_",
                    help="set as Windows wallpaper (saves undo state first)")
    ap.add_argument("--undo", action="store_true",
                    help="restore the wallpaper saved by --set and exit")
    args = ap.parse_args()

    if args.undo:
        undo_wallpaper()
        return

    size = args.size or detect_size()
    manifest, images_dir = load_collection(args.collection, args.images)
    mode = args.mode or manifest.get("default_mode", "triptych")
    filter_name = args.filter_name or manifest.get("default_filter", "none")
    rng = random.Random(args.seed)

    works = select_works(manifest, images_dir, mode, filter_name, rng)
    canvas = render(works, images_dir, size, mode)
    canvas.save(args.out)
    print(f"Wrote {args.out} ({size[0]}x{size[1]}, {len(works)} work(s) "
          f"from {manifest.get('name', args.collection)})")
    for w in works:
        print(f"  - {w.get('title')} ({w.get('creator')}, {w.get('date')})")

    if args.set_:
        set_wallpaper(args.out)


if __name__ == "__main__":
    main()
