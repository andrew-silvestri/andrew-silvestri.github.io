#!/usr/bin/env python3
"""Download Harry Ransom Center images for the works in manifest.json.

The Center's exhibition pages do not publish og:image meta tags, so
each work in the manifest carries an "image_url" that was verified
directly against the live page (the same image the Center embeds).
Works without a verified image_url are reported as unresolved rather
than guessed at.

Stdlib only. Run on your own machine; images land in images/.
"""

import json
import os
import re
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(HERE, "images")
UA = {"User-Agent": "desktop-gallery-wallpaper/1.0 (personal use)"}

OG_IMAGE_RE = re.compile(
    r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']')


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def main():
    with open(os.path.join(HERE, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    os.makedirs(IMAGES_DIR, exist_ok=True)

    unresolved, failed = [], []
    for work in manifest["works"]:
        dest = os.path.join(IMAGES_DIR, work["file"])
        if os.path.exists(dest):
            print(f"skip (exists): {work['title']}")
            continue
        image_url = work.get("image_url")
        if not image_url:
            # Last resort: check for an og:image on the item page, but
            # never invent an image URL.
            try:
                html = get(work["url"]).decode("utf-8", errors="replace")
                m = OG_IMAGE_RE.search(html)
                image_url = m.group(1) if m else None
            except Exception:
                image_url = None
        if not image_url:
            unresolved.append(f"{work['title']} ({work['url']})")
            continue
        try:
            data = get(image_url)
            with open(dest, "wb") as f:
                f.write(data)
            print(f"ok: {work['title']} ({len(data) // 1024} KB)")
        except Exception as exc:
            failed.append(work["title"])
            print(f"FAILED: {work['title']}: {exc}", file=sys.stderr)
        time.sleep(1)

    if unresolved:
        print("\nCould not resolve an image for:", *unresolved, sep="\n  ")
    if failed:
        print(f"\n{len(failed)} download(s) failed:", *failed, sep="\n  ")
    if unresolved or failed:
        sys.exit(1)
    print("\nAll images downloaded.")


if __name__ == "__main__":
    main()
