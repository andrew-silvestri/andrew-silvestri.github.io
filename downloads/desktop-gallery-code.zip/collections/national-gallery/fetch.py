#!/usr/bin/env python3
"""Download National Gallery images for the works in manifest.json.

Verified against the live site: painting pages embed a IIIF image
service path like
    server.iip?IIIF=/fronts/N-0524-00-000102-XL-PYR.tif/full/!80,50/0/default.jpg
(the pages do not publish an og:image tag). We take the first /fronts/
tile path and re-request it at wallpaper resolution via the standard
IIIF size syntax. If that fails we fall back to the page's "thumbnail"
meta tag (an 800px crop — usable, but the IIIF route is preferred).

Stdlib only. Run on your own machine; images land in images/.
"""

import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(HERE, "images")
BASE = "https://www.nationalgallery.org.uk"
UA = {"User-Agent": "desktop-gallery-wallpaper/1.0 (personal use)"}

IIIF_RE = re.compile(r'server\.iip\?IIIF=(/fronts/[^/"\']+?-PYR\.tif)')
THUMB_RE = re.compile(
    r'<meta[^>]+name=["\']thumbnail["\'][^>]+content=["\']([^"\']+)["\']')


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def resolve_image(html):
    m = IIIF_RE.search(html)
    if m:
        # !2400,2400 = fit within a 2400px box, preserving aspect ratio.
        return (f"{BASE}/server.iip?IIIF={m.group(1)}"
                "/full/!2400,2400/0/default.jpg")
    m = THUMB_RE.search(html)
    if m:
        return urllib.parse.urljoin(BASE, m.group(1).replace("&amp;", "&"))
    return None


def main():
    with open(os.path.join(HERE, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    os.makedirs(IMAGES_DIR, exist_ok=True)

    failed = []
    for work in manifest["works"]:
        dest = os.path.join(IMAGES_DIR, work["file"])
        if os.path.exists(dest):
            print(f"skip (exists): {work['title']}")
            continue
        try:
            html = get(work["url"]).decode("utf-8", errors="replace")
            image_url = resolve_image(html)
            if not image_url:
                raise RuntimeError("no IIIF path or thumbnail meta found")
            data = get(image_url)
            with open(dest, "wb") as f:
                f.write(data)
            print(f"ok: {work['title']} ({len(data) // 1024} KB)")
        except Exception as exc:
            failed.append(work["title"])
            print(f"FAILED: {work['title']}: {exc}", file=sys.stderr)
        time.sleep(1)  # be polite to the museum's servers

    if failed:
        print(f"\n{len(failed)} work(s) could not be fetched:", *failed,
              sep="\n  ")
        sys.exit(1)
    print("\nAll images downloaded.")


if __name__ == "__main__":
    main()
