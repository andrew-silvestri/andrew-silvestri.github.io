#!/usr/bin/env python3
"""Download the Wright of Derby painting via the Wikimedia Commons API.

The Commons file title in manifest.json was verified against the live
Commons page (original: 4724x6126, ~5.9 MB, public domain / PD-Art).
The imageinfo API returns the direct URL to the original upload.

Stdlib only. Run on your own machine; the image lands in images/.
"""

import json
import os
import sys
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(HERE, "images")
API = "https://commons.wikimedia.org/w/api.php"
# Commons policy asks for a descriptive User-Agent.
UA = {"User-Agent": "desktop-gallery-wallpaper/1.0 (personal use)"}


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read()


def commons_original_url(file_title):
    query = urllib.parse.urlencode({
        "action": "query",
        "titles": file_title,
        "prop": "imageinfo",
        "iiprop": "url",
        "format": "json",
    })
    data = json.loads(get(f"{API}?{query}"))
    pages = data["query"]["pages"]
    for page in pages.values():
        info = page.get("imageinfo")
        if info:
            return info[0]["url"]
    raise RuntimeError(f"Commons API returned no imageinfo for {file_title}")


def main():
    with open(os.path.join(HERE, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    os.makedirs(IMAGES_DIR, exist_ok=True)

    for work in manifest["works"]:
        dest = os.path.join(IMAGES_DIR, work["file"])
        if os.path.exists(dest):
            print(f"skip (exists): {work['title']}")
            continue
        try:
            url = commons_original_url(work["commons_file"])
            data = get(url)
            with open(dest, "wb") as f:
                f.write(data)
            print(f"ok: {work['title']} ({len(data) // 1024} KB)")
        except Exception as exc:
            print(f"FAILED: {work['title']}: {exc}", file=sys.stderr)
            sys.exit(1)
    print("Done.")


if __name__ == "__main__":
    main()
