#!/usr/bin/env python3
"""Download Philbrook images for the works in manifest.json.

The museum's eMuseum site serves each work's full-resolution image from
a stable media dispatcher endpoint (the same one the original scrapers
in PyProjects/philbrook_museum/archiveScripts — xhr_scraper.py and
selenium_slow_downloader.py — used to fill images_full/):

    https://philbrook.emuseum.com/internal/media/dispatcher/<id>/full

where <id> is each work's dispatcher id, stored as "id" in
manifest.json (its "file" is <id>.jpg).

Stdlib only. Run on your own machine; images land in images/ next to
this script. Note: if the PyProjects/philbrook_museum/images_full
folder happens to sit next to this repo, wallpaper.py already finds it
via the manifest's images_hint and you don't need to run this at all.
"""

import json
import os
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(HERE, "images")
UA = {"User-Agent": "desktop-gallery-wallpaper/1.0 (personal use)"}

DISPATCHER_URL = "https://philbrook.emuseum.com/internal/media/dispatcher/{id}/full"


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def main():
    with open(os.path.join(HERE, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    os.makedirs(IMAGES_DIR, exist_ok=True)

    failed = []
    for work in manifest["works"]:
        dest = os.path.join(IMAGES_DIR, work["file"])
        if os.path.exists(dest):
            print(f"skip (exists): {work['title']}")
            continue
        try:
            data = get(DISPATCHER_URL.format(id=work["id"]))
            if data[:1] == b"<":  # HTML error page, not an image
                raise RuntimeError("server returned a page, not an image")
            with open(dest, "wb") as f:
                f.write(data)
            print(f"ok: {work['title']} ({len(data) // 1024} KB)")
        except Exception as exc:
            failed.append(work["title"])
            print(f"FAILED: {work['title']}: {exc}", file=sys.stderr)
        time.sleep(1)  # be polite to the museum's servers

    if failed:
        print(f"\n{len(failed)} work(s) could not be fetched:", *failed,
              sep="\n  ")
        sys.exit(1)
    print("\nAll images downloaded.")


if __name__ == "__main__":
    main()
