#!/usr/bin/env python3
"""Download Louvre images for the works in manifest.json.

Each work's page at collections.louvre.fr exposes an og:image meta tag
(verified against the live site), e.g.
    https://collections.louvre.fr/media/cache/medium/.../0000868046_OG.JPG
We parse that tag from the item's HTML page. As an optimistic upgrade we
first try swapping the "medium" cache size for "large"; if that 404s we
fall back to the og:image URL exactly as published.

Stdlib only. Run on your own machine; images land in images/ next to
this script.
"""

import json
import os
import re
import sys
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
IMAGES_DIR = os.path.join(HERE, "images")
UA = {"User-Agent": "desktop-gallery-wallpaper/1.0 (personal use)"}

OG_IMAGE_RE = re.compile(
    r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']')


def get(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def main():
    with open(os.path.join(HERE, "manifest.json"), encoding="utf-8") as f:
        manifest = json.load(f)
    os.makedirs(IMAGES_DIR, exist_ok=True)

    failed = []
    for work in manifest["works"]:
        dest = os.path.join(IMAGES_DIR, work["file"])
        if os.path.exists(dest):
            print(f"skip (exists): {work['title']}")
            continue
        try:
            html = get(work["url"]).decode("utf-8", errors="replace")
            m = OG_IMAGE_RE.search(html)
            if not m:
                raise RuntimeError("no og:image meta tag found")
            og_url = m.group(1)
            data = None
            if "/medium/" in og_url:
                try:  # larger rendition if the cache offers one
                    data = get(og_url.replace("/medium/", "/large/"))
                except Exception:
                    data = None
            if data is None:
                data = get(og_url)
            with open(dest, "wb") as f:
                f.write(data)
            print(f"ok: {work['title']} ({len(data) // 1024} KB)")
        except Exception as exc:
            failed.append(work["title"])
            print(f"FAILED: {work['title']}: {exc}", file=sys.stderr)
        time.sleep(1)  # be polite to the museum's servers

    if failed:
        print(f"\n{len(failed)} work(s) could not be fetched:", *failed,
              sep="\n  ")
        sys.exit(1)
    print("\nAll images downloaded.")


if __name__ == "__main__":
    main()
