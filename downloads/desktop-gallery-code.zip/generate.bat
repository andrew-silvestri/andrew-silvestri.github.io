@echo off
rem Self-bootstrapping wallpaper generator (Philbrook collection).
rem Normal run: renders a gallery-wall wallpaper and sets it as your
rem desktop background. First run: creates .venv and installs Pillow,
rem which needs Python installed once on this machine (python.org).

cd /d "%~dp0"

if exist "%~dp0.venv\Scripts\python.exe" goto run

rem ----- First run: find a Python to bootstrap with -----
set "PYTHON="
py -3 -c "" >nul 2>&1 && set "PYTHON=py -3"
if not defined PYTHON python -c "" >nul 2>&1 && set "PYTHON=python"
if not defined PYTHON (
    echo.
    echo Python was not found on this machine.
    echo Install it once from  https://www.python.org/downloads/
    echo during install, check the box "Add python.exe to PATH".
    echo Then double-click this file again.
    echo.
    pause
    exit /b 1
)

echo First run: setting up, takes a few minutes. Later runs are instant.
echo Creating private environment .venv ...
%PYTHON% -m venv "%~dp0.venv"
if not exist "%~dp0.venv\Scripts\python.exe" (
    echo.
    echo Could not create the .venv folder - see any error above.
    pause
    exit /b 1
)

echo Installing Pillow into .venv - please wait ...
"%~dp0.venv\Scripts\python.exe" -m pip install --quiet pillow
if errorlevel 1 (
    echo.
    echo pip install failed - are you online? See the error above.
    pause
    exit /b 1
)

:run
"%~dp0.venv\Scripts\python.exe" "%~dp0wallpaper.py" --collection "collections\philbrook" --set
if errorlevel 1 (
    echo.
    echo The generator reported a problem - see the message above.
    echo If it says images are missing, download them first with:
    echo     .venv\Scripts\python.exe collections\philbrook\fetch.py
)
echo.
echo To put your old wallpaper back at any time, run:
echo     .venv\Scripts\python.exe wallpaper.py --undo
echo.
pause
