# Desktop Gallery

A small, config-driven wallpaper generator. It composes a dark "museum
wall" from a collection of artworks — one work or a triptych, each with
a plaque underneath giving the title, artist, and date/medium — and can
optionally set the result as the Windows desktop wallpaper. It
generalizes the one-off script that lived in
`PyProjects/philbrook_museum/archiveScripts/wallpaper_generator.py`:
instead of hardcoded 3840x2400 pixel zones, the layout is derived as
fractions of whatever canvas size you ask for, and the artwork list
comes from a `manifest.json` per collection rather than being baked in.

## Quickstart

Double-click `generate.bat` — first run sets itself up (creates a
private `.venv` here and installs Pillow into it; needs Python
installed once, from python.org); every run after is instant. It
renders a Philbrook triptych and sets it as your wallpaper, then
prints the undo command. Nothing is written outside this folder except
the wallpaper itself and one undo file (`undo_wallpaper.json`).

Philbrook images: run `collections\philbrook\fetch.py` once to
download them into `collections\philbrook\images\` from the museum's
own site. (Soft fallback: if this folder happens to sit next to
`PyProjects/`, the manifest's `images_hint` reuses the existing
`philbrook_museum/images_full` folder and no download is needed.)

Or run it by hand with any Python that has Pillow:

    python wallpaper.py --collection collections/philbrook

On Windows the screen size is auto-detected; elsewhere pass
`--size 2560x1440`. Other useful flags:

    --mode single          one centered work instead of a triptych
    --seed 7               deterministic pick (same works every run)
    --out my.png           where to write the image
    --filter paintings     only oil/tempera/watercolor/etc. media
    --images DIR           use a different image folder
    --set                  also set it as the Windows wallpaper
    --undo                 restore whatever wallpaper you had before

The other collections ship metadata only. Before first use, download
their images (on your machine, from the museums' own sites):

    cd collections/louvre && python fetch.py

Same for `national-gallery`, `wright-alchemist` (a single painting;
its manifest defaults to `--mode single`), and `ransom-center`.

## The --set / --undo contract

`--set` is deliberately non-invasive. Before changing anything it reads
your current wallpaper path from the registry
(`HKCU\Control Panel\Desktop\WallPaper`) and saves it to
`undo_wallpaper.json` next to `wallpaper.py` — but only if that file
does not already exist, so repeated runs never lose your original
wallpaper. Then it applies the new image via `SystemParametersInfoW`.
`--undo` restores the saved path the same way and deletes
`undo_wallpaper.json`. That is the entire footprint: one state file in
this folder, fully reversible, nothing written anywhere else on your
system.

## Why images are fetched, not shipped

The artworks in these collections are in the public domain, but the
photographs of them are published by the museums on their own sites,
under their own terms of use (the Louvre and the National Gallery, for
example, permit personal and non-commercial use but not redistribution
of their photography). Shipping the image files with this project would
amount to redistributing them; pointing `fetch.py` at each museum's own
public pages keeps the museums in control of their files and keeps this
repository small. The code and the metadata — verified titles, dates,
inventory numbers, and stable collection URLs — are the project; the
pixels stay where the museums put them, and each `manifest.json`
carries a `license_note` saying exactly where its images come from.
