# The Deep Search: Historical Algorithms for Consumers, Markets, and Energy

Every quantitative device v4 uses (or stubs for you), with lineage. These are the
"known laws" of how humans and energy systems behave over decades — the toolkit for
looking future-forward. Items marked **[coded]** are implemented in `v4/cohorts.py`.

## 1. Adoption & diffusion (how habits change)

- **Bass diffusion (1969)** — adoption rate = (p + q·F(t))·(1−F(t)): innovators p ≈
  0.01–0.03, imitators q ≈ 0.3–0.5. The workhorse for EV/rooftop-solar/appliance
  uptake; the most used model in the EV literature. **[coded: EV fleet share]**
- **Logistic / Fisher–Pry (1971) substitution** — technology share follows an S-curve
  in log-odds; Marchetti & Nakićenović (1979) showed *global primary energy* substitutions
  (wood→coal→oil→gas) follow logistic waves with ~50-year time constants. **[coded]**
- **Gompertz (1825)** — asymmetric S-curve, born from mortality law; the standard fit
  for **car ownership vs GDP per capita** (slow start, fast middle, saturation
  ~500–850 vehicles/1000 people). **[coded: fleet size per district]**
- **Rogers (1962) adopter categories** — innovators/early/majority/laggards; v4's
  consumer mentalities (green/neutral/consumerist) are a coarse Rogers segmentation.
- **Discrete choice / multinomial logit (McFadden 1974)** — P(choice) ∝ exp(utility);
  the standard for fuel-type and mode choice (car vs rail). **[coded: mode split]**

## 2. Markets (how prices form and cycle)

- **Marshallian supply/demand + merit order** — v3's dispatch core; clearing price =
  marginal unit cost. Modern power-market foundation.
- **Cobweb theorem (Kaldor 1934)** — lagged supply response → oscillations; classic in
  **fertilizer and agricultural markets** (plant this year on last year's price).
  **[coded: farm N-demand lag]**
- **Hotelling's rule (1931)** — exhaustible-resource price rises at the interest rate;
  the theoretical spine of oil-in-the-ground valuation (honored mostly in the breach —
  see the 1986 and 2014 gluts).
- **Hubbert logistic depletion (1956)** — production bell curves; called the US lower-48
  1970 peak; broken by the shale learning curve (see Wright).
- **Theory of storage (Kaldor–Working)** — convenience yield links inventories to
  backwardation/contango; explains why negative WTI (Apr 2020) happened at Cushing.
- **Jevons paradox (1865, *The Coal Question*)** + **Khazzoom–Brookes rebound** —
  efficiency lowers effective price → demand rebound 10–30% (direct) for driving/heating;
  economy-wide estimates higher. **[coded: rebound machinery from v2, per mentality]**
- **Kilian (2009) shock decomposition** — oil price moves split into supply, aggregate
  demand, and precautionary demand shocks; v4's event library tags each historical
  event with its Kilian type.

## 3. Cost dynamics (why technologies get cheap)

- **Wright's law (1936)** — cost falls ~20% per doubling of cumulative production
  (solar PV ~20%, batteries ~18%, wind ~12%; observed since 1925 aircraft data,
  formalized by Arrow's learning-by-doing, 1962). Beats Moore-style time trends for
  energy tech forecasting. **[coded: solar/battery/electrolyzer cost curves]**
- **Experience-curve pitfalls** — floor costs (balance-of-system), and cost UP-curves
  (nuclear post-1970s regulatory ratchet: "negative learning", Grubler 2010).

## 4. Demand fundamentals (the human layer)

- **Price elasticities (survey values)** — gasoline: ≈ −0.05 to −0.09 short-run, −0.3
  long-run; residential electricity ≈ −0.1/−0.3; natural gas ≈ −0.1/−0.5. Short-run
  inelasticity is why supply shocks spike prices. **[coded per cohort]**
- **Income elasticities / Engel curves** — energy is a normal good until saturation;
  meat consumption follows income with saturation ~80–120 kg/cap/yr (US flat since
  1970s, China quadrupled since 1980). **[coded: diet cohorts]**
- **Kaya identity (1990)** — CO₂ = pop × GDP/pop × energy/GDP × CO₂/energy; v4's
  climate tab decomposes district emissions this way.
- **Demographic transition + urbanization S-curves** — drive rail-share vs car-share;
  rail mode share high where density high (JP ~30% pkm rail vs US ~0.3%). **[coded]**
- **Haber–Bosch fertilizer demand (1913→)** — ~1–2% of world energy; N-fertilizer use
  roughly linear in cereal output since 1960 (Green Revolution); natural-gas feedstock
  → ammonia price tracks gas price with ~0.7 pass-through, demand responds with
  cobweb lag. **[coded: farm cohorts]**
- **Data centers** — ~1–1.5% of global electricity 2010–2020 (efficiency offset growth:
  Koomey), AI buildout breaks the flat trend post-2023 (~15–25%/yr power growth).
  **[coded: datacenter cohorts + buildout scenario]**

## 4b. The unconscious mind (behavioral substrate layer) **[coded: psych nodes]**

v4 gives every district six psychological-substrate nodes that modulate its consumer
cohorts — the layer beneath stated preferences:

- **Habit inertia** — Becker–Murphy rational habit formation (1988); energy use is
  ~70% habitual; inertia damps short-run response (why SR elasticities are tiny).
- **Loss aversion** — Kahneman–Tversky prospect theory (1979): price *increases* hurt
  ~2× more than equivalent savings please; activated by fuel-cost shocks, it
  over-drives conservation and hoarding (1973 gas lines were partly this).
- **Cognitive dissonance** — Festinger (1957): green identity + high-carbon behavior
  builds tension that resolves in delayed, discontinuous behavior change (EV purchase,
  diet shift) rather than smooth elasticity. Modeled as an accumulator node charged by
  fuel-price stress × green-mentality density, discharging into EV adoption and
  oil-demand relief.
- **Social norm conformity** — Cialdini; Opower RCTs showed ~2% durable conservation
  from neighbor-comparison alone; norms propagate district-to-district.
- **Status signaling** — Veblen (1899): trucks and Teslas both; couples adoption to
  identity, not price (why EV uptake maps poorly onto fuel-savings math).
- **Present bias** — Laibson hyperbolic discounting (1997): the efficiency-gap
  explanation; blocks positive-NPV retrofits, damps long-run response edges.

The attitude–behavior gap (~30% claim green intent, ~3-5% pay green premia) is the
calibration anchor for how weakly mentality couples to behavior at baseline — and
dissonance is the mechanism that closes the gap under sustained stress.

## 5. Historical events encoded in v4 (`v4/history.py`), with observed anchors

| Event | Year | Kilian type | Observed anchor |
|---|---|---|---|
| OPEC embargo | 1973–74 | supply | oil $2.90→$11.65/bbl (~×4); US demand fell only ~6% (SR elasticity ~−0.05) |
| Iranian revolution | 1979 | supply+precaution | oil ×2.5; global demand −10% over 4 yrs (LR elasticity kicks in) |
| Oil glut / OPEC quota collapse | 1986 | supply(+) | oil $27→$14 in months; demand rebound |
| Gulf War spike | 1990 | precaution | oil ×2 in 2 months, fully retraced in 6 |
| Global Financial Crisis | 2008–09 | agg. demand | oil $147→$34; electricity demand −4-5% OECD |
| Fukushima | 2011 | policy | JP nuclear 30%→~0; LNG imports +25%, JKM premium era |
| **COVID-19** | 2020 | agg. demand | oil demand −20 Mb/d (−20%) Apr; **WTI −$37**; road transport −50-75%; electricity −15-25% lockdown regions |
| Winter Storm Uri | 2021 | weather | ERCOT $9,000 cap 4 days; HH spot ×8; 4.5M customers shed |
| Russia/Ukraine | 2022 | supply+precaution | TTF ~€340/MWh (~×10); Brent $128; EU gas demand −15% (record LR response) |

Model-vs-history comparison table is generated at run time (`outputs/event_validation.csv`).

## 6. What v4 deliberately simplifies (so you know where the bodies are buried)

No general-equilibrium income feedback (an oil shock that causes a recession that cuts
demand is half-coded via demand-destruction edges, not a macro model); no endogenous
investment (Wright curves are exogenous scenarios); cobweb lags are one-period;
behavioral parameters are point estimates, not distributions.

## Sources (deep-search pass)

[Bass model & new-auto tech coefficients](https://www.sciencedirect.com/science/article/abs/pii/S0739885915000220) ·
[Bass/Gompertz/logistic comparison](https://www.researchgate.net/publication/345180609_Predicting_Product_Uptake_Using_Bass_Gompertz_and_Logistic_Diffusion_Models_Application_to_a_Broadband_Product) ·
[Bass for renewable-energy policy](https://archiv.soms.ethz.ch/teaching/MatlabFall10/projects/BassInnovationDiffusionModelApplicationInPolicyAnalysisForAdoptionOfRETechnologies_Ostojic.pdf) ·
[EV adoption S-curves](https://arxiv.org/pdf/2306.16152) ·
[1973 oil shock (Federal Reserve History)](https://www.federalreservehistory.org/essays/oil-shock-of-1973-74) ·
[Baker Institute 50-year embargo review](https://www.bakerinstitute.org/research/chaos-energy-markets-then-and-now-50-years-after-1973-arab-oil-embargo-review) ·
[Oil demand elasticities (Reed)](https://www.reed.edu/economics/parker/f10/201/cases/oil_demand.html) ·
[COVID oil demand −20% (IEA)](https://www.iea.org/news/global-oil-demand-to-decline-in-2020-as-coronavirus-weighs-heavily-on-markets) ·
[COVID petroleum price collapse (BLS)](https://www.bls.gov/opub/mlr/2020/article/from-the-barrel-to-the-pump.htm) ·
[300 years of energy price shocks (LSE/Grantham)](https://www.lse.ac.uk/granthaminstitute/wp-content/uploads/2014/03/WP153-Historical-energy-price-shocks-and-their-changing-effects-on-the-economy.pdf)
