# 13 — World Energy Web v4 (final run)

**957,350 nodes / 2,490,332 edges.** The v3 core (31k real plants, grids, markets,
chokepoints, weather, sun) plus, per district, the human machinery of energy demand:

| layer | nodes | what it is |
|---|---|---|
| car cohorts | 761,344 | model-year (1995–2026) × fuel (gasoline/diesel/hybrid/EV) × class (car/truck), era-correct efficiency |
| farms | 66,437 | rural nitrogen-fertilizer demand via gas → Haber-Bosch (4 world ammonia complexes) → fertilizer market, cobweb-lagged |
| core (v3) | 52,804 | real plants, grids, districts, consumers, markets, basins, chokepoints, pipelines, LNG, weather, sun, policy |
| households | 29,740 | income deciles, decile-specific elasticity |
| **psych (unconscious mind)** | 17,844 | habit inertia · loss aversion · status signaling · cognitive dissonance · social norms · present bias — per district, modulating consumers |
| diet cohorts | 11,896 | heavy-meat → plant, coupled to the grain market |
| transit | 8,922 | rail commuters (grid-fed), bus, air travelers (jet-fuel-fed) |
| datacenters | 4,461 | conventional + AI-era, fed by an AI-compute demand node |
| climate cells | 2,974 | district anomaly cells under a global climate-system node (Climate tab) |
| chain | 9 | ammonia complexes, fertilizer/grain markets, climate system, global temp, AI demand |

Array-native engine (`v4/engine4.py`, scipy.sparse): full build ~5 s, a million-node
propagation ~1 s in ~3 GB RAM. NetworkX is used only for the core.

## The deep search

`HISTORICAL_ALGORITHMS.md` — the compendium: Bass/logistic/Gompertz diffusion, Wright's
law, Hotelling, cobweb, Hubbert, storage theory, Kilian decomposition, elasticity survey
values, Engel/meat curves, Kaya, Haber-Bosch demand, datacenter/Koomey trends, and the
behavioral-economics lineage behind the unconscious-mind layer (Festinger, Kahneman-
Tversky, Becker-Murphy, Laibson, Cialdini, Veblen). Items marked [coded] are live in
`v4/cohorts.py` and drive the Trends tab projections to 2040.

## Historical event replays (the headline)

`python3 run_v4.py` replays ten events 1973–2024 and validates model price multipliers
against the record (`outputs/event_validation.csv`, `fig2_validation.png`):

- 1973 OPEC embargo → 398k nodes, 383k car cohorts stressed, **zero farms** (oil isn't
  the fertilizer feedstock — the model gets the chemistry right)
- 2008 GFC / 2020 COVID → demand-collapse relief reaching **all 66,437 farms**
- 2022 Russia → 6,944 farms via the *European* ammonia complex (the real 2022
  fertilizer crisis pathway), TTF ×8.9 model vs ×9 observed
- Fukushima 2011 → the JP nuclear fleet (real WRI units) out, JKM pull
- Uri 2021 → ERCOT ×225 (calibration anchor), 94k nodes
- Out-of-sample fit: 7/10 points within ~factor-2; misses documented (1973 price
  controls, COVID negative prices need storage physics)

## Navigate it

**`navigator.html`** — the requested HTML artifact, fully self-contained (open in any
browser): Overview census · clickable 1973→2024 **Timeline** with per-event layer reach
and implied prices · **Event Runs** validation table · **Node Explorer** (search ~2,000
stratified samples: a 2019 EV cohort in an ERCOT district, a specific farm, a
dissonance node) · **Trends** (eight encoded engines, 1965→2040) · **Climate** tab ·
**Unconscious Mind** tab with per-event psych activation.

Plus the usual: five PNGs in `outputs/`, per-event impact CSVs, `v4_results.xlsx`.

## Caveats (final-run honesty)

Cohort populations are procedural (counts scaled by district demand and rural share),
not census microdata; the Bass EV curve is fitted to leader markets (global uptake lags
it ~5-8 yr — use `region_lead`); psych-layer weights are structural estimates anchored
only to the attitude-behavior-gap literature; validation is against price multipliers,
not volumes. Each is a data-swap away, same pattern as the WRI plant integration.
