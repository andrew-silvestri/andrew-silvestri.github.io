"""v4 figures."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .build4 import KINDS

KCOLOR = dict(core="#4C72B0", car="#DD8452", household="#55A868", diet="#C44E52",
              transit="#8172B3", farm="#937860", datacenter="#DA8BC3",
              climate_cell="#8C8C8C", psych="#CCB974", chain="#64B5CD")


def fig_census(w, path):
    counts = {k: int((w.kind == i).sum()) for i, k in enumerate(KINDS)}
    fig, ax = plt.subplots(figsize=(10, 5.5))
    ks = sorted(counts, key=lambda k: -counts[k])
    ax.bar(ks, [counts[k] for k in ks], color=[KCOLOR[k] for k in ks])
    for i, k in enumerate(ks):
        ax.text(i, counts[k] * 1.1, f"{counts[k]:,}", ha="center", fontsize=9)
    ax.set_yscale("log")
    ax.set_ylabel("nodes (log)")
    ax.set_title(f"v4 node census — {len(w.kind):,} nodes, "
                 f"{len(w.edges[2]):,} edges")
    ax.grid(axis="y", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def fig_validation(rows, path):
    fig, ax = plt.subplots(figsize=(8.5, 7))
    for r in rows:
        if r["model_mult"] is None or r["observed_mult"] <= 0:
            continue
        c = "tab:red" if r["calibration_anchor"] else "tab:blue"
        ax.scatter(r["observed_mult"], max(r["model_mult"], 0.01), s=90, c=c, zorder=3)
        ax.annotate(f"{r['event'][:14]}·{r['market'].replace('MKT_','')}",
                    (r["observed_mult"], max(r["model_mult"], 0.01)),
                    xytext=(6, 4), textcoords="offset points", fontsize=8)
    lims = [0.05, 300]
    ax.plot(lims, lims, "k--", lw=1, label="perfect")
    ax.plot(lims, [l * 2 for l in lims], "k:", lw=0.8)
    ax.plot(lims, [l / 2 for l in lims], "k:", lw=0.8, label="factor-2 band")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("observed price multiplier"); ax.set_ylabel("model multiplier")
    ax.set_title("Historical replay validation — red = calibration anchors (fit by\n"
                 "construction), blue = out-of-sample events")
    ax.legend(); ax.grid(alpha=0.3, which="both")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def fig_event_matrix(event_layers, path):
    events = list(event_layers)
    layers = KINDS
    M = np.array([[event_layers[e].get(k, {}).get("mean", 0) for k in layers]
                  for e in events])
    fig, ax = plt.subplots(figsize=(11, 0.5 * len(events) + 2.5))
    im = ax.imshow(M, cmap="inferno_r", aspect="auto")
    ax.set_xticks(range(len(layers))); ax.set_xticklabels(layers, rotation=35, ha="right")
    ax.set_yticks(range(len(events))); ax.set_yticklabels(events, fontsize=9)
    fig.colorbar(im, label="mean |stress|")
    ax.set_title("Historical events × v4 layers")
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def fig_trends(tr, path):
    fig, axes = plt.subplots(2, 3, figsize=(15, 8))
    plots = [("ev_share_sales_pct", "EV share of new sales (%) — Bass"),
             ("solar_cost_index", "Solar cost index — Wright 20%"),
             ("meat_kg_cap_emerging", "Meat kg/cap, emerging economy — Engel"),
             ("datacenter_power_index", "Datacenter power (2010=100) — AI break"),
             ("fleet_mpg_gasoline", "Gasoline fleet mpg — efficiency drift"),
             ("global_primary_share_coal", "Coal share of primary energy — Marchetti")]
    y = tr["years"]
    for ax, (key, title) in zip(axes.flat, plots):
        ax.plot(y, tr[key], lw=2.5)
        ax.axvline(2026, color="gray", ls=":", lw=1)
        ax.set_title(title, fontsize=10); ax.grid(alpha=0.3)
    fig.suptitle("Encoded historical trend engines (dotted line = today)", fontsize=13)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)


def fig_farm_response(event_farm, path):
    fig, ax = plt.subplots(figsize=(10, 5.5))
    evs = list(event_farm)
    vals = [event_farm[e] for e in evs]
    ax.barh(evs, vals, color="#937860")
    ax.set_xlabel("farms with |stress| ≥ 0.02 (of 66,437)")
    ax.set_title("Rural nitrogen/fertilizer demand response by historical event\n"
                 "(gas → Haber-Bosch → fertilizer market → farm cohorts)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout(); fig.savefig(path, dpi=150); plt.close(fig)
