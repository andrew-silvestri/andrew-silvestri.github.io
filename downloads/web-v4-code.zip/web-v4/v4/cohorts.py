"""
v4 cohort definitions + the historical trend functions (see HISTORICAL_ALGORITHMS.md).

Cohort node kinds appended to the v3 core, per district:
  car cohorts        model-year (1995..2026) x fuel (gasoline diesel hybrid ev) x class (car truck)
  household deciles  income d1..d10 with decile-specific elasticity
  diet cohorts       heavy-meat / moderate / low-meat / plant  (energy+land footprint)
  transit cohorts    rail-commuter / bus / air-traveler
  farm cohorts       rural farms with nitrogen-fertilizer demand (cobweb-lagged)
  datacenter         conventional + AI-era build-out
  climate cell       district climate anomaly node (climate tab layer)
plus global chain nodes: ammonia/Haber-Bosch plants, fertilizer market, grain market,
climate system (global temp anomaly, carbon cycle), AI compute demand.
"""
import numpy as np

CAR_YEARS = list(range(1995, 2027))          # 32 model years
CAR_FUELS = ["gasoline", "diesel", "hybrid", "ev"]
CAR_CLASSES = ["car", "truck"]

DIETS = [("heavy_meat", 1.00), ("moderate", 0.65), ("low_meat", 0.40), ("plant", 0.20)]
TRANSIT = ["rail_commuter", "bus_rider", "air_traveler"]
DECILES = 10


# ------------------------------------------------------------ trend functions
def bass(t, p=0.015, q=0.38):
    """Cumulative Bass adoption F(t), t in years from launch."""
    e = np.exp(-(p + q) * t)
    return (1 - e) / (1 + (q / p) * e)


def logistic_sub(t, t50, tau):
    """Fisher-Pry market-share substitution."""
    return 1.0 / (1.0 + np.exp(-(t - t50) / tau))


def gompertz(x, a=0.85, b=5.0, c=2.2):
    """Car ownership saturation vs income index x in (0, ~3]. Returns veh/adult."""
    return a * np.exp(-b * np.exp(-c * x))


def wright(cum_doublings, lr=0.20, c0=1.0):
    """Wright's law: cost after n doublings at learning rate lr."""
    return c0 * (1 - lr) ** cum_doublings


def fleet_mpg(year, fuel):
    """US-style fleet efficiency trend by model year (mpg-equivalent)."""
    base = dict(gasoline=(20, 0.012), diesel=(24, 0.010),
                hybrid=(42, 0.008), ev=(100, 0.010))[fuel]
    return base[0] * (1 + base[1]) ** (year - 1995)


def ev_share_of_sales(year, region_lead=0.0):
    """Bass-fitted EV share of new sales; region_lead shifts launch (NO ~ -8 yr)."""
    return float(np.clip(bass(max(year - 2011 + region_lead, 0.01)), 0, 0.95))


def meat_kg_per_cap(income_idx):
    """Engel-type saturation: income index 0..3 -> kg/cap/yr."""
    return 120 * (1 - np.exp(-1.1 * income_idx))


def datacenter_growth(year):
    """Relative datacenter power (2010=1): Koomey-flat then AI-era inflection."""
    if year <= 2022:
        return 1.0 * (1.03) ** (year - 2010)
    return 1.0 * (1.03) ** 12 * (1.20) ** (year - 2022)


def fertilizer_demand_index(grain_price_idx, gas_price_idx, lag_price_idx):
    """Cobweb-lagged N demand: plant on LAST season's grain price; today's gas
    price passes ~0.7 into ammonia cost, damping demand via SR elasticity -0.2."""
    return max(0.1, lag_price_idx ** 0.5 * (1 - 0.2 * (gas_price_idx - 1)) *
               (1 + 0.15 * (grain_price_idx - 1)))


# time series for the navigator's Trends tab (1965-2040)
def trend_series():
    years = list(range(1965, 2041))
    out = {"years": years}
    out["ev_share_sales_pct"] = [round(100 * ev_share_of_sales(y), 2) for y in years]
    out["fleet_mpg_gasoline"] = [round(fleet_mpg(min(max(y, 1995), 2026), "gasoline"), 1)
                                 for y in years]
    out["solar_cost_index"] = [round(100 * wright(max(0, (y - 1976)) / 3.5), 2)
                               for y in years]  # ~doubling every 3.5 yr
    out["battery_cost_index"] = [round(100 * wright(max(0, (y - 1991)) / 2.8, lr=0.18), 2)
                                 for y in years]
    out["meat_kg_cap_emerging"] = [round(meat_kg_per_cap(0.2 + 0.028 * (y - 1965)), 1)
                                   for y in years]
    out["datacenter_power_index"] = [round(100 * datacenter_growth(max(y, 2010)) /
                                           datacenter_growth(2010), 1) for y in years]
    out["oil_substitution_transport"] = [round(100 * (1 - 0.9 * logistic_sub(y, 2035, 6)), 1)
                                         for y in years]
    out["global_primary_share_coal"] = [round(100 * 0.55 * (1 - logistic_sub(y, 1968, 22)) +
                                              12, 1) for y in years]
    return out
