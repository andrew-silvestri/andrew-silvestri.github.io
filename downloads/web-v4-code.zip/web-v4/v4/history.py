"""
Historical event library + model-vs-history validation.

Each event: year, Kilian shock type, the shock pattern expressed on v4 nodes, and
OBSERVED anchors (price multipliers / demand deltas from the record — see
HISTORICAL_ALGORITHMS.md §5). replay() runs the event; validate() compares the
model's implied price multipliers (via the calibrated units layer k's) with what
actually happened. Anchor events used for calibration are marked calib=True —
their fit is by construction; the others are out-of-sample tests.
"""

EVENTS = {
    "opec_embargo_1973": dict(
        year=1973, kilian="supply",
        description="Arab OPEC embargo + production cuts; oil $2.90→$11.65 (~x4). "
                    "US demand fell only ~6% — the discovery of short-run inelasticity.",
        shocks={"POL_OPEC": 0.9, "BAS_GHAWAR": 0.5, "BAS_ZAKUM": 0.5, "BAS_BURGAN": 0.5,
                "CHK_HORMUZ": 0.25},
        observed={"MKT_BRENT": 4.0}, calib=False),
    "iran_revolution_1979": dict(
        year=1979, kilian="supply+precautionary",
        description="Iranian production collapse + hoarding; oil ~x2.5; triggered the "
                    "long-run demand response that broke 1970s oil intensity.",
        shocks={"BAS_IRANFIELDS": 0.9, "POL_SANCTIONS_IR": 0.7, "CHK_HORMUZ": 0.3},
        observed={"MKT_BRENT": 2.5}, calib=False),
    "oil_glut_1986": dict(
        year=1986, kilian="supply(+)",
        description="Saudi abandons swing-producer role; oil $27→$14. Relief shock.",
        shocks={"POL_OPEC": -0.7, "BAS_GHAWAR": -0.5},
        observed={"MKT_BRENT": 0.52}, calib=False),
    "gulf_war_1990": dict(
        year=1990, kilian="precautionary",
        description="Kuwait invasion; oil x2 in 2 months, fully retraced by spring.",
        shocks={"BAS_BURGAN": 0.9, "BAS_RUMAILA": 0.6, "CHK_HORMUZ": 0.2},
        observed={"MKT_BRENT": 2.0}, calib=False),
    "gfc_2008": dict(
        year=2008, kilian="aggregate demand",
        description="Financial crisis demand collapse; oil $147→$34; OECD power −4-5%.",
        shocks={"__ALL_INDUSTRIAL_SECTORS__": -0.45, "MKT_BRENT": -0.35},
        observed={"MKT_BRENT": 0.35}, calib=False),
    "fukushima_2011": dict(
        year=2011, kilian="policy",
        description="Japan nuclear fleet offline; LNG imports +25%; JKM premium era begins.",
        shocks={"__STATIONS_JP_nuclear_20__": 1.0},
        observed={"MKT_JKM": 1.6}, calib=False),
    "covid_2020": dict(
        year=2020, kilian="aggregate demand",
        description="Lockdowns: oil demand −20%, road transport −50-75%, WTI briefly "
                    "negative, electricity −15-25% in lockdown regions.",
        shocks={"__ALL_TRANSPORT_SECTORS__": -0.7, "__ALL_INDUSTRIAL_SECTORS__": -0.3,
                "MKT_BRENT": -0.5, "MKT_WTI": -0.6, "__AIR_COHORTS__": -0.9},
        observed={"MKT_BRENT": 0.31, "MKT_WTI": 0.0}, calib=False),
    "uri_2021": dict(
        year=2021, kilian="weather",
        description="Winter Storm Uri: ERCOT at cap 4 days, HH x8, Permian freeze-offs.",
        shocks={"WX_TX_FREEZE": 0.95, "WXL_ERCOT_coldsnap": 0.9},
        observed={"ERCOT": 225.0, "MKT_HH": 7.7}, calib=True),
    "russia_2022": dict(
        year=2022, kilian="supply+precautionary",
        description="Invasion + pipeline cuts: TTF ~x10, Brent $128, EU demand −15%.",
        shocks={"PIP_TURKSTREAM": 0.9, "PIP_UKRTRANSIT": 0.9, "LNGX_YAMAL": 0.8,
                "POL_SANCTIONS_RU": 0.8},
        observed={"MKT_TTF": 9.0, "MKT_BRENT": 1.83}, calib=True),
    "ai_datacenter_boom_2024": dict(
        year=2024, kilian="demand(structural)",
        description="AI compute build-out breaks the Koomey-flat datacenter power trend "
                    "(~20%/yr growth); load growth returns to US/Asia grids.",
        shocks={"AI_DEMAND_NODE": 0.8},
        observed={}, calib=False),
}


def resolve(w, G_idx, shocks):
    """Expand placeholder keys onto v4 array indices."""
    import numpy as np
    from .build4 import KIND_CODE, CHAIN
    out = {}
    for k, v in shocks.items():
        if k == "__ALL_TRANSPORT_SECTORS__":
            for nid, i in G_idx.items():
                if nid.startswith("DEM_") and nid.endswith("_transport"):
                    out[i] = v
        elif k == "__ALL_INDUSTRIAL_SECTORS__":
            for nid, i in G_idx.items():
                if nid.startswith("DEM_") and nid.endswith("_industrial"):
                    out[i] = v
        elif k == "__AIR_COHORTS__":
            ids = np.where((w.kind == KIND_CODE["transit"]) & (w.sub == 2))[0]
            for i in ids[:2000]:
                out[int(i)] = v
        elif k == "__STATIONS_JP_nuclear_20__":
            cands = [i for i in range(w.n_core)
                     if w.core_countries[i] == "JP" and w.core_fuels[i] == "nuclear"
                     and w.core_kinds[i] == "station"]
            for i in cands[:30]:
                out[i] = v
        elif k == "AI_DEMAND_NODE":
            out[w.n_core + CHAIN.index("AI_DEMAND")] = v
        else:
            out[k] = v
    return out


def validate(events_results, pm_k, pm_base):
    """Model multiplier = exp(k * stress); compare to observed."""
    import math
    rows = []
    for name, (ev, stress_at) in events_results.items():
        for mkt, obs in ev.get("observed", {}).items():
            k = pm_k.get(mkt)
            s = stress_at.get(mkt, 0.0)
            model = math.exp(k * s) if k else None
            rows.append(dict(event=name, year=ev["year"], market=mkt,
                             observed_mult=obs,
                             model_mult=round(model, 2) if model else None,
                             stress=round(s, 3),
                             calibration_anchor=ev.get("calib", False)))
    return rows
