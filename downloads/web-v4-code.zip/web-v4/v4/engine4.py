"""v4 propagation engine — scipy.sparse, million-node scale."""
import numpy as np
from scipy import sparse
from .build4 import KINDS


class Engine4:
    def __init__(self, w):
        self.w = w
        n = len(w.kind)
        src, dst, ww = w.edges
        self.W = sparse.csr_matrix((ww.astype(np.float64), (dst, src)), shape=(n, n))
        self.n = n

    def run(self, shocks: dict, rounds=60, lam=0.55, thresh=0.02):
        """shocks: {core_node_id or array_index: magnitude}."""
        b = np.zeros(self.n)
        for k, v in shocks.items():
            i = self.w.idx.get(k, k if isinstance(k, (int, np.integer)) else None)
            if i is not None:
                b[i] = v
        s = b.copy()
        first = np.full(self.n, -1, dtype=np.int16)
        first[np.abs(s) >= thresh] = 0
        gain = 1.0 - self.w.res.astype(np.float64)
        for r in range(1, rounds + 1):
            s_new = (1 - lam) * s + lam * np.tanh(b + gain * (self.W @ s))
            newly = (first < 0) & (np.abs(s_new) >= thresh)
            first[newly] = r
            if np.max(np.abs(s_new - s)) < 1e-5:
                s = s_new
                break
            s = s_new
        return np.clip(s, -1, 1), first

    def top(self, s, first, k=30, exclude=()):
        kinds = getattr(self.w, "KINDS5", KINDS)
        order = np.argsort(-np.abs(s))
        out = []
        ex = set(self.w.idx.get(e, e) for e in exclude)
        for i in order[: k * 4]:
            if i in ex or abs(s[i]) < 1e-4:
                continue
            out.append(dict(i=int(i), name=self.w.decode_name(int(i)),
                            kind=kinds[self.w.kind[i]],
                            impact=round(float(s[i]), 4), round=int(first[i])))
            if len(out) >= k:
                break
        return out

    def layer_summary(self, s, thresh=0.02):
        out = {}
        a = np.abs(s)
        for ki, kname in enumerate(getattr(self.w, "KINDS5", KINDS)):
            m = self.w.kind == ki
            if not m.any():
                continue
            out[kname] = dict(n=int(m.sum()), touched=int((a[m] >= thresh).sum()),
                              mean=round(float(a[m].mean()), 5),
                              max=round(float(a[m].max()), 4))
        return out

    def sample_nodes(self, per_kind=250, seed=5):
        """Representative node sample for the HTML navigator."""
        rng = np.random.default_rng(seed)
        out = []
        for ki, kname in enumerate(KINDS):
            ids = np.where(self.w.kind == ki)[0]
            if not len(ids):
                continue
            pick = ids if len(ids) <= per_kind else rng.choice(ids, per_kind, replace=False)
            for i in sorted(pick.tolist()):
                out.append(dict(i=int(i), kind=kname, name=self.w.decode_name(int(i))))
        return out
