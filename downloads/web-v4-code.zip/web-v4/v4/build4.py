"""
v4 mega-graph builder — array-native (no per-node Python objects; the node count
makes NetworkX infeasible in RAM). The v3 core (real plants, districts, consumers,
markets, weather, sun) is imported and flattened, then per-district cohorts are
appended as numpy blocks:

  car cohorts (32 model-years x 4 fuels x 2 classes), household income deciles,
  diet cohorts, transit cohorts, rural farms w/ nitrogen demand, datacenters,
  climate cells, and the six unconscious-mind (psych) nodes.

Plus global chain nodes: Haber-Bosch ammonia plants, fertilizer & grain markets,
climate system, AI compute demand.

Node identity is (kind, district, sub) encoded in arrays; names are synthesized
on demand (decode_name) to keep 1M+ nodes in ~hundreds of MB.
"""
import numpy as np
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from energyweb.build import build as build_core
from . import cohorts as C

KINDS = ["core", "car", "household", "diet", "transit", "farm", "datacenter",
         "climate_cell", "psych", "chain"]
KIND_CODE = {k: i for i, k in enumerate(KINDS)}
PSYCH = ["habit_inertia", "loss_aversion", "status_signal", "dissonance",
         "social_norm", "present_bias"]

CHAIN = ["AMMONIA_USGULF", "AMMONIA_MIDEAST", "AMMONIA_CHINA", "AMMONIA_EUROPE",
         "FERT_MARKET", "GRAIN_MARKET", "CLIMATE_SYS", "GLOBAL_TEMP", "AI_DEMAND"]

RURAL_SHARE = dict(NorthAmerica=0.16, SouthAmerica=0.20, Europe=0.15, Eurasia=0.25,
                   MiddleEast=0.13, Africa=0.55, Asia=0.40, Oceania=0.14)


class Web4:
    """Flattened graph: arrays + CSR propagation matrix built in engine4."""
    def __init__(self):
        self.core_ids = []          # python list of core node id strings
        self.kind = None            # int8 array
        self.district = None        # int32 (district ordinal, -1 for non-cohort)
        self.sub = None             # int32 (cohort sub-index)
        self.res = None             # float32 resilience
        self.size = None            # float32
        self.edges = None           # (src,dst,w) arrays
        self.district_names = []    # ordinal -> core district id
        self.n_core = 0

    def decode_name(self, i):
        if i < self.n_core:
            return self.core_names[i]
        k = KINDS[self.kind[i]]
        d = self.district_names[self.district[i]] if self.district[i] >= 0 else "GLOBAL"
        s = int(self.sub[i])
        if k == "car":
            cls = C.CAR_CLASSES[s % 2]; s //= 2
            fuel = C.CAR_FUELS[s % 4]; s //= 4
            year = C.CAR_YEARS[s]
            return f"{d} {year} {fuel} {cls} cohort ({C.fleet_mpg(year, fuel):.0f} mpg-e)"
        if k == "household":
            return f"{d} household income decile {s+1}"
        if k == "diet":
            return f"{d} {C.DIETS[s][0]} diet cohort"
        if k == "transit":
            return f"{d} {C.TRANSIT[s]} cohort"
        if k == "farm":
            return f"{d} farm #{s+1:03d} (N-fertilizer demand)"
        if k == "datacenter":
            return f"{d} datacenter {'AI-era' if s else 'conventional'}"
        if k == "climate_cell":
            return f"{d} climate anomaly cell"
        if k == "psych":
            return f"{d} unconscious: {PSYCH[s]}"
        if k == "chain":
            return CHAIN[s]
        return f"{k}:{d}:{s}"


def build_v4(district_cap=None, verbose=True):
    G = build_core()                       # v3 core: real plants + districts + consumers
    core_nodes = list(G.nodes)
    idx = {n: i for i, n in enumerate(core_nodes)}
    n_core = len(core_nodes)
    w = Web4()
    w.core_names = [G.nodes[n]["name"] for n in core_nodes]
    w.core_countries = [G.nodes[n].get("country", "") for n in core_nodes]
    w.core_fuels = [G.nodes[n].get("fuel", "") for n in core_nodes]
    w.core_kinds = [G.nodes[n]["kind"] for n in core_nodes]
    w.n_core = n_core

    kind = [0] * n_core
    district = [-1] * n_core
    sub = [0] * n_core
    res = [float(G.nodes[n].get("resilience", 0.35)) for n in core_nodes]
    size = [float(G.nodes[n].get("size", 1.0)) for n in core_nodes]

    E_src = [np.fromiter((idx[u] for u, v in G.edges()), dtype=np.int64)]
    E_dst = [np.fromiter((idx[v] for u, v in G.edges()), dtype=np.int64)]
    E_w = [np.fromiter((d["w"] for _, _, d in G.edges(data=True)), dtype=np.float32)]

    # ------------- global chain nodes
    chain_base = n_core
    for si, cname in enumerate(CHAIN):
        kind.append(KIND_CODE["chain"]); district.append(-1); sub.append(si)
        res.append(0.25); size.append(1.5)
    ch = {c: chain_base + i for i, c in enumerate(CHAIN)}

    def add_edges(srcs, dsts, ws):
        E_src.append(np.asarray(srcs, dtype=np.int64))
        E_dst.append(np.asarray(dsts, dtype=np.int64))
        E_w.append(np.asarray(ws, dtype=np.float32))

    # gas -> ammonia -> fertilizer -> grain; climate; AI demand
    gs = [idx.get("SUP_US_gas"), idx.get("SUP_QA_gas"), idx.get("SUP_CN_gas"),
          idx.get("SUP_DE_gas"), idx.get("MKT_TTF")]
    add_edges([gs[0], gs[1], gs[2], gs[3], gs[4],
               ch["AMMONIA_USGULF"], ch["AMMONIA_MIDEAST"], ch["AMMONIA_CHINA"],
               ch["AMMONIA_EUROPE"],
               ch["FERT_MARKET"], ch["CLIMATE_SYS"], ch["CLIMATE_SYS"], ch["AI_DEMAND"]],
              [ch["AMMONIA_USGULF"], ch["AMMONIA_MIDEAST"], ch["AMMONIA_CHINA"],
               ch["AMMONIA_EUROPE"], ch["AMMONIA_EUROPE"],
               ch["FERT_MARKET"], ch["FERT_MARKET"], ch["FERT_MARKET"],
               ch["FERT_MARKET"],
               ch["GRAIN_MARKET"], ch["GLOBAL_TEMP"], idx.get("WX_ENSO"),
               ch["AI_DEMAND"]],
              [0.65, 0.65, 0.65, 0.55, 0.45,
               0.45, 0.45, 0.45, 0.45,
               0.35, 0.5, 0.25, 0.0])

    # ------------- district cohort blocks
    dists = [(n, d) for n, d in G.nodes(data=True) if d["kind"] == "district"]
    if district_cap:
        dists = dists[:district_cap]
    w.district_names = [n for n, _ in dists]
    rng = np.random.default_rng(11)

    n_cars = len(C.CAR_YEARS) * 4 * 2
    car_fuel = np.tile(np.repeat(np.arange(4), 2), len(C.CAR_YEARS))
    car_year = np.repeat(np.arange(len(C.CAR_YEARS)), 8)
    # fuel-cost exposure by fuel: gasoline, diesel, hybrid, ev
    car_oil_w = np.array([0.50, 0.50, 0.25, 0.02], dtype=np.float32)[car_fuel]
    car_grid_w = np.array([0.0, 0.0, 0.05, 0.30], dtype=np.float32)[car_fuel]

    next_i = len(kind)
    kA, dA, sA, rA, zA = [], [], [], [], []   # appended cohort attribute blocks

    def block(kname, dord, count, subs, resil, sz):
        nonlocal next_i
        start = next_i
        kA.append(np.full(count, KIND_CODE[kname], dtype=np.int8))
        dA.append(np.full(count, dord, dtype=np.int32))
        sA.append(np.asarray(subs, dtype=np.int32))
        rA.append(np.full(count, resil, dtype=np.float32))
        zA.append(np.full(count, sz, dtype=np.float32))
        next_i += count
        return start

    for dord, (dn, dd) in enumerate(dists):
        di = idx[dn]
        cc = dd["country"]; region = dd["region"]; gw = dd["demand_gw"]
        gid = idx[dd["grid"]]
        oil = idx.get(f"SUP_{cc}_oil"); gas = idx.get(f"SUP_{cc}_gas")
        cons = [idx[m] for m in G.predecessors(dn)
                if G.nodes[m]["kind"] == "district"] or []
        # consumer nodes of this district (successors named CON_)
        con_idx = [idx[m] for m in G.successors(dn) if m.startswith("CON_")]

        # cars
        s0 = block("car", dord, n_cars, np.arange(n_cars), 0.55, max(gw / 400, 0.01))
        add_edges(np.full(n_cars, oil), np.arange(s0, s0 + n_cars), car_oil_w * 0.9)
        ev_mask = car_grid_w > 0
        add_edges(np.full(int(ev_mask.sum()), gid),
                  np.arange(s0, s0 + n_cars)[ev_mask], car_grid_w[ev_mask])
        add_edges(np.arange(s0, s0 + n_cars), np.full(n_cars, di),
                  np.full(n_cars, 0.004, dtype=np.float32))

        # households (deciles: low deciles more elastic + weather-exposed)
        s0 = block("household", dord, 10, np.arange(10), 0.5, max(gw / 100, 0.02))
        dec_w = np.linspace(0.5, 0.15, 10).astype(np.float32)
        add_edges(np.full(10, di), np.arange(s0, s0 + 10), dec_w)
        add_edges(np.full(10, gas), np.arange(s0, s0 + 10), dec_w * 0.5)

        # diets
        s0 = block("diet", dord, 4, np.arange(4), 0.55, max(gw / 300, 0.01))
        meat_w = np.array([m for _, m in C.DIETS], dtype=np.float32)
        add_edges(np.full(4, ch["GRAIN_MARKET"]), np.arange(s0, s0 + 4),
                  0.35 * meat_w)
        add_edges(np.arange(s0, s0 + 4), np.full(4, ch["GRAIN_MARKET"]),
                  0.02 * meat_w)

        # transit
        s0 = block("transit", dord, 3, np.arange(3), 0.5, max(gw / 300, 0.01))
        add_edges([gid, oil, idx.get("MKT_BRENT")],
                  [s0, s0 + 1, s0 + 2], [0.35, 0.4, 0.5])

        # farms (rural share scales count)
        nf = max(6, int(80 * RURAL_SHARE[region]))
        s0 = block("farm", dord, nf, np.arange(nf), 0.45, 0.05)
        add_edges(np.full(nf, ch["FERT_MARKET"]), np.arange(s0, s0 + nf),
                  rng.uniform(0.35, 0.6, nf).astype(np.float32))
        add_edges(np.arange(s0, s0 + nf), np.full(nf, ch["GRAIN_MARKET"]),
                  np.full(nf, 0.004, dtype=np.float32))
        cell_placeholder = None

        # climate cell (feeds farms + households)
        s0c = block("climate_cell", dord, 1, [0], 0.2, 0.3)
        add_edges([ch["CLIMATE_SYS"]], [s0c], [0.35])
        add_edges(np.full(nf, s0c), np.arange(s0, s0 + nf),
                  np.full(nf, 0.25, dtype=np.float32))

        # datacenters (tech regions get the AI-era one)
        ndc = 2 if region in ("NorthAmerica", "Asia", "Europe") else 1
        s0 = block("datacenter", dord, ndc, np.arange(ndc), 0.4, max(gw / 60, 0.05))
        add_edges(np.full(ndc, gid), np.arange(s0, s0 + ndc),
                  np.full(ndc, 0.3, dtype=np.float32))
        add_edges([ch["AI_DEMAND"]], [s0 + ndc - 1], [0.5])
        add_edges(np.arange(s0, s0 + ndc), np.full(ndc, gid),
                  np.full(ndc, 0.05, dtype=np.float32))

        # unconscious mind (psych substrate)
        s0 = block("psych", dord, 6, np.arange(6), 0.75, 0.2)
        HAB, LOSS, STAT, DISS, NORM, PRES = range(s0, s0 + 6)
        add_edges([oil, oil, gid], [LOSS, DISS, LOSS], [0.4, 0.3, 0.2])
        # psych modulates the district's consumers and cohorts
        if con_idx:
            m = len(con_idx)
            add_edges(np.full(m, HAB), con_idx, np.full(m, 0.10, dtype=np.float32))
            add_edges(np.full(m, LOSS), con_idx, np.full(m, 0.18, dtype=np.float32))
            add_edges(np.full(m, NORM), con_idx, np.full(m, 0.08, dtype=np.float32))
        # dissonance discharges into behavior change: oil demand relief + EV pull
        add_edges([DISS, DISS], [oil, gid], [-0.05, -0.02])
        add_edges([NORM], [DISS], [0.15])
        add_edges([PRES], [HAB], [0.2])

    w.kind = np.concatenate([np.asarray(kind, dtype=np.int8)] + kA)
    w.district = np.concatenate([np.asarray(district, dtype=np.int32)] + dA)
    w.sub = np.concatenate([np.asarray(sub, dtype=np.int32)] + sA)
    w.res = np.concatenate([np.asarray(res, dtype=np.float32)] + rA)
    w.size = np.concatenate([np.asarray(size, dtype=np.float32)] + zA)
    src = np.concatenate(E_src); dst = np.concatenate(E_dst)
    ww = np.concatenate(E_w)
    ok = (src >= 0) & (dst >= 0)
    src, dst, ww = src[ok], dst[ok], ww[ok]
    # ---- aggregate-inflow normalization: millions of cohort nodes must not
    # saturate shared targets (grids, supplies, grain market). For edges whose
    # SOURCE is a cohort/chain node, cap the summed |w| into any single target.
    cohort_src = src >= n_core + len(CHAIN)   # cap mass-cohort sources only
    cap = 0.6
    infl = np.zeros(len(kind) + sum(len(a) for a in kA))
    np.add.at(infl, dst[cohort_src], np.abs(ww[cohort_src]))
    factor = np.ones_like(infl)
    over = infl > cap
    factor[over] = cap / infl[over]
    ww = ww.astype(np.float32).copy()
    ww[cohort_src] *= factor[dst[cohort_src]].astype(np.float32)
    w.edges = (src, dst, ww)
    w.idx = idx
    w.core_id_list = core_nodes
    if verbose:
        print(f"v4 web: {len(w.kind):,} nodes, {len(ww):,} edges "
              f"({n_core:,} core + {len(w.kind)-n_core:,} cohort/chain)")
    return w
