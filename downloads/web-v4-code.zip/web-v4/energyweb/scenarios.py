"""Scenario library — top-down, bottom-up, and middle-out shocks."""

SCENARIOS = {
    # ------------------------------------------------ top-down (geopolitical / macro)
    "hormuz_closure": dict(
        category="top-down",
        description="Full closure of the Strait of Hormuz: ~30% of seaborne oil, "
                    "~20% of LNG halted; Gulf exporters bottled up.",
        shocks={"CHK_HORMUZ": 1.0, "POL_SANCTIONS_IR": 0.4}),
    "russia_full_cutoff": dict(
        category="top-down",
        description="Total halt of remaining Russian pipeline gas + Yamal LNG to Europe.",
        shocks={"PIP_TURKSTREAM": 0.9, "PIP_UKRTRANSIT": 0.9, "LNGX_YAMAL": 0.8,
                "POL_SANCTIONS_RU": 0.8}),
    "opec_deep_cut": dict(
        category="top-down",
        description="OPEC+ announces deep coordinated supply cut.",
        shocks={"POL_OPEC": 0.8, "BAS_GHAWAR": 0.25, "BAS_ZAKUM": 0.25, "BAS_BURGAN": 0.25}),
    "malacca_disruption": dict(
        category="top-down",
        description="Conflict/piracy disrupts Strait of Malacca transits for Asia.",
        shocks={"CHK_MALACCA": 0.8}),
    "red_sea_crisis": dict(
        category="top-down",
        description="Bab el-Mandeb + Suez avoidance; rerouting via Cape of Good Hope.",
        shocks={"CHK_BABELMANDEB": 0.85, "CHK_SUEZ": 0.6}),

    # ------------------------------------------------ weather (top-down regional)
    "gulf_major_hurricane": dict(
        category="top-down",
        description="Cat-4 landfall on the US Gulf Coast: GoM shut-ins, LNG terminals down, "
                    "refinery/products corridor hit.",
        shocks={"WX_GULF_HURR": 0.95}),
    "texas_uri_repeat": dict(
        category="top-down",
        description="Uri-type deep freeze: ERCOT + Permian wellhead freeze-offs simultaneously.",
        shocks={"WX_TX_FREEZE": 0.95, "WXL_ERCOT_coldsnap": 0.9}),
    "european_wind_drought": dict(
        category="top-down",
        description="Multi-week blocking high: NW Europe wind output collapses in winter.",
        shocks={"WX_EU_BLOCK": 0.9, "WX_EU_COLD": 0.5}),
    "enso_swing": dict(
        category="top-down",
        description="Strong El Niño: hydro stress in Brazil/Colombia/SE Asia, heat in Australia.",
        shocks={"WX_ENSO": 0.8}),

    # ------------------------------------------------ bottom-up (single assets)
    "ercot_largest_trip": dict(
        category="bottom-up",
        description="Largest single ERCOT station trips offline (unit contingency).",
        shocks={"__LARGEST_STATION_ERCOT__": 0.9}),
    "south_texas_nuclear_outage": dict(
        category="bottom-up",
        description="Extended forced outage at a large TX nuclear unit.",
        shocks={"__LARGEST_STATION_ERCOT_nuclear__": 1.0}),
    "german_gas_fleet_derate": dict(
        category="bottom-up",
        description="A tranche of German gas units derated on fuel constraints.",
        shocks={"__STATIONS_DE_gas_5__": 0.6}),
    "freeport_explosion": dict(
        category="bottom-up",
        description="Freeport LNG offline for months (2022-style incident).",
        shocks={"LNGX_FREEPORT": 1.0}),
    "colonial_cyberattack": dict(
        category="bottom-up",
        description="Ransomware halts the products pipeline serving the US East Coast.",
        shocks={"PIP_COLONIAL": 0.9}),

    # ------------------------------------------------ middle-out (markets / midstream)
    "ttf_squeeze": dict(
        category="middle-out",
        description="A European gas price squeeze emerges from storage fears (market-native shock).",
        shocks={"MKT_TTF": 0.8}),
    "jkm_bidding_war": dict(
        category="middle-out",
        description="Asian LNG bidding war pulls cargoes; freight rates spike.",
        shocks={"MKT_JKM": 0.8, "MKT_FREIGHT_LNG": 0.6}),
    "coal_export_ban": dict(
        category="middle-out",
        description="Major exporter bans coal exports (Indonesia-2022-style).",
        shocks={"BAS_KALIMANTAN": 0.7, "POL_CN_EXPORT": 0.5}),
    "carbon_price_doubling": dict(
        category="middle-out",
        description="EUA carbon price doubles on policy tightening.",
        shocks={"MKT_EUA": 0.9}),
    "uranium_squeeze": dict(
        category="middle-out",
        description="Uranium supply/conversion bottleneck stresses nuclear fuel chain.",
        shocks={"MKT_URANIUM": 0.7}),

    # ------------------------------------------------ relief / counterfactual
    "spr_release": dict(
        category="relief",
        description="Coordinated SPR + IEA stock release during an oil shock (run vs hormuz_closure).",
        shocks={"CHK_HORMUZ": 1.0, "POL_SPR": 0.9, "POL_IEA": 0.7}),
}


def resolve_shocks(G, shocks):
    """Expand placeholder shock keys (__LARGEST_STATION_<grid>[_fuel]__, __STATIONS_<cc>_<fuel>_<n>__)."""
    out = {}
    for key, mag in shocks.items():
        if key.startswith("__LARGEST_STATION_"):
            body = key.strip("_").replace("LARGEST_STATION_", "")
            parts = body.split("_")
            grid = parts[0]
            fuel = parts[1] if len(parts) > 1 else None
            cands = [(d.get("cap_gw", 0), n) for n, d in G.nodes(data=True)
                     if d.get("kind") == "station" and d.get("grid") == grid
                     and (fuel is None or d.get("fuel") == fuel)]
            if cands:
                out[max(cands)[1]] = mag
        elif key.startswith("__CONSUMERS_"):
            _resolve_consumers(G, key, mag, out)
        elif key.startswith("__STATIONS_"):
            _, cc, fuel, n = key.strip("_").split("_")
            cands = sorted([(d.get("cap_gw", 0), m) for m, d in G.nodes(data=True)
                            if d.get("kind") == "station" and d.get("country") == cc
                            and d.get("fuel") == fuel], reverse=True)[: int(n)]
            for _, m in cands:
                out[m] = mag
        else:
            out[key] = mag
    return out


# ------------------------------------------------ v2 scenarios (granular layers)
SCENARIOS.update({
    "sun_quiet_cycle": dict(
        category="top-down",
        description="Prolonged irradiance anomaly / dim solar cycle stresses all solar belts.",
        shocks={"SUN": 0.5}),
    "cloudy_year_europe": dict(
        category="top-down",
        description="Anomalously cloudy year over both European insolation belts.",
        shocks={"INS_EU_SOUTH": 0.7, "INS_EU_NORTH": 0.7}),
    "district_storm_cluster": dict(
        category="bottom-up",
        description="Severe storms hit five ERCOT districts' cloud/storm cells at once.",
        shocks={f"CLD_DIS_ERCOT_{i:03d}": 0.9 for i in range(5)}),
    "consumer_frugality_shift": dict(
        category="middle-out",
        description="A demand-side mentality shift: US industrial+household conservation wave "
                    "(relief entering from the consumer layer).",
        shocks={"__CONSUMERS_US_20__": -0.5}),
    "ev_adoption_surge": dict(
        category="middle-out",
        description="Rapid EV adoption: gasoline demand relief, grid load stress (China+US).",
        shocks={"SUP_US_oil": -0.3, "SUP_CN_oil": -0.3, "ERCOT": 0.2, "CN_E": 0.25, "CAISO": 0.25}),
})


def _resolve_consumers(G, key, mag, out):
    _, cc, n = key.strip("_").split("_")[1:] if False else (None, key.strip("_").split("_")[1], key.strip("_").split("_")[2])
    cands = sorted([(d.get("demand_gw", 0), m) for m, d in G.nodes(data=True)
                    if d.get("kind") == "consumer" and d.get("country") == cc],
                   reverse=True)[: int(n)]
    for _, m in cands:
        out[m] = mag
