"""
Graph builder: assembles the world energy web from world_data tables plus
procedurally generated station fleets, local weather cells, and demand sectors.

Layers (node attribute `layer`):
  0 policy/geopolitics   1 chokepoints        2 upstream basins
  3 midstream (pipelines, LNG, shipping)      4 markets/prices
  5 national fuel supply 6 generation stations 7 grids/transmission
  8 demand sectors       9 weather systems

Edge attribute `w` = signed sensitivity (stress transmitted per unit stress),
`kind` = relationship type. Stress semantics: s ∈ [0,1] disruption/tightness.
"""
import math
import random
import networkx as nx
from . import world_data as W

LAYER = {
    "policy": 0, "chokepoint": 1, "basin": 2, "midstream": 3, "market": 4,
    "supply": 5, "station": 6, "grid": 7, "sector": 8, "weather": 9,
    "district": 10, "consumer": 11, "sun": 12,
}
LAYER_NAMES = {v: k for k, v in LAYER.items()}


def _add(G, nid, name, kind, country="", region="", size=1.0, resilience=0.35, **extra):
    G.add_node(nid, name=name, kind=kind, layer=LAYER[kind], country=country,
               region=region, size=size, resilience=resilience, **extra)


def _edge(G, u, v, w, kind):
    if u == v or abs(w) < 1e-4 or not (G.has_node(u) and G.has_node(v)):
        return
    if G.has_edge(u, v):
        G[u][v]["w"] = max(G[u][v]["w"], w)
    else:
        G.add_edge(u, v, w=round(w, 4), kind=kind)


def grid_ids_for(country_code):
    if country_code in W.MULTI_GRIDS:
        return [(g, s) for g, _, s in W.MULTI_GRIDS[country_code]]
    return [(f"{country_code}_GRID", 1.0)]


def build(seed=7, station_density=1.0, district_density=1.2, granular=True,
          use_real_plants=True):
    """Returns the full DiGraph.
    station_density scales procedural fleet sizes; district_density scales
    sub-national districts per grid; granular=False reproduces the v1 web;
    use_real_plants=True swaps procedural fleets for the WRI Global Power Plant
    Database (34,936 real plants with lat/lon) when data/ contains it."""
    from . import society_data as S
    from . import real_data as RD
    rng = random.Random(seed)
    G = nx.DiGraph()
    countries = {c[0]: c for c in W.COUNTRIES}
    real_plants = RD.load_real_plants() if use_real_plants else []

    # ---------------- markets
    for mid, name, fuel, region in W.MARKETS:
        _add(G, mid, name, "market", region=region, size=1.0, resilience=0.25, fuel=fuel)
    for a, b, w in W.MARKET_SUBSTITUTION:
        _edge(G, a, b, w * 0.5, "substitution")

    # ---------------- chokepoints + shipping routes
    for cid, name, shares, regions in W.CHOKEPOINTS:
        _add(G, cid, name, "chokepoint", region="global",
             size=sum(shares.values()), resilience=0.15, shares=dict(shares))
        for fuel, share in shares.items():
            mkt = {"oil": "MKT_BRENT", "lng": "MKT_JKM", "coal": "MKT_NEWC"}.get(fuel)
            if mkt:
                _edge(G, cid, mkt, 1.6 * share, "flow_risk")
        _edge(G, cid, "MKT_FREIGHT_TANKER", 0.8 * shares.get("oil", 0), "flow_risk")
        _edge(G, cid, "MKT_FREIGHT_LNG", 0.9 * shares.get("lng", 0), "flow_risk")
    _edge(G, "CHK_BABELMANDEB", "CHK_CAPE", 0.5, "reroute")
    _edge(G, "CHK_SUEZ", "CHK_CAPE", 0.5, "reroute")
    _edge(G, "CHK_HORMUZ", "CHK_MALACCA", 0.15, "reroute")

    # ---------------- basins
    for bid, name, cc, shares, hurr in W.BASINS:
        region = countries[cc][2]
        _add(G, bid, name, "basin", country=cc, region=region,
             size=sum(shares.values()) * 4, resilience=0.3, shares=dict(shares))
        for fuel, share in shares.items():
            mkt = {"oil": "MKT_BRENT" if region != "NorthAmerica" else "MKT_WTI",
                   "gas": "MKT_TTF" if region == "Europe" else
                          ("MKT_HH" if region == "NorthAmerica" else "MKT_JKM"),
                   "lng": "MKT_JKM", "coal": "MKT_NEWC" if region != "Europe" else "MKT_API2",
                   }.get(fuel)
            if mkt:
                _edge(G, bid, mkt, 6.0 * share, "supply_loss")
        # basin feeds its own country's fuel supply
        _edge(G, bid, f"SUP_{cc}_{max(shares, key=shares.get)}",
              0.9 * (1 - countries[cc][5].get(max(shares, key=shares.get), 0)), "domestic_supply")

    # exports flow through chokepoints (region heuristics)
    for bid, name, cc, shares, hurr in W.BASINS:
        region = countries[cc][2]
        if region == "MiddleEast":
            _edge(G, "CHK_HORMUZ", bid, 0.0, "route")     # placeholder direction below
            _edge(G, bid, "CHK_HORMUZ", 0.3 * sum(shares.values()), "export_route")
        if cc in ("RU",) and "oil" in shares:
            _edge(G, bid, "CHK_BOSPORUS", 0.2 * shares.get("oil", 0) * 4, "export_route")
            _edge(G, bid, "CHK_DANISH", 0.2 * shares.get("oil", 0) * 4, "export_route")

    # ---------------- pipelines
    for pid, name, src, dst, fuel, scale in W.PIPELINES:
        dst_supply = f"SUP_{dst}_{fuel}" if dst in countries else f"SUP_US_{fuel}"
        _add(G, pid, name, "midstream", country=dst if dst in countries else "US",
             size=scale, resilience=0.2, fuel=fuel)
        _edge(G, src, pid, 0.8 * scale, "feeds")
        G.nodes[pid]["dst_supply"] = dst_supply

    # ---------------- LNG terminals
    for tid, name, cc, scale in W.LNG_EXPORT:
        _add(G, tid, name, "midstream", country=cc, region=countries[cc][2],
             size=scale * 3, resilience=0.25, fuel="lng")
        _edge(G, tid, "MKT_JKM", 2.5 * scale, "supply_loss")
        _edge(G, tid, "MKT_TTF", 1.8 * scale, "supply_loss")
        _edge(G, f"SUP_{cc}_gas", tid, 0.5, "feeds")      # created later; edge added after
    for tid, name, cc, scale in W.LNG_IMPORT:
        _add(G, tid, name, "midstream", country=cc, region=countries[cc][2],
             size=scale * 3, resilience=0.3, fuel="lng")
        _edge(G, "MKT_JKM", tid, 0.5, "price_pass")
        _edge(G, "MKT_FREIGHT_LNG", tid, 0.3, "price_pass")
        _edge(G, tid, f"SUP_{cc}_gas", 0.7 * min(1.0, scale * 10), "import_supply")

    # chokepoints gate LNG/oil routes into importing regions
    for cid, name, shares, regions in W.CHOKEPOINTS:
        for tid, tname, cc, scale in W.LNG_IMPORT:
            if countries[cc][2] in regions and "lng" in shares:
                _edge(G, cid, tid, 1.2 * shares["lng"] * min(1.0, scale * 8), "route_risk")

    # ---------------- countries: supply, grids, sectors, stations, local weather
    total_stations = 0
    for cc, cname, region, demand, mix, imp in W.COUNTRIES:
        # national fuel supply nodes
        for fuel in ("oil", "gas", "coal"):
            sid = f"SUP_{cc}_{fuel}"
            _add(G, sid, f"{cname} {fuel} supply", "supply", country=cc, region=region,
                 size=demand / 100, resilience=0.35, fuel=fuel)
            # import exposure: world market stress passes through in proportion to import dependence
            mkt = {"oil": "MKT_BRENT" if region != "NorthAmerica" else "MKT_WTI",
                   "gas": {"Europe": "MKT_TTF", "NorthAmerica": "MKT_HH"}.get(region, "MKT_JKM"),
                   "coal": "MKT_API2" if region == "Europe" else "MKT_NEWC"}[fuel]
            _edge(G, mkt, sid, 0.35 + 0.5 * imp.get(fuel, 0.5), "price_pass")
        for fuel in ("nuclear",):
            sid = f"SUP_{cc}_nuclear"
            _add(G, sid, f"{cname} nuclear fuel supply", "supply", country=cc, region=region,
                 size=demand / 200, resilience=0.5, fuel="nuclear")
            _edge(G, "MKT_URANIUM", sid, 0.3, "price_pass")

        # grids
        gids = grid_ids_for(cc)
        for gid, share in gids:
            gname = dict((g, n) for g, n, _ in W.MULTI_GRIDS.get(cc, [])).get(gid, f"{cname} grid")
            _add(G, gid, gname, "grid", country=cc, region=region,
                 size=demand * share / 50, resilience=0.3, demand_gw=demand * share)
            # demand sectors
            for sec in W.DEMAND_SECTORS:
                nid = f"DEM_{gid}_{sec}"
                wshare = dict(residential=0.28, commercial=0.22, industrial=0.34,
                              transport=0.10, agriculture=0.06)[sec]
                _add(G, nid, f"{gname} {sec} demand", "sector", country=cc, region=region,
                     size=demand * share * wshare / 60, resilience=0.4)
                _edge(G, gid, nid, 0.8 * wshare + 0.2, "serves")
                _edge(G, f"SUP_{cc}_oil", nid, 0.35 if sec == "transport" else 0.05, "fuel_cost")
                _edge(G, f"SUP_{cc}_gas", nid, 0.25 if sec in ("residential", "industrial") else 0.05, "fuel_cost")
            # local weather cells (propensity for storms etc.)
            for wtag, prop in (("storm", 0.5), ("heatwave", 0.45), ("cold snap", 0.35)):
                wid = f"WXL_{gid}_{wtag.replace(' ', '')}"
                _add(G, wid, f"{gname} local {wtag} cell", "weather", country=cc, region=region,
                     size=0.4, resilience=0.1, propensity=prop)
                _edge(G, wid, gid, 0.25 * prop, "weather_hit")
                _edge(G, wid, f"DEM_{gid}_residential", 0.3 * prop, "demand_spike")

        # generation stations (procedural fleet — used only without the real DB)
        for fuel, frac in (mix.items() if not real_plants else []):
            if frac <= 0.005:
                continue
            fleet_gw = demand * frac * 1.15                     # capacity margin
            n_st = max(1, min(90, int(station_density * fleet_gw / W.STATION_GW[fuel] / 3)))
            for k in range(n_st):
                cap = W.STATION_GW[fuel] * rng.lognormvariate(0, 0.5) * 3
                gid, gshare = gids[k % len(gids)] if len(gids) > 1 else gids[0]
                sid = f"ST_{cc}_{fuel.upper()}_{k:03d}"
                _add(G, sid, f"{dict((g, n) for g, n, _ in W.MULTI_GRIDS.get(cc, [])).get(gid, cname)} "
                             f"{fuel} station #{k+1:02d} ({cap:.2f} GW)",
                     "station", country=cc, region=region, size=cap,
                     resilience=0.45, fuel=fuel, grid=gid, cap_gw=round(cap, 2))
                gd = G.nodes[gid]["demand_gw"]
                _edge(G, sid, gid, min(0.8, 1.3 * cap / max(gd, 1)), "generates")
                _edge(G, gid, sid, 0.12, "dispatch_strain")   # scarcity stresses the rest of the fleet
                if fuel in ("coal", "gas", "oil", "nuclear"):
                    _edge(G, f"SUP_{cc}_{fuel}", sid, 0.55, "fuel_feed")
                # local weather vulnerability
                wid = f"WXL_{gid}_storm"
                _edge(G, wid, sid, 0.3 * W.WX_VULN[fuel], "weather_hit")
                total_stations += 1

    # ---------------- real plants (WRI Global Power Plant Database)
    for p in real_plants:
        cc = p["cc"]
        if cc not in countries:
            continue
        gid = p["grid"]
        if gid not in G:
            continue
        sid = f"ST_{p['idnr']}"
        gd = G.nodes[gid]["demand_gw"]
        _add(G, sid, f"{p['name']} [{p['fuel']}, {p['cap_gw']:.2f} GW]",
             "station", country=cc, region=countries[cc][2], size=max(p["cap_gw"], 0.05),
             resilience=0.45, fuel=p["fuel"], grid=gid, cap_gw=p["cap_gw"],
             lat=p["lat"], lon=p["lon"], real=True,
             **({"solar_cf": p["solar_cf"]} if p["solar_cf"] else {}))
        _edge(G, sid, gid, min(0.8, 1.3 * p["cap_gw"] / max(gd, 1)), "generates")
        _edge(G, gid, sid, 0.12, "dispatch_strain")
        if p["fuel"] in ("coal", "gas", "oil", "nuclear"):
            _edge(G, f"SUP_{cc}_{p['fuel']}", sid, 0.55, "fuel_feed")
        _edge(G, f"WXL_{gid}_storm", sid, 0.3 * W.WX_VULN[p["fuel"]], "weather_hit")
        if p["hurricane"]:
            wx = "WX_GULF_HURR" if p["lon"] < -60 else "WX_TYPHOON"
            _edge(G, wx, sid, 0.35 * W.WX_VULN[p["fuel"]], "weather_hit")
        total_stations += 1

    # pipelines discharge into supply nodes (now that they exist)
    for pid, name, src, dst, fuel, scale in W.PIPELINES:
        _edge(G, pid, G.nodes[pid]["dst_supply"], 0.7 * scale, "import_supply")

    # LNG export terminals draw on national gas supply (edges deferred earlier are fine now)
    for tid, name, cc, scale in W.LNG_EXPORT:
        _edge(G, f"SUP_{cc}_gas", tid, 0.4, "feeds")

    # ---------------- interties
    for a, b, s in W.INTERTIES:
        _edge(G, a, b, 0.3 * s, "intertie")
        _edge(G, b, a, 0.3 * s, "intertie")

    # ---------------- macro weather
    # note: propensity = likelihood (kept as node attr for scenario design);
    # edge weights carry INTENSITY of a realized event, so they are not discounted by it.
    stations_by_grid = {}
    for n, d in G.nodes(data=True):
        if d["kind"] == "station":
            stations_by_grid.setdefault(d["grid"], []).append((n, d["fuel"]))
    for wid, name, region, targets, prop in W.WEATHER_MACRO:
        _add(G, wid, name, "weather", region=region, size=1.2, resilience=0.1, propensity=prop)
        for tgt in targets:
            if G.has_node(tgt):
                k = G.nodes[tgt]["kind"]
                w = dict(basin=0.7, midstream=0.7, grid=0.6).get(k, 0.5)
                _edge(G, wid, tgt, w, "weather_hit")
                if k == "grid":  # realized event hits the fleet, weighted by fuel vulnerability
                    for sid, fuel in stations_by_grid.get(tgt, []):
                        _edge(G, wid, sid, 0.4 * W.WX_VULN[fuel], "weather_hit")
                    for sec in W.DEMAND_SECTORS[:2]:
                        _edge(G, wid, f"DEM_{tgt}_{sec}", 0.35, "demand_spike")

    # ---------------- policy
    for pid, name, targets in W.POLICY:
        _add(G, pid, name, "policy", region="global", size=1.0, resilience=0.1)
        for tgt in targets:
            sign = -0.5 if pid in ("POL_SPR", "POL_IEA", "POL_EU_STORAGE", "POL_45Q_IRA") else 0.5
            _edge(G, pid, tgt, sign, "policy")

    # ---------------- v2 granular layers: districts, consumers, sun chain
    if granular:
        # sun + insolation belts
        _add(G, S.SUN_NODE[0], S.SUN_NODE[1], "sun", region="solar-system",
             size=2.0, resilience=0.0)
        for iid, iname, regions, quality in S.INSOLATION_BELTS:
            _add(G, iid, iname, "sun", region=regions[0], size=1.0,
                 resilience=0.05, quality=quality)
            _edge(G, S.SUN_NODE[0], iid, 0.5, "irradiance")
        belt_for_region = {}
        for iid, iname, regions, quality in S.INSOLATION_BELTS:
            for r in regions:
                belt_for_region.setdefault(r, iid)
        # utility solar stations hang off their regional belt
        for n, d in list(G.nodes(data=True)):
            if d.get("kind") == "station" and d.get("fuel") == "solar":
                belt = belt_for_region.get(d["region"])
                if belt:
                    q = G.nodes[belt]["quality"]
                    _edge(G, belt, n, 0.5 * q, "irradiance")

        for cc, cname, region, demand, mix, imp in W.COUNTRIES:
            soc = S.COUNTRY_SOCIETY.get(cc, S.REGION_SOCIETY[region])
            car, green, ev, income = soc
            belt = belt_for_region.get(region)
            for gid, gshare in grid_ids_for(cc):
                gname = G.nodes[gid]["name"]
                gd = G.nodes[gid]["demand_gw"]
                n_dis = max(S.DISTRICT_MIN, min(S.DISTRICT_MAX,
                                                int(gd * district_density)))
                shares = [rng.lognormvariate(0, 0.6) for _ in range(n_dis)]
                tot = sum(shares)
                for i in range(n_dis):
                    frac = shares[i] / tot
                    did = f"DIS_{gid}_{i:03d}"
                    d_gw = gd * frac
                    _add(G, did, f"{gname} district {i+1:03d} ({d_gw:.2f} GW)",
                         "district", country=cc, region=region, size=max(d_gw / 3, 0.15),
                         resilience=0.35, demand_gw=round(d_gw, 3), grid=gid)
                    _edge(G, gid, did, 0.45 + 0.4 * min(frac * n_dis, 1.5) / 1.5, "distributes")
                    _edge(G, did, gid, min(0.3, 0.6 * frac), "load_agg")
                    # local cloud cover cell
                    cld = f"CLD_{did}"
                    prop = rng.uniform(0.3, 0.8)
                    _add(G, cld, f"{gname} d{i+1:03d} cloud-cover cell", "weather",
                         country=cc, region=region, size=0.25, resilience=0.05,
                         propensity=round(prop, 2))
                    _edge(G, cld, did, 0.10 * prop, "weather_hit")
                    # distributed rooftop solar in the district
                    dpv = f"ST_{did}_PV"
                    pv_gw = d_gw * mix.get("solar", 0) * rng.uniform(0.3, 0.9)
                    if pv_gw > 0.005:
                        _add(G, dpv, f"{gname} d{i+1:03d} distributed PV ({pv_gw:.2f} GW)",
                             "station", country=cc, region=region, size=max(pv_gw, 0.1),
                             resilience=0.4, fuel="solar", grid=gid, cap_gw=round(pv_gw, 3),
                             distributed=True)
                        _edge(G, dpv, did, min(0.5, pv_gw / max(d_gw, 0.05)), "generates")
                        _edge(G, cld, dpv, 0.55, "cloud_block")
                        if belt:
                            _edge(G, belt, dpv, 0.35 * G.nodes[belt]["quality"], "irradiance")
                    # consumer groups
                    for (tag, elas, wxs), pshare in zip(
                            S.CONSUMER_ARCHETYPES, list(income) + [0.30]):
                        cid = f"CON_{did}_{tag}"
                        ment = ("green" if rng.random() < green else
                                ("consumerist" if rng.random() < car * 0.5 else "neutral"))
                        rebound = S.MENTALITY_REBOUND[ment]
                        c_gw = d_gw * pshare * (0.75 if tag != "industry" else 1.0)
                        _add(G, cid, f"{gname} d{i+1:03d} {tag} ({ment})", "consumer",
                             country=cc, region=region, size=max(c_gw / 2, 0.08),
                             resilience=0.45, elasticity=elas, mentality=ment,
                             rebound=rebound, car_culture=car, ev_share=ev,
                             demand_gw=round(c_gw, 3), archetype=tag)
                        _edge(G, did, cid, 0.5 * pshare + 0.15, "serves")
                        if tag != "industry":
                            _edge(G, f"SUP_{cc}_oil", cid,
                                  0.4 * car * (1 - ev), "fuel_cost")
                            _edge(G, f"SUP_{cc}_gas", cid, 0.2, "fuel_cost")
                            _edge(G, cld, cid, 0.15 * wxs, "weather_hit")
                        else:
                            _edge(G, f"SUP_{cc}_gas", cid, 0.35, "fuel_cost")
                        # demand response / rebound: price RELIEF (negative stress)
                        # arriving here converts into ADDED load upstream (Jevons machinery)
                        _edge(G, cid, gid, -0.06 * elas * rebound, "demand_response")
                        if car > 0.3 and tag != "industry":
                            _edge(G, cid, f"SUP_{cc}_oil",
                                  -0.05 * elas * rebound * car * (1 - ev), "demand_response")

    # markets feed back into grids (dispatch cost stress)
    for cc, cname, region, demand, mix, imp in W.COUNTRIES:
        for gid, share in grid_ids_for(cc):
            _edge(G, f"SUP_{cc}_gas", gid, 0.45 * mix.get("gas", 0), "dispatch_cost")
            _edge(G, f"SUP_{cc}_coal", gid, 0.4 * mix.get("coal", 0), "dispatch_cost")
            _edge(G, f"SUP_{cc}_oil", gid, 0.4 * mix.get("oil", 0), "dispatch_cost")
            if region == "Europe":  # carbon cost bites fossil-heavy EU dispatch
                _edge(G, "MKT_EUA", gid, 0.5 * (mix.get("coal", 0) + 0.5 * mix.get("gas", 0)),
                      "carbon_cost")
                _edge(G, "MKT_EUA", f"SUP_{cc}_coal", 0.3, "carbon_cost")

    # demand destruction feedback: heavily stressed industrial demand relieves markets a bit
    for cc, cname, region, demand, mix, imp in W.COUNTRIES:
        for gid, share in grid_ids_for(cc):
            _edge(G, f"DEM_{gid}_industrial", "MKT_TTF" if region == "Europe" else "MKT_JKM",
                  -0.05, "demand_destruction")

    G.graph["n_stations"] = total_stations
    G.graph["countries"] = W.COUNTRIES
    return G


if __name__ == "__main__":
    g = build()
    print(f"nodes={g.number_of_nodes()} edges={g.number_of_edges()} stations={g.graph['n_stations']}")
