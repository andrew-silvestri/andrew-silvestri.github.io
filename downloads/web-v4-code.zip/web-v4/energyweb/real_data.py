"""
Rung 2+3: real asset data + real-weather grounding.

Loads the WRI Global Power Plant Database (data/global_power_plant_database.csv,
fetched from github.com/wri/global-power-plant-database — 34,936 real plants with
name, capacity, fuel, lat/lon) and grounds weather exposure in geography:
  - solar capacity factor from a latitude climatology (NASA-POWER-style GHI bands)
  - hurricane/typhoon-belt membership from lat/lon boxes
  - grid assignment for multi-grid countries from lat/lon boxes

Drop-in upgrades: ERA5/NASA POWER API loaders are stubbed at the bottom for when
you run outside this sandbox (both endpoints are blocked here).
"""
import csv, os

ISO3_TO_ISO2 = {
    "USA": "US", "CAN": "CA", "MEX": "MX", "BRA": "BR", "ARG": "AR", "CHL": "CL",
    "COL": "CO", "GBR": "GB", "DEU": "DE", "FRA": "FR", "ESP": "ES", "ITA": "IT",
    "POL": "PL", "NLD": "NL", "NOR": "NO", "SWE": "SE", "UKR": "UA", "TUR": "TR",
    "RUS": "RU", "KAZ": "KZ", "SAU": "SA", "ARE": "AE", "IRN": "IR", "IRQ": "IQ",
    "QAT": "QA", "KWT": "KW", "ISR": "IL", "EGY": "EG", "DZA": "DZ", "NGA": "NG",
    "ZAF": "ZA", "LBY": "LY", "CHN": "CN", "IND": "IN", "JPN": "JP", "KOR": "KR",
    "TWN": "TW", "IDN": "ID", "MYS": "MY", "VNM": "VN", "THA": "TH", "PAK": "PK",
    "BGD": "BD", "AUS": "AU", "NZL": "NZ",
}

FUEL_MAP = {
    "Gas": "gas", "Coal": "coal", "Oil": "oil", "Petcoke": "oil", "Hydro": "hydro",
    "Solar": "solar", "Wind": "wind", "Nuclear": "nuclear", "Biomass": "bio",
    "Waste": "bio", "Geothermal": "geo", "Cogeneration": "gas",
}


def solar_cf_from_lat(lat):
    """Latitude-band GHI climatology (kWh/m2/day, NASA POWER magnitudes) -> AC CF."""
    a = abs(lat)
    ghi = (5.8 if a < 15 else 6.1 if a < 25 else 5.4 if a < 35 else
           4.4 if a < 45 else 3.4 if a < 55 else 2.6)
    return round(ghi / 24 * 0.78, 3)          # performance ratio 0.78


def hurricane_exposed(lat, lon):
    """Atlantic/GoM + West Pacific + Bay of Bengal cyclone belts."""
    if 8 <= lat <= 36 and -100 <= lon <= -60:
        return True                            # Atlantic / Gulf of Mexico
    if 5 <= lat <= 38 and 105 <= lon <= 150:
        return True                            # West Pacific typhoons
    if 8 <= lat <= 24 and 78 <= lon <= 95:
        return True                            # Bay of Bengal
    return False


def assign_grid(cc, lat, lon):
    """Approximate multi-grid assignment from geography."""
    if cc == "US":
        if -107 <= lon <= -93.5 and 25.8 <= lat <= 36.5:
            if lon >= -104 and lat <= 34:
                return "ERCOT" if (lon >= -103.1 and lat <= 33.6) or lon >= -100 else "SPP"
        if lon <= -114:
            return "CAISO" if (lat <= 42 and lon <= -117) else "WECCNW"
        if lon <= -104:
            return "WECCNW"
        if lat >= 40.5 and lon >= -80:
            return "NYISO" if -80 < lon <= -73.5 and lat <= 45 else ("ISONE" if lon > -73.5 else "PJM")
        if lat >= 38 and -90 <= lon <= -74:
            return "PJM"
        if lat >= 37 and -104 < lon <= -90:
            return "MISO" if lat >= 40 else "SPP"
        if lat < 37 and -95 < lon <= -75:
            return "SERC"
        return "MISO"
    if cc == "CN":
        if lat >= 41 and lon >= 118:
            return "CN_NE"
        if lon < 100:
            return "CN_NW"
        if lat >= 36:
            return "CN_N"
        if lat >= 30:
            return "CN_C" if lon < 115 else "CN_E"
        return "CN_S"
    if cc == "IN":
        if lat >= 26:
            return "IN_N"
        if lon <= 76 or lat >= 20:
            return "IN_W" if lon <= 80 else "IN_E"
        return "IN_S"
    if cc == "JP":
        return "JP_E" if lon >= 137.5 else "JP_W"
    if cc == "AU":
        return "WEM" if lon <= 129 else "NEM"
    if cc == "CA":
        if lon <= -95:
            return "CA_W"
        return "CA_ON" if lon <= -76 else "CA_QC"
    if cc == "RU":
        return "RU_EU" if lon <= 60 else "RU_SIB"
    if cc == "BR":
        return "SIN"
    return f"{cc}_GRID"


def load_real_plants(path=None, min_mw=1.0):
    """Yields dicts for every usable plant in the WRI DB."""
    path = path or os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "data", "global_power_plant_database.csv")
    if not os.path.exists(path):
        return []
    out = []
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            cc = ISO3_TO_ISO2.get(row["country"])
            fuel = FUEL_MAP.get(row["primary_fuel"])
            if not cc or not fuel:
                continue
            try:
                cap = float(row["capacity_mw"])
                lat = float(row["latitude"]); lon = float(row["longitude"])
            except (ValueError, TypeError):
                continue
            if cap < min_mw:
                continue
            out.append(dict(
                name=row["name"][:60], cc=cc, fuel=fuel, cap_gw=round(cap / 1000, 4),
                lat=lat, lon=lon, grid=assign_grid(cc, lat, lon),
                solar_cf=solar_cf_from_lat(lat) if fuel == "solar" else None,
                hurricane=hurricane_exposed(lat, lon),
                idnr=row["gppd_idnr"]))
    return out


# ---------------------------------------------------------------- API stubs
def fetch_nasa_power_ghi(lat, lon):
    """NASA POWER climatology (blocked in this sandbox; works on your machine):
    https://power.larc.nasa.gov/api/temporal/climatology/point?parameters=ALLSKY_SFC_SW_DWN
        &community=RE&longitude={lon}&latitude={lat}&format=JSON
    Replace solar_cf_from_lat with this per-site value when you have network access."""
    raise NotImplementedError


def load_era5_capacity_factors(nc_path):
    """Point at an ERA5-derived NetCDF (e.g. via atlite) to replace the latitude
    climatology with hourly-reanalysis capacity factors. Requires xarray+atlite."""
    raise NotImplementedError
