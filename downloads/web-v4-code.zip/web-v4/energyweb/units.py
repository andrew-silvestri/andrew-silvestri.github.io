"""
Rung 1: units before nodes — stress -> real prices.

Each benchmark node gets price(s) = base * exp(k*s). The k's are CALIBRATED so
that replaying a named historical shock through THIS graph reproduces the
observed price peak of that event:

  anchor event                      market     base -> observed peak
  2021-22 Russian supply crisis     TTF        $10  -> $90 /MMBtu   (Aug '22, ~€340/MWh)
  same event, Asian pull            JKM        $10  -> $70 /MMBtu
  Winter Storm Uri (Feb 2021)       HenryHub   $3   -> $23 /MMBtu   (national spot)
  Uri, ERCOT scarcity               ERCOT      $40  -> $9,000 /MWh  (cap, 4 days)
  2022 oil shock                    Brent      $70  -> $128 /bbl
  2021-22 coal squeeze              Newcastle  $60  -> $440 /t

calibrate() runs each anchor scenario on the live graph, reads the stress the
event produces at that node, and solves k = ln(peak/base)/s_event. Prices are
then defined for ANY scenario. This is transfer-calibration, not forecasting —
documented error bars are a factor of ~2.
"""
import math

ANCHORS = [
    # node, base, peak, unit, scenario that reproduces the anchor event
    ("MKT_TTF", 10.0, 90.0, "$/MMBtu", "russia_full_cutoff"),
    ("MKT_JKM", 10.0, 70.0, "$/MMBtu", "russia_full_cutoff"),
    ("MKT_HH", 3.0, 23.0, "$/MMBtu", "texas_uri_repeat"),
    ("ERCOT", 40.0, 9000.0, "$/MWh", "texas_uri_repeat"),
    ("MKT_BRENT", 70.0, 128.0, "$/bbl", "russia_full_cutoff"),
    ("MKT_NEWC", 60.0, 440.0, "$/t", "coal_export_ban"),
    ("MKT_WTI", 68.0, 124.0, "$/bbl", "hormuz_closure"),
    ("MKT_API2", 65.0, 400.0, "$/t", "russia_full_cutoff"),
    ("MKT_EUA", 80.0, 100.0, "$/tCO2", "carbon_price_doubling"),
    ("MKT_URANIUM", 80.0, 110.0, "$/lb", "uranium_squeeze"),
]

DEFAULT_K = 3.0          # for uncalibrated market/grid nodes
GRID_BASE = 45.0         # $/MWh generic grid baseline


class PriceModel:
    def __init__(self, eng):
        from .scenarios import SCENARIOS, resolve_shocks
        self.eng = eng
        self.k = {}
        self.base = {}
        self.unit = {}
        cache = {}
        for node, base, peak, unit, scen in ANCHORS:
            if node not in eng.idx:
                continue
            if scen not in cache:
                sh = resolve_shocks(eng.G, SCENARIOS[scen]["shocks"])
                cache[scen], _ = eng.run(sh)
            s_event = float(cache[scen][eng.idx[node]])
            if s_event <= 0.02:
                continue
            self.k[node] = min(math.log(peak / base) / s_event, 15.0)
            self.base[node] = base
            self.unit[node] = unit

    def price(self, node, s):
        base = self.base.get(node, GRID_BASE if node in self.eng.G and
                             self.eng.G.nodes[node]["kind"] == "grid" else None)
        if base is None:
            return None
        k = self.k.get(node, DEFAULT_K)
        return base * math.exp(k * max(min(s, 1.0), -1.0))

    def table(self, state):
        """Price readout for all calibrated nodes under a propagated state."""
        rows = []
        for node in self.base:
            s = float(state[self.eng.idx[node]])
            rows.append(dict(node=node, name=self.eng.G.nodes[node]["name"],
                             stress=round(s, 4), base=self.base[node],
                             price=round(self.price(node, s), 2),
                             unit=self.unit[node], k=round(self.k[node], 2)))
        return sorted(rows, key=lambda r: -abs(r["stress"]))
