"""
Rung 4: merit-order dispatch core per grid.

Builds a supply curve from the grid's REAL fleet (WRI DB), prices fuel from the
calibrated units layer, derates units by their propagated stress, and clears
demand against the curve. Price = marginal unit's cost (+ scarcity adder as
reserves thin). Run baseline vs scenario to get a real $/MWh delta per grid.
"""
import numpy as np

HEAT_RATE = dict(gas=7.2, coal=9.8, oil=10.5)          # MMBtu/MWh
VOM = dict(gas=3, coal=5, oil=6, nuclear=9, hydro=4, wind=1, solar=1, bio=28, geo=7)
AVAIL = dict(gas=0.90, coal=0.85, oil=0.85, nuclear=0.92, hydro=0.80,
             wind=0.30, solar=0.25, bio=0.7, geo=0.85)
FUEL_MKT = dict(gas={"NorthAmerica": "MKT_HH", "Europe": "MKT_TTF"},
                coal={"Europe": "MKT_API2"}, oil={})
FUEL_BASE = dict(gas=3.0, coal=2.2, oil=12.0)          # $/MMBtu equivalents


def _fuel_price(pm, fuel, region, state):
    """$/MMBtu under the current state (falls back to Asia/global markers)."""
    node = FUEL_MKT.get(fuel, {}).get(region)
    if node is None:
        node = {"gas": "MKT_JKM", "coal": "MKT_NEWC", "oil": "MKT_BRENT"}.get(fuel)
    if node is None or pm is None or node not in pm.base:
        return FUEL_BASE.get(fuel, 0.0)
    s = float(state[pm.eng.idx[node]]) if state is not None else 0.0
    p = pm.price(node, s)
    # convert benchmarks to $/MMBtu-ish: coal $/t /25, oil $/bbl /5.8
    if node in ("MKT_NEWC", "MKT_API2"):
        return p / 25.0
    if node in ("MKT_BRENT", "MKT_WTI"):
        return p / 5.8
    return p


def clear_grid(eng, gid, state=None, pm=None, demand_mult=1.0):
    """Merit-order clearing for one grid. Returns dict with price, margin, stack."""
    G = eng.G
    nd = G.nodes[gid]
    fleet = []
    for n in G.predecessors(gid):
        d = G.nodes[n]
        if d.get("kind") != "station":
            continue
        fuel = d["fuel"]
        stress = float(state[eng.idx[n]]) if state is not None else 0.0
        avail = d.get("solar_cf", AVAIL[fuel]) if fuel == "solar" else AVAIL[fuel]
        cap0 = d.get("cap_gw", d.get("size", 0.1)) * avail
        if cap0 <= 0:
            continue
        fp = _fuel_price(pm, fuel, d.get("region", ""), state)
        mc = VOM[fuel] + HEAT_RATE.get(fuel, 0.0) * fp
        fleet.append((mc, cap0, max(0.0, min(stress, 1.0)), fuel, n))
    demand = nd["demand_gw"] * demand_mult
    # WRI-coverage correction, computed on the UNDERATED fleet so it is identical
    # for baseline and scenario runs: if the listed fleet can't meet baseline
    # demand + margin, scale up (unlisted/distributed capacity).
    total0 = sum(c for _, c, _, _, _ in fleet)
    coverage = 1.0
    if 0 < total0 < demand * 1.25:
        coverage = demand * 1.35 / total0
    fleet = sorted((mc, cap0 * coverage * (1 - st), fuel, n)
                   for mc, cap0, st, fuel, n in fleet)
    # demand-side stress raises load a touch (scarcity events co-move with weather)
    if state is not None:
        gs = float(state[eng.idx[gid]])
        demand *= (1 + 0.15 * max(gs, 0))
    cum, price, marginal = 0.0, None, None
    for mc, cap, fuel, n in fleet:
        cum += cap
        if cum >= demand:
            price, marginal = mc, fuel
            break
    total_cap = sum(c for _, c, _, _ in fleet)
    if price is None:                                   # shortfall -> scarcity pricing
        price, marginal = 9000.0, "SCARCITY"
    else:
        margin = (total_cap - demand) / max(demand, 1e-6)
        if margin < 0.15:                               # scarcity adder as reserves thin
            price += (0.15 - margin) / 0.15 * 2000.0
    return dict(grid=gid, demand_gw=round(demand, 2),
                available_gw=round(total_cap, 2),
                reserve_margin=round((total_cap - demand) / max(demand, 1e-6), 3),
                price=round(price, 2), marginal_fuel=marginal, units=len(fleet))


def price_deltas(eng, state, pm=None, grids=None):
    """Baseline vs scenario clearing for the chosen grids."""
    grids = grids or [n for n, d in eng.G.nodes(data=True) if d["kind"] == "grid"]
    rows = []
    for gid in grids:
        base = clear_grid(eng, gid, None, pm)
        scen = clear_grid(eng, gid, state, pm)
        rows.append(dict(grid=gid, name=eng.G.nodes[gid]["name"],
                         base_price=base["price"], scen_price=scen["price"],
                         delta=round(scen["price"] - base["price"], 2),
                         marginal=scen["marginal_fuel"],
                         reserve_margin=scen["reserve_margin"]))
    rows.sort(key=lambda r: -abs(r["delta"]))
    return rows
