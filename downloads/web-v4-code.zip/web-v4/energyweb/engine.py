"""
Shock propagation engine.

State: stress s_i ∈ [0, 1] per node (0 = normal, 1 = fully disrupted/max-tight).
Signed edges allowed (relief measures, demand destruction).

Update (synchronous, damped, saturating):
    inflow_i  = Σ_j w_ji · s_j
    s_i(t+1)  = (1-λ)·s_i(t) + λ·clip( shock_i + (1 - resilience_i)·inflow_i )
    clip via tanh into [−0.2, 1] then clamp to [0, 1] for reporting.

Converges in ~30-60 rounds. `first_hit` records the round each node first
exceeded a visibility threshold — the ripple wavefront.
"""
import numpy as np


class Engine:
    def __init__(self, G):
        self.G = G
        self.nodes = list(G.nodes)
        self.idx = {n: i for i, n in enumerate(self.nodes)}
        n = len(self.nodes)
        self.res = np.array([G.nodes[m].get("resilience", 0.35) for m in self.nodes])
        rows, cols, ws = [], [], []
        for u, v, d in G.edges(data=True):
            rows.append(self.idx[v]); cols.append(self.idx[u]); ws.append(d["w"])
        self.rows = np.array(rows); self.cols = np.array(cols); self.ws = np.array(ws)
        self.n = n

    def run(self, shocks: dict, rounds=60, lam=0.55, thresh=0.02):
        """shocks: {node_id: magnitude in [0,1] (or negative for relief)}.
        Returns (impact array aligned to self.nodes, first_hit dict)."""
        b = np.zeros(self.n)
        for k, v in shocks.items():
            if k in self.idx:
                b[self.idx[k]] = v
        s = b.copy()
        first_hit = np.full(self.n, -1)
        first_hit[np.abs(s) >= thresh] = 0
        for r in range(1, rounds + 1):
            inflow = np.zeros(self.n)
            np.add.at(inflow, self.rows, self.ws * s[self.cols])
            target = np.tanh(b + (1.0 - self.res) * inflow)
            s_new = (1 - lam) * s + lam * target
            newly = (first_hit < 0) & (np.abs(s_new) >= thresh)
            first_hit[newly] = r
            if np.max(np.abs(s_new - s)) < 1e-5:
                s = s_new
                break
            s = s_new
        return np.clip(s, -1, 1), first_hit

    def report(self, s, first_hit, top=25, exclude_shocked=None):
        order = np.argsort(-np.abs(s))
        out = []
        for i in order[: top * 3]:
            nid = self.nodes[i]
            if exclude_shocked and nid in exclude_shocked:
                continue
            nd = self.G.nodes[nid]
            out.append(dict(id=nid, name=nd["name"], kind=nd["kind"],
                            country=nd.get("country", ""), impact=round(float(s[i]), 4),
                            hit_round=int(first_hit[i])))
            if len(out) >= top:
                break
        return out

    def layer_summary(self, s):
        from collections import defaultdict
        acc = defaultdict(list)
        for i, nid in enumerate(self.nodes):
            acc[self.G.nodes[nid]["kind"]].append(abs(float(s[i])))
        return {k: dict(mean=round(float(np.mean(v)), 4),
                        max=round(float(np.max(v)), 4),
                        touched=int(sum(1 for x in v if x >= 0.02)),
                        n=len(v))
                for k, v in sorted(acc.items())}

    def intervention_add_capacity(self, grid_id, fuel="nuclear", gw=1.0, cf=None):
        """What-if: add a plant at `grid_id` and settle the ripple.

        Mechanics: new supply = price/scarcity RELIEF (negative stress) at the grid
        and at the displaced fuel's national supply node. Propagates through signed
        edges; consumer `demand_response` edges convert relief into added load
        (the Jevons machinery). Post-processing splits the outcome into
        substitution vs rebound and reports mix, price and CO2 deltas.
        """
        import numpy as np
        from .society_data import MERIT_DISPLACEMENT, EMISSION_T_PER_GWH
        G = self.G
        assert grid_id in G and G.nodes[grid_id]["kind"] == "grid", "unknown grid"
        nd = G.nodes[grid_id]
        cc, gd = nd["country"], nd["demand_gw"]
        cf = cf if cf is not None else dict(nuclear=0.90, solar=0.25, wind=0.35,
                                            gas=0.55, coal=0.60, hydro=0.45).get(fuel, 0.5)
        # which fuel gets displaced (merit order: priciest fossil first, present in mix)
        cmix = next(c for c in G.graph["countries"] if c[0] == cc)[4]
        displaced = next((f for f in MERIT_DISPLACEMENT if cmix.get(f, 0) > 0.01), "gas")
        relief = -min(0.85, 0.9 * gw * cf / max(gd, 0.5))
        shocks = {grid_id: relief, f"SUP_{cc}_{displaced}": relief * 0.6}
        s, fh = self.run(shocks)

        # rebound accounting over consumer nodes (relief -> added demand)
        rebound_gw = 0.0
        touched_cons = 0
        for i, n in enumerate(self.nodes):
            d = G.nodes[n]
            if d["kind"] == "consumer" and s[i] < -0.005:
                add = -float(s[i]) * d["elasticity"] * d["rebound"] * d["demand_gw"] * 0.5
                rebound_gw += add
                touched_cons += 1
        added_gw_avg = gw * cf
        rebound_frac = min(rebound_gw / added_gw_avg, 1.5) if added_gw_avg > 0 else 0
        displaced_gw = added_gw_avg * max(0.0, 1 - rebound_frac)
        verdict = ("JEVONS BACKFIRE (rebound > new supply)" if rebound_frac >= 1.0 else
                   "PARTIAL REBOUND — some new demand induced" if rebound_frac >= 0.25 else
                   "SUBSTITUTION-DOMINATED — mostly displaces the marginal fuel")
        co2_delta_mt = (-(displaced_gw * 8760 * EMISSION_T_PER_GWH[displaced])
                        + added_gw_avg * 8760 * EMISSION_T_PER_GWH.get(fuel, 0)) / 1e6
        # price relief readouts
        def s_of(nid):
            return float(s[self.idx[nid]]) if nid in self.idx else 0.0
        # new country mix
        newmix = dict(cmix)
        total = gd / max(nd["demand_gw"], 1e-9)  # grid share only; report grid-level mix
        mix_grid = {f: v for f, v in cmix.items() if v > 0.005}
        add_share = added_gw_avg / (gd + added_gw_avg - displaced_gw)
        newmix_grid = {f: v * (1 - add_share) for f, v in mix_grid.items()}
        newmix_grid[fuel] = newmix_grid.get(fuel, 0) + add_share
        newmix_grid[displaced] = max(0.0, newmix_grid.get(displaced, 0)
                                     - displaced_gw / max(gd, 1e-9) * (1 - add_share))
        norm = sum(newmix_grid.values())
        newmix_grid = {f: round(v / norm, 4) for f, v in newmix_grid.items()}
        return dict(
            grid=grid_id, fuel=fuel, gw=gw, cf=cf, avg_gw=round(added_gw_avg, 3),
            displaced_fuel=displaced, rebound_gw=round(rebound_gw, 3),
            rebound_frac=round(rebound_frac, 3), displaced_gw=round(displaced_gw, 3),
            verdict=verdict, co2_delta_mt_per_yr=round(co2_delta_mt, 3),
            grid_price_relief=round(-s_of(grid_id), 4),
            fuel_price_relief=round(-s_of(f"SUP_{cc}_{displaced}"), 4),
            market_relief={m: round(-s_of(m), 4) for m in
                           ("MKT_HH", "MKT_TTF", "MKT_JKM", "MKT_BRENT", "MKT_NEWC")
                           if abs(s_of(m)) > 0.002},
            consumers_responding=touched_cons,
            new_mix=dict(sorted(newmix_grid.items(), key=lambda kv: -kv[1])),
            state=s, first_hit=fh, shocks=shocks)

    def trace_paths(self, shocks, target, k=3):
        """k highest-weight simple paths (<=6 hops) from any shocked node to target."""
        import networkx as nx
        best = []
        for src in shocks:
            if src not in self.G or target not in self.G:
                continue
            try:
                for path in nx.shortest_simple_paths(self.G, src, target, weight=None):
                    if len(path) > 7:
                        break
                    wprod = 1.0
                    for a, b in zip(path, path[1:]):
                        wprod *= abs(self.G[a][b]["w"])
                    best.append((wprod, path))
                    if len(best) > 40:
                        break
            except nx.NetworkXNoPath:
                continue
        best.sort(key=lambda t: -t[0])
        return best[:k]
