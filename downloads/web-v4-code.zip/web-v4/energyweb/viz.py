"""Visualization: layered web overview, ripple maps, cascade charts."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from .build import LAYER_NAMES

LAYER_X = {0: 0.0, 1: 1.0, 2: 2.0, 3: 3.2, 4: 4.4, 5: 5.6, 6: 6.8, 7: 8.2,
           10: 9.4, 11: 10.6, 8: 11.8, 9: 13.0, 12: 14.2}
LAYER_LABEL = {0: "Policy", 1: "Chokepoints", 2: "Basins", 3: "Midstream",
               4: "Markets", 5: "Fuel supply", 6: "Stations", 7: "Grids",
               10: "Districts", 11: "Consumers", 8: "Sectors", 9: "Weather",
               12: "Sun"}
KIND_COLOR = dict(policy="#8172B3", chokepoint="#C44E52", basin="#937860",
                  midstream="#DD8452", market="#CCB974", supply="#DA8BC3",
                  station="#4C72B0", grid="#55A868", sector="#64B5CD",
                  weather="#8C8C8C", district="#2E8B8B", consumer="#B47CC7",
                  sun="#E8A33D")


def layout(G, seed=3):
    """Deterministic layered layout: x by layer, y spread by hash w/ jitter."""
    rng = np.random.default_rng(seed)
    pos = {}
    from collections import defaultdict
    per_layer = defaultdict(list)
    for n, d in G.nodes(data=True):
        per_layer[d["layer"]].append(n)
    for lay, nodes in per_layer.items():
        nodes.sort()
        ys = np.linspace(0, 1, len(nodes))
        jitter = rng.normal(0, 0.15 / max(len(nodes), 10), len(nodes))
        for n, y, j in zip(nodes, ys, jitter):
            pos[n] = (LAYER_X[lay] + rng.normal(0, 0.14), float(np.clip(y + j, 0, 1)))
    return pos


def _draw_edges(ax, G, pos, alpha=0.05, lw=0.3, max_edges=25000):
    edges = list(G.edges())
    if len(edges) > max_edges:                      # sample for drawing speed only
        step = len(edges) // max_edges + 1
        edges = edges[::step]
    segs = [(pos[u], pos[v]) for u, v in edges]
    ax.add_collection(LineCollection(segs, colors="gray", alpha=alpha,
                                     linewidths=lw, zorder=1, rasterized=True))


def fig_overview(G, path):
    pos = layout(G)
    fig, ax = plt.subplots(figsize=(17, 9.5))
    _draw_edges(ax, G, pos)
    for kind, color in KIND_COLOR.items():
        xs, ys, ss = [], [], []
        for n, d in G.nodes(data=True):
            if d["kind"] == kind:
                xs.append(pos[n][0]); ys.append(pos[n][1])
                ss.append(4 + 14 * min(d.get("size", 1), 6))
        ax.scatter(xs, ys, s=ss, c=color, label=f"{kind} ({len(xs)})",
                   alpha=0.75, linewidths=0, zorder=3, rasterized=True)
    for lay, lab in LAYER_LABEL.items():
        ax.text(LAYER_X[lay], 1.045, lab, ha="center", fontsize=11, fontweight="bold")
    ax.legend(loc="lower center", ncol=5, fontsize=9, frameon=True,
              bbox_to_anchor=(0.5, -0.08))
    ax.set_title(f"World Energy Web — {G.number_of_nodes():,} nodes, "
                 f"{G.number_of_edges():,} edges "
                 f"({G.graph.get('n_stations', 0):,} individual generation stations)",
                 fontsize=14)
    ax.set_xlim(-0.6, 14.8); ax.set_ylim(-0.05, 1.09)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_ripple(G, eng, s, shocks, title, path):
    pos = layout(G)
    fig, ax = plt.subplots(figsize=(17, 9.5))
    _draw_edges(ax, G, pos, alpha=0.03)
    imp = np.abs(s)
    xs = np.array([pos[n][0] for n in eng.nodes])
    ys = np.array([pos[n][1] for n in eng.nodes])
    sizes = np.array([4 + 13 * min(G.nodes[n].get("size", 1), 6) for n in eng.nodes])
    quiet = imp < 0.02
    ax.scatter(xs[quiet], ys[quiet], s=sizes[quiet] * 0.5, c="#DDDDDD",
               alpha=0.5, linewidths=0, zorder=2, rasterized=True)
    hot = ~quiet
    sc = ax.scatter(xs[hot], ys[hot], s=sizes[hot] * (1 + 3 * imp[hot]),
                    c=imp[hot], cmap="inferno_r", vmin=0, vmax=max(0.4, imp.max()),
                    alpha=0.95, linewidths=0, zorder=3, rasterized=True)
    fig.colorbar(sc, ax=ax, label="|stress|", shrink=0.7)
    for nid in shocks:
        if nid in pos:
            ax.scatter(*pos[nid], s=520, marker="*", c="red", edgecolors="k",
                       zorder=5)
            ax.annotate(G.nodes[nid]["name"], pos[nid], xytext=(8, 10),
                        textcoords="offset points", fontsize=10, fontweight="bold",
                        color="darkred")
    for lay, lab in LAYER_LABEL.items():
        ax.text(LAYER_X[lay], 1.045, lab, ha="center", fontsize=11, fontweight="bold")
    touched = int((imp >= 0.02).sum())
    ax.set_title(f"{title}\n{touched:,} of {len(eng.nodes):,} nodes touched (|stress| ≥ 0.02)",
                 fontsize=13)
    ax.set_xlim(-0.6, 14.8); ax.set_ylim(-0.05, 1.09)
    ax.axis("off")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_cascade(G, eng, s, fh, shocks, title, path, top=28):
    rep = eng.report(s, fh, top=top, exclude_shocked=set(shocks))
    rep = rep[::-1]
    fig, ax = plt.subplots(figsize=(11, 0.34 * top + 2))
    ys = np.arange(len(rep))
    vals = [r["impact"] for r in rep]
    cols = [KIND_COLOR.get(r["kind"], "gray") for r in rep]
    ax.barh(ys, vals, color=cols, alpha=0.9)
    for y, r in zip(ys, rep):
        ax.text(0.003, y, f" {r['name'][:58]}  (r{r['hit_round']})",
                va="center", fontsize=8)
    ax.set_yticks([])
    ax.set_xlabel("stress")
    ax.set_title(f"{title} — top propagated impacts (rN = round first hit)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_wavefront(G, eng, fh, s, title, path):
    fig, ax = plt.subplots(figsize=(10, 5.5))
    kinds = list(KIND_COLOR)
    for kind in kinds:
        rounds = [fh[i] for i, n in enumerate(eng.nodes)
                  if G.nodes[n]["kind"] == kind and fh[i] >= 0 and abs(s[i]) >= 0.02]
        if rounds:
            ax.scatter([np.median(rounds)], [kinds.index(kind)],
                       s=200 + 12 * len(rounds), c=KIND_COLOR[kind], alpha=0.85)
            ax.annotate(f"{len(rounds)} nodes", (np.median(rounds), kinds.index(kind)),
                        xytext=(12, -4), textcoords="offset points", fontsize=9)
    ax.set_yticks(range(len(kinds)))
    ax.set_yticklabels(kinds)
    ax.set_xlabel("median round of first impact (ripple time)")
    ax.set_title(f"{title} — wavefront timing by layer")
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_scenario_matrix(matrix, scen_names, layer_names, path):
    fig, ax = plt.subplots(figsize=(11, 0.5 * len(scen_names) + 2.5))
    im = ax.imshow(matrix, cmap="inferno_r", aspect="auto")
    ax.set_xticks(range(len(layer_names)))
    ax.set_xticklabels(layer_names, rotation=35, ha="right")
    ax.set_yticks(range(len(scen_names)))
    ax.set_yticklabels(scen_names, fontsize=9)
    fig.colorbar(im, label="mean |stress| in layer")
    ax.set_title("Scenario × layer impact matrix — how shocks land across the chain")
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def fig_intervention(result, path):
    """Waterfall + mix chart for an add-capacity what-if."""
    import matplotlib.pyplot as plt
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5.5))
    # waterfall: added -> rebound -> net displaced
    vals = [result["avg_gw"], -result["rebound_gw"], -result["displaced_gw"]]
    labels = [f"new {result['fuel']}\n(avg GW)", "demand rebound\n(Jevons)",
              f"displaced {result['displaced_fuel']}"]
    run = 0
    for i, (v, l) in enumerate(zip(vals, labels)):
        a1.bar(i, v, bottom=(run if v < 0 else 0) if i else 0,
               color=["#55A868", "#C44E52", "#4C72B0"][i])
        a1.text(i, max(run + v, run) + 0.05, f"{abs(v):.2f} GW", ha="center", fontsize=10)
        run += v if i else v
    a1.set_xticks(range(3)); a1.set_xticklabels(labels, fontsize=9)
    a1.set_ylabel("average GW")
    a1.set_title(f"{result['grid']}: +{result['gw']} GW {result['fuel']} — {result['verdict']}\n"
                 f"CO2 {result['co2_delta_mt_per_yr']:+.2f} Mt/yr · "
                 f"{result['consumers_responding']} consumer groups responded", fontsize=10)
    a1.grid(axis="y", alpha=0.3)
    mix = result["new_mix"]
    a2.barh(list(mix.keys())[::-1], list(mix.values())[::-1], color="#4C72B0", alpha=0.85)
    a2.set_title("post-intervention energy mix (country-mix basis)")
    a2.set_xlabel("share")
    a2.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
