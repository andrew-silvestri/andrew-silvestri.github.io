"""
v2 data: society/consumer archetypes, solar chain, district generation parameters.
All parameters are structural estimates in [0,1]; edit and rebuild.
"""

# per-region society defaults: (car_culture, green_mentality, ev_share, income_split(lo,mid,hi))
REGION_SOCIETY = {
    "NorthAmerica": (0.85, 0.35, 0.12, (0.30, 0.45, 0.25)),
    "SouthAmerica": (0.55, 0.40, 0.04, (0.45, 0.40, 0.15)),
    "Europe":       (0.55, 0.60, 0.25, (0.25, 0.50, 0.25)),
    "Eurasia":      (0.55, 0.20, 0.05, (0.40, 0.45, 0.15)),
    "MiddleEast":   (0.80, 0.15, 0.03, (0.30, 0.40, 0.30)),
    "Africa":       (0.40, 0.30, 0.01, (0.60, 0.30, 0.10)),
    "Asia":         (0.45, 0.35, 0.15, (0.45, 0.40, 0.15)),
    "Oceania":      (0.80, 0.50, 0.10, (0.25, 0.45, 0.30)),
}

# country overrides (code -> same tuple); extend freely
COUNTRY_SOCIETY = {
    "US": (0.92, 0.35, 0.12, (0.28, 0.44, 0.28)),
    "NO": (0.60, 0.80, 0.85, (0.15, 0.50, 0.35)),
    "CN": (0.45, 0.40, 0.35, (0.40, 0.45, 0.15)),
    "IN": (0.35, 0.30, 0.06, (0.55, 0.35, 0.10)),
    "DE": (0.65, 0.65, 0.25, (0.22, 0.52, 0.26)),
    "JP": (0.55, 0.50, 0.12, (0.20, 0.55, 0.25)),
    "SA": (0.90, 0.10, 0.02, (0.25, 0.40, 0.35)),
    "BR": (0.55, 0.45, 0.05, (0.45, 0.38, 0.17)),
}

# consumer archetypes: (tag, elasticity_of_demand, weather_sensitivity, notes)
CONSUMER_ARCHETYPES = [
    ("lowincome",  0.55, 0.60),   # price-sensitive, weather-exposed
    ("midincome",  0.35, 0.40),
    ("highincome", 0.15, 0.25),   # inelastic
    ("industry",   0.45, 0.15),   # curtails on price, insensitive to weather
]

# mentality modifiers on elasticity: green households respond more to price AND
# rebound less (sufficiency); consumerist rebound more (Jevons-prone)
MENTALITY_REBOUND = dict(green=0.4, neutral=1.0, consumerist=1.6)

# insolation belts: (id, name, regions served, solar_quality 0-1)
INSOLATION_BELTS = [
    ("INS_SUNBELT_NA", "North American sunbelt", ["NorthAmerica"], 0.85),
    ("INS_NORTH_NA", "Northern North America", ["NorthAmerica"], 0.55),
    ("INS_EU_SOUTH", "Southern Europe belt", ["Europe"], 0.70),
    ("INS_EU_NORTH", "Northern Europe belt", ["Europe"], 0.40),
    ("INS_MENA", "MENA solar belt", ["MiddleEast", "Africa"], 0.95),
    ("INS_ASIA_S", "South/SE Asia belt", ["Asia"], 0.70),
    ("INS_ASIA_E", "East Asia belt", ["Asia", "Eurasia"], 0.55),
    ("INS_OCEANIA", "Australian belt", ["Oceania"], 0.90),
    ("INS_LATAM", "Latin America belt", ["SouthAmerica"], 0.80),
]

SUN_NODE = ("SUN", "Solar output variability (solar cycle + irradiance anomalies)")

# districts per grid: count scales with demand; density knob in build
DISTRICT_MIN, DISTRICT_MAX = 4, 120

# fuels considered displaceable by a new zero-marginal-cost plant, in merit order
# (highest marginal cost displaced first)
MERIT_DISPLACEMENT = ["oil", "gas", "coal"]

EMISSION_T_PER_GWH = dict(coal=950, gas=420, oil=700, nuclear=0, hydro=0,
                          wind=0, solar=0, bio=50, geo=30)
