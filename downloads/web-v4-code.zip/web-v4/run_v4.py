"""
v4 final run:  python3 run_v4.py
Builds the ~1M-node web, calibrates units, replays all historical events,
writes figures + CSVs + navigator.html (self-contained explorer).
"""
import os, sys, json, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
OUT = os.path.join(HERE, "outputs")
os.makedirs(OUT, exist_ok=True)

from energyweb.build import build as build_core
from energyweb.engine import Engine as EngineV3
from energyweb.units import PriceModel
from v4.build4 import build_v4, KINDS, KIND_CODE, CHAIN
from v4.engine4 import Engine4
from v4 import history, viz4
from v4.cohorts import trend_series


def main():
    print("== calibrating units layer on the v3 core ...")
    Gc = build_core(verbose=False) if "verbose" in build_core.__code__.co_varnames else build_core()
    pm = PriceModel(EngineV3(Gc))
    del Gc

    print("== building v4 mega-web ...")
    w = build_v4()
    eng = Engine4(w)
    viz4.fig_census(w, os.path.join(OUT, "fig1_census.png"))

    events_results = {}
    event_layers = {}
    event_farm = {}
    nav_events = []
    for name, ev in history.EVENTS.items():
        shocks = history.resolve(w, w.idx, ev["shocks"])
        s, fh = eng.run(shocks)
        touched = int((np.abs(s) >= 0.02).sum())
        stress_at = {m: float(s[w.idx[m]]) for m in
                     ("MKT_BRENT", "MKT_WTI", "MKT_TTF", "MKT_JKM", "MKT_HH",
                      "MKT_NEWC", "ERCOT") if m in w.idx}
        ls = eng.layer_summary(s)
        top = eng.top(s, fh, k=25, exclude=set(ev["shocks"]))
        events_results[name] = (ev, stress_at)
        event_layers[name] = ls
        event_farm[name] = ls.get("farm", {}).get("touched", 0)
        print(f"  {name:26s} {ev['year']}  touched {touched:>7,}  "
              f"farms {event_farm[name]:>6,}  cars {ls['car']['touched']:>7,}")
        nav_events.append(dict(
            id=name, year=ev["year"], kilian=ev["kilian"], desc=ev["description"],
            touched=touched, layers=ls, top=top,
            prices={m: dict(stress=round(v, 3),
                            mult=(round(float(np.exp(pm.k.get(m, 3) * v)), 2)
                                  if m in pm.k else None))
                    for m, v in stress_at.items() if abs(v) > 0.01}))
        with open(os.path.join(OUT, f"impacts_{name}.csv"), "w", newline="") as f:
            cw = csv.writer(f)
            cw.writerow(["name", "kind", "impact", "round"])
            for r in top:
                cw.writerow([r["name"], r["kind"], r["impact"], r["round"]])

    rows = history.validate(events_results, pm.k, pm.base)
    with open(os.path.join(OUT, "event_validation.csv"), "w", newline="") as f:
        cw = csv.DictWriter(f, fieldnames=list(rows[0]))
        cw.writeheader(); cw.writerows(rows)
    viz4.fig_validation(rows, os.path.join(OUT, "fig2_validation.png"))
    viz4.fig_event_matrix(event_layers, os.path.join(OUT, "fig3_event_matrix.png"))
    tr = trend_series()
    viz4.fig_trends(tr, os.path.join(OUT, "fig4_trends.png"))
    viz4.fig_farm_response(event_farm, os.path.join(OUT, "fig5_farm_response.png"))

    # climate tab data: climate-cell + chain states under two climate-relevant runs
    s_cl, _ = eng.run({w.n_core + CHAIN.index("CLIMATE_SYS"): 0.7})
    climate = dict(
        note="CLIMATE_SYS forcing 0.7 (accelerating-anomaly scenario)",
        global_temp_stress=round(float(s_cl[w.n_core + CHAIN.index("GLOBAL_TEMP")]), 3),
        cells_touched=int(eng.layer_summary(s_cl)["climate_cell"]["touched"]),
        farms_touched=int(eng.layer_summary(s_cl)["farm"]["touched"]),
        layers=eng.layer_summary(s_cl))

    census = {k: int((w.kind == i).sum()) for i, k in enumerate(KINDS)}
    data = dict(
        meta=dict(nodes=int(len(w.kind)), edges=int(len(w.edges[2])),
                  core=int(w.n_core), title="World Energy Web v4"),
        census=census, events=nav_events, validation=rows, trends=tr,
        climate=climate,
        samples=eng.sample_nodes(per_kind=220),
        psych=["habit_inertia", "loss_aversion", "status_signal", "dissonance",
               "social_norm", "present_bias"])
    with open(os.path.join(OUT, "navigator_data.json"), "w") as f:
        json.dump(data, f)

    tpl = open(os.path.join(HERE, "v4", "navigator_template.html")).read()
    html = tpl.replace("/*__DATA__*/null", json.dumps(data))
    with open(os.path.join(HERE, "navigator.html"), "w") as f:
        f.write(html)
    print("wrote navigator.html + figures + CSVs →", OUT)


if __name__ == "__main__":
    main()
