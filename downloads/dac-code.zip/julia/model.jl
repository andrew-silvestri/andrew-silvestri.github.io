# DAC Fixed-Bed Adsorption Cycle + TEA — Julia port of ../model.py
# CALF-20 params from CALF20 Calcs.xlsx (Nguyen sheet); Lewatit-type amine calibrated
# to literature anchors (see README). Run locally:
#   julia> using Pkg; Pkg.activate("."); Pkg.instantiate(); include("model.jl")
# Untested in sandbox (Julia unavailable there); logic mirrors verified model.py.

using Printf

const R = 8.314

# CALF-20 dual-site Langmuir (concentration basis, m3/mol)
const Q_B = 2.387;  const Q_D = 3.271
const B0 = 5.519e-7; const D0 = 5.187e-8
const DU_B = -35060.0; const DU_D = -28950.0

# Lewatit-type amine single-site Langmuir (pressure basis, 1/Pa), calibrated
const LEW_QM = 3.4; const LEW_DH = -70000.0; const LEW_B0 = 9.0e-15

function isotherm_calf20(y, P, T)
    c = y * P / (R * T)
    b = B0 * exp(-DU_B / (R * T)); d = D0 * exp(-DU_D / (R * T))
    Q_B * b * c / (1 + b * c) + Q_D * d * c / (1 + d * c)
end

function isotherm_lewatit(y, P, T)
    p = y * P
    b = LEW_B0 * exp(-LEW_DH / (R * T))
    LEW_QM * b * p / (1 + b * p)
end

isotherm(y, P, T, s::Symbol) = s === :calf20 ? isotherm_calf20(y, P, T) : isotherm_lewatit(y, P, T)

Base.@kwdef struct Cycle
    T_ads::Float64 = 298.15;  T_des::Float64 = 373.15
    y_ads::Float64 = 420e-6;  y_des::Float64 = 1.0
    P::Float64 = 101325.0;    P_des::Float64 = 2000.0
    sorbent::Symbol = :lewatit
    cp_sorbent::Float64 = 1.0; steel_ratio::Float64 = 1.0; cp_steel::Float64 = 0.50
    dH_ads::Float64 = 70.0     # kJ/mol
    heat_recovery::Float64 = 0.0
    fan_kwh_per_t::Float64 = 150.0
    sorbent_cost::Float64 = 50.0; sorbent_life::Float64 = 2.0
    capex_per_tpy::Float64 = 2000.0; r::Float64 = 0.08; plant_life::Int = 15
    elec_price::Float64 = 0.065; heat_price::Float64 = 0.02
    fom_frac::Float64 = 0.04; cycles_per_day::Float64 = 6.0
end

function working_capacity(cy::Cycle)
    q_ads = isotherm(cy.y_ads, cy.P, cy.T_ads, cy.sorbent)
    q_des = isotherm(cy.y_des, cy.P_des, cy.T_des, cy.sorbent)
    (max(q_ads - q_des, 0.0), q_ads, q_des)
end

function regen_energy(cy::Cycle)
    dq, _, _ = working_capacity(cy)
    dq <= 0 && return (thermal = Inf, electric = Inf, total = Inf, dq = dq)
    kg_per_kg = dq * 0.044
    sens = (cy.cp_sorbent + cy.steel_ratio * cy.cp_steel) * (cy.T_des - cy.T_ads) *
           (1 - cy.heat_recovery)                       # kJ/kg sorbent
    thermal = (sens / kg_per_kg + cy.dH_ads / 0.044) / 3.6   # kWh_th/tCO2
    (thermal = thermal, electric = cy.fan_kwh_per_t, total = thermal + cy.fan_kwh_per_t, dq = dq)
end

crf(r, n) = r > 0 ? r * (1 + r)^n / ((1 + r)^n - 1) : 1 / n

function cost_per_tonne(cy::Cycle)
    e = regen_energy(cy)
    e.dq <= 0 && return (sorbent = Inf, capex = Inf, fom = Inf, energy = Inf, total = Inf)
    kg_yr = e.dq * 0.044 * cy.cycles_per_day * 365
    sorbent = cy.sorbent_cost / cy.sorbent_life / kg_yr * 1000
    capex = cy.capex_per_tpy * crf(cy.r, cy.plant_life)
    fom = cy.capex_per_tpy * cy.fom_frac
    energy = e.thermal * cy.heat_price + e.electric * cy.elec_price
    (sorbent = sorbent, capex = capex, fom = fom, energy = energy,
     total = sorbent + capex + fom + energy)
end

function main()
    cy = Cycle()
    dq, qa, qd = working_capacity(cy)
    e = regen_energy(cy); c = cost_per_tonne(cy)
    @printf "q_ads=%.4f  q_des=%.4f  dq=%.4f mmol/g\n" qa qd dq
    @printf "thermal=%.1f kWh_th/t  electric=%.1f kWh_e/t\n" e.thermal e.electric
    @printf "cost: sorbent %.1f + capex %.1f + FOM %.1f + energy %.1f = %.1f \$/t\n" c.sorbent c.capex c.fom c.energy c.total
    calf = Cycle(sorbent = :calf20, dH_ads = 35.0)
    @printf "CALF-20 working capacity: %.4f mmol/g (physisorbent fails at 420 ppm)\n" working_capacity(calf)[1]

    try
        @eval using Plots
        ppm = exp10.(range(log10(50), log10(200_000); length = 300))
        plt = plot(xscale = :log10, xlabel = "CO2 partial pressure [ppm]",
                   ylabel = "loading [mmol/g]", title = "Amine vs CALF-20 isotherms", legend = :topleft)
        for (T, ls) in ((298.15, :solid), (373.15, :dash))
            plot!(plt, ppm, [isotherm_lewatit(x * 1e-6, 101325.0, T) for x in ppm];
                  lw = 2.5, ls = ls, color = :green, label = "amine $(round(T-273.15))°C")
            plot!(plt, ppm, [isotherm_calf20(x * 1e-6, 101325.0, T) for x in ppm];
                  lw = 2.5, ls = ls, color = :blue, label = "CALF-20 $(round(T-273.15))°C")
        end
        vline!(plt, [420.0]; color = :black, ls = :dot, label = "ambient")
        savefig(plt, joinpath(@__DIR__, "fig1_isotherms_julia.png"))
        println("figure written")
    catch e
        @warn "Plots.jl unavailable — computation ran, skipped figure" e
    end
end

abspath(PROGRAM_FILE) == @__FILE__ && main()
