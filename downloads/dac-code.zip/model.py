"""
DAC Fixed-Bed Adsorption Cycle + Techno-Economic Model (CALF-20)
================================================================
Grounded in: dac/ folder (Green Fund app), ArchivedDACmassTransfer.pdf scope,
and the dual-site Langmuir parameters in
"Everything From Prior (K Project) Report/Sorbent/CALF20 Calcs.xlsx" (Nguyen sheet).

Model chain:
  1. Dual-site Langmuir isotherm  q(c,T) = qb*b*c/(1+b*c) + qd*d*c/(1+d*c)
     with b = b0*exp(-dUb/RT), d = d0*exp(-dUd/RT), c = y*P/(R*T)  [mol/m3]
  2. Temperature-swing working capacity: adsorb @ Tads, 420 ppm; desorb @ Tdes
     under CO2-rich purge (p_des partial pressure).
  3. Linear-driving-force (LDF) breakthrough curve for a small contactor bed.
  4. Regeneration energy [kWh/tCO2]: sensible heat (sorbent+steel) + heat of
     adsorption + fan work; then $/tCO2 with capex/O&M and tornado sensitivity.

Run: python3 model.py  -> PNGs + CSVs in outputs/
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import figstyle
figstyle.use()
from dataclasses import dataclass, asdict
import os, json, csv

R = 8.314  # J/mol-K
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
os.makedirs(OUT, exist_ok=True)

# ---- CALF-20 CO2 dual-site Langmuir params (from CALF20 Calcs.xlsx, Nguyen sheet)
#      Validated: reproduces the sheet's b@303K = 0.611 m3/mol.
Q_B = 2.387        # mmol/g  site-b capacity
Q_D = 3.271        # mmol/g  site-d capacity
B0 = 5.519e-7      # m3/mol
D0 = 5.187e-8      # m3/mol
DU_B = -35060.0    # J/mol
DU_D = -28950.0    # J/mol


def isotherm_calf20(y_co2, P_total, T):
    """CALF-20 CO2 loading [mmol/g]; concentration basis c = y*P/(R*T) [mol/m3]."""
    c = y_co2 * P_total / (R * T)
    b = B0 * np.exp(-DU_B / (R * T))
    d = D0 * np.exp(-DU_D / (R * T))
    return Q_B * b * c / (1 + b * c) + Q_D * d * c / (1 + d * c)


# ---- Lewatit VP OC 1065-style amine chemisorbent (the K-project's chosen DAC sorbent).
# Single-site Langmuir CALIBRATED to literature anchor points (Bos et al. 2018-type data):
#   q(42 Pa, 25 C) ~ 1.4 mol/kg ; dH ~ -70 kJ/mol. Replace with full Toth fit when refining.
LEW_QM = 3.4       # mol/kg
LEW_DH = -70000.0  # J/mol
LEW_B0 = 9.0e-15   # 1/Pa  (gives b=0.0167 1/Pa at 298 K)


def isotherm_lewatit(y_co2, P_total, T):
    """Amine sorbent CO2 loading [mol/kg == mmol/g]; pressure basis p = y*P [Pa]."""
    p = y_co2 * P_total
    b = LEW_B0 * np.exp(-LEW_DH / (R * T))
    return LEW_QM * b * p / (1 + b * p)


def isotherm_q(y_co2, P_total, T, sorbent="lewatit"):
    if sorbent == "calf20":
        return isotherm_calf20(y_co2, P_total, T)
    return isotherm_lewatit(y_co2, P_total, T)


@dataclass
class Cycle:
    T_ads: float = 298.15      # K adsorption temp (25 C)
    T_des: float = 373.15      # K desorption temp (100 C)
    y_ads: float = 420e-6      # ambient CO2
    y_des: float = 1.0         # pure CO2 headspace during desorption
    P: float = 101325.0        # Pa
    P_des: float = 2000.0      # Pa. Pure CO2 at 20 mbar absolute — a vacuum swing, not a
    #                          steam purge. This is the single most important
    #                          number in the model: at 10 kPa the working
    #                          capacity collapses and cost triples; at 20 kPa
    #                          the cycle stops working altogether. It is now in
    #                          the tornado, where it belongs.
    sorbent: str = "lewatit"   # "lewatit" (working DAC design) or "calf20"
    # energy accounting
    cp_sorbent: float = 1.0    # kJ/kg-K
    steel_ratio: float = 1.0   # kg steel per kg sorbent (contactor mass penalty)
    cp_steel: float = 0.50     # kJ/kg-K
    dH_ads: float = 70.0       # kJ/mol CO2 (amine chemisorption; 35 for CALF-20 physisorption)
    heat_recovery: float = 0.0 # fraction of sensible heat recovered (0 baseline)
    fan_kwh_per_t: float = 150.0  # kWh_e/tCO2 fan work (contactor dP; sensitivity)
    # economics
    sorbent_cost: float = 50.0   # $/kg
    sorbent_life: float = 2.0    # years
    capex_per_tpy: float = 2000.0  # $ per (tCO2/yr) capacity, balance of plant
    r: float = 0.08
    plant_life: int = 15
    elec_price: float = 0.065    # $/kWh
    heat_price: float = 0.02     # $/kWh_th (low-grade heat)
    fom_frac: float = 0.04       # fraction of BoP capex per yr
    cycles_per_day: float = 6.0


def working_capacity(cy: Cycle):
    """mmol CO2 per g sorbent per cycle."""
    q_ads = isotherm_q(cy.y_ads, cy.P, cy.T_ads, cy.sorbent)
    q_des = isotherm_q(cy.y_des, cy.P_des, cy.T_des, cy.sorbent)
    return max(q_ads - q_des, 0.0), q_ads, q_des


def regen_energy(cy: Cycle):
    """Thermal + electric energy per tonne CO2 captured [kWh/t]."""
    dq, *_ = working_capacity(cy)              # mmol/g = mol/kg
    if dq <= 0:
        return dict(thermal=np.inf, electric=np.inf, total=np.inf, dq=dq)
    kg_co2_per_kg_sorb = dq * 0.044            # kg CO2 / kg sorbent / cycle
    dT = cy.T_des - cy.T_ads
    sensible = (cy.cp_sorbent + cy.steel_ratio * cy.cp_steel) * dT * (1 - cy.heat_recovery)  # kJ/kg sorbent
    sens_per_kg_co2 = sensible / kg_co2_per_kg_sorb          # kJ/kg CO2
    dh_per_kg_co2 = cy.dH_ads / 0.044                        # kJ/kg CO2
    thermal_kwh_t = (sens_per_kg_co2 + dh_per_kg_co2) / 3.6  # kWh_th/tCO2
    return dict(thermal=thermal_kwh_t, electric=cy.fan_kwh_per_t,
                total=thermal_kwh_t + cy.fan_kwh_per_t, dq=dq)


def crf(r, n):
    return r * (1 + r) ** n / ((1 + r) ** n - 1) if r > 0 else 1 / n


def cost_per_tonne(cy: Cycle):
    """$/tCO2 captured."""
    e = regen_energy(cy)
    dq = e["dq"]
    if dq <= 0:  # cycle infeasible (e.g., desorb T too low vs CO2 backpressure)
        return dict(sorbent=np.inf, capex=np.inf, fom=np.inf, energy=np.inf,
                    total=np.inf, thermal=np.inf, electric=np.inf, dq=dq)
    kg_co2_per_kg_sorb_yr = dq * 0.044 * cy.cycles_per_day * 365
    sorbent_pt = cy.sorbent_cost / cy.sorbent_life / kg_co2_per_kg_sorb_yr * 1000
    capex_pt = cy.capex_per_tpy * crf(cy.r, cy.plant_life)
    fom_pt = cy.capex_per_tpy * cy.fom_frac
    energy_pt = e["thermal"] * cy.heat_price + e["electric"] * cy.elec_price  # kWh/t * $/kWh
    total = sorbent_pt + capex_pt + fom_pt + energy_pt
    return dict(sorbent=sorbent_pt, capex=capex_pt, fom=fom_pt,
                energy=energy_pt, total=total,
                thermal=e["thermal"], electric=e["electric"], dq=e["dq"])


def breakthrough(cy: Cycle, bed_kg=10.0, flow_m3_h=300.0, kldf=0.002):
    """LDF breakthrough: dq/dt = k(q*-q); gas-phase CO2 balance over bed (CSTR-in-series x1).
    Returns t [h], outlet/inlet CO2 ratio."""
    c_in = cy.y_ads * cy.P / (R * cy.T_ads)          # mol/m3
    q_star = isotherm_q(cy.y_ads, cy.P, cy.T_ads, cy.sorbent)  # mmol/g equilibrium
    Q = flow_m3_h / 3600.0                            # m3/s
    n_in = Q * c_in                                   # mol/s CO2 in
    q = 0.0                                           # mol/kg loading
    q_eq = q_star                                     # mol/kg (mmol/g)
    dt = 30.0                                         # s
    t_end = 48 * 3600
    ts, ratio = [], []
    for i in range(int(t_end / dt)):
        uptake = kldf * (q_eq - q) * bed_kg           # mol/s if q in mol/kg
        uptake = min(uptake, n_in)                    # can't capture more than inflow
        q += uptake / bed_kg * dt
        ts.append(i * dt / 3600)
        ratio.append(1 - uptake / n_in)
    return np.array(ts), np.array(ratio), q


# --------------------------------------------------------------------- figures
def fig_isotherms():
    ppm = np.logspace(np.log10(50), np.log10(200000), 300)
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    for T, ls in [(298.15, "-"), (373.15, "--")]:
        ax.plot(ppm, isotherm_lewatit(ppm * 1e-6, 101325.0, T), ls, lw=2.5,
                color=figstyle.GREEN, label=f"Lewatit-type amine, {T-273.15:.0f} °C")
        ax.plot(ppm, isotherm_calf20(ppm * 1e-6, 101325.0, T), ls, lw=2.5,
                color="tab:blue", label=f"CALF-20 (your Nguyen params), {T-273.15:.0f} °C")
    ax.axvline(420, color="k", ls=":", lw=1)
    ax.annotate("ambient\n420 ppm", (460, 2.6), fontsize=9)
    ax.set_xscale("log")
    ax.set_xlabel("CO₂ partial pressure [ppm of 1 atm]")
    ax.set_ylabel("CO₂ loading  [mmol/g]")
    ax.set_title("Why the K-project picked an amine: chemisorbent holds loading at 420 ppm;\n"
                 "CALF-20 (flue-gas physisorbent) is nearly empty there")
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3, which="both")
    figstyle.finish(fig, f"{OUT}/fig1_isotherms.png")


def fig_working_capacity(cy: Cycle):
    Tdes = np.linspace(330, 420, 200)
    dq = []
    for T in Tdes:
        c = Cycle(**{**asdict(cy), "T_des": T})
        dq.append(working_capacity(c)[0])
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.plot(Tdes - 273.15, dq, lw=2.5)
    base_dq = working_capacity(cy)[0]
    ax.plot(cy.T_des - 273.15, base_dq, "k*", ms=15)
    ax.annotate(f"baseline {base_dq:.3f} mmol/g @ {cy.T_des-273.15:.0f} °C",
                (cy.T_des - 273.15 + 2, base_dq), fontsize=9)
    ax.set_xlabel("Desorption temperature [°C]")
    ax.set_ylabel("Working capacity Δq [mmol/g per cycle]")
    ax.set_title("Temperature-swing working capacity (adsorb 25 °C @ 420 ppm)")
    ax.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig2_working_capacity.png")


def fig_energy(cy: Cycle):
    hr = np.linspace(0, 0.8, 100)
    th, tot = [], []
    for h in hr:
        c = Cycle(**{**asdict(cy), "heat_recovery": h})
        e = regen_energy(c)
        th.append(e["thermal"])
        tot.append(e["total"])
    fig, ax = plt.subplots(figsize=(8, 5.5))
    ax.plot(hr * 100, th, lw=2.5, label="thermal")
    ax.plot(hr * 100, tot, lw=2.5, ls="--", label="thermal + fan electric")
    ax.axhline(regen_energy(cy)["total"], color=figstyle.DIM, lw=1, ls=":")
    ax.set_xlabel("Sensible-heat recovery [%]")
    ax.set_ylabel("Regeneration energy  [kWh per tCO₂]")
    ax.set_title("Energy per tonne vs heat recovery (Climeworks-style benchmark ~2000–2500 kWh_th/t)")
    ax.legend()
    ax.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig3_energy_per_tonne.png")


def fig_breakthrough(cy: Cycle):
    fig, ax = plt.subplots(figsize=(8, 5.5))
    for kldf, lab in [(0.001, "k=0.001 1/s"), (0.002, "k=0.002 1/s"), (0.005, "k=0.005 1/s")]:
        t, ratio, qf = breakthrough(cy, kldf=kldf)
        ax.plot(t, ratio, lw=2, label=f"{lab}")
    ax.set_xlabel("Time [h]")
    ax.set_ylabel("Outlet / inlet CO₂  [-]")
    ax.set_title("LDF breakthrough, 10 kg amine sorbent bed, 300 m³/h ambient air")
    ax.legend()
    ax.grid(alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig4_breakthrough.png")


def fig_cost_tornado(cy: Cycle):
    base = cost_per_tonne(cy)["total"]
    swings = {
        # The desorption pressure belongs at the top of this list, not absent
        # from it. Everything below moves the answer by tens of dollars; this
        # moves it by hundreds, and past about 15 kPa it removes the answer.
        "Desorption pressure (2–10 kPa)": ("P_des", 2000, 10000),
        "Cycles/day (3–10)": ("cycles_per_day", 3, 10),
        "Sorbent cost ($20–150/kg)": ("sorbent_cost", 20, 150),
        "Sorbent life (1–5 yr)": ("sorbent_life", 1, 5),
        "BoP capex ($1000–4000/tpy)": ("capex_per_tpy", 1000, 4000),
        "Desorb T (80–130 °C)": ("T_des", 353.15, 403.15),
        "Heat recovery (0–60%)": ("heat_recovery", 0.0, 0.6),
        "Fan energy (75–300 kWh/t)": ("fan_kwh_per_t", 75, 300),
        "Heat price ($0.01–0.04/kWh)": ("heat_price", 0.01, 0.04),
        "Elec price (4.5–9 ¢/kWh)": ("elec_price", 0.045, 0.09),
    }
    rows = []
    for label, (k, lo, hi) in swings.items():
        c_lo = cost_per_tonne(Cycle(**{**asdict(cy), k: lo}))["total"]
        c_hi = cost_per_tonne(Cycle(**{**asdict(cy), k: hi}))["total"]
        rows.append((label, c_lo, c_hi))
    rows.sort(key=lambda t: abs(t[2] - t[1]))
    fig, ax = plt.subplots(figsize=(9.5, 6))
    for i, (label, lo, hi) in enumerate(rows):
        ax.barh(i, hi - lo, left=lo, color="#4C72B0" if hi >= lo else "#DD8452", alpha=0.85)
        ax.text(min(lo, hi) - 15, i, label, ha="right", va="center", fontsize=9)
    ax.axvline(base, color="k", lw=1.5, label=f"baseline ${base:.0f}/t")
    ax.set_yticks([])
    ax.set_xlabel("Capture cost  [$/tCO₂]")
    ax.set_title("DAC cost sensitivity (one-at-a-time)")
    ax.legend(loc="lower right")
    ax.grid(axis="x", alpha=0.3)
    figstyle.finish(fig, f"{OUT}/fig5_cost_tornado.png")


def main():
    cy = Cycle()
    dq, q_ads, q_des = working_capacity(cy)
    e = regen_energy(cy)
    c = cost_per_tonne(cy)
    summary = {
        "q_ads_mmol/g": round(q_ads, 4), "q_des_mmol/g": round(q_des, 4),
        "working_capacity_mmol/g": round(dq, 4),
        "thermal_kWh/t": round(e["thermal"], 1), "electric_kWh/t": round(e["electric"], 1),
        "cost_sorbent_$/t": round(c["sorbent"], 1), "cost_capex_$/t": round(c["capex"], 1),
        "cost_fom_$/t": round(c["fom"], 1), "cost_energy_$/t": round(c["energy"], 1),
        "cost_total_$/t": round(c["total"], 1),
    }
    with open(f"{OUT}/summary.json", "w") as f:
        json.dump({"cycle": asdict(cy), "results": summary}, f, indent=2)
    with open(f"{OUT}/summary.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        [w.writerow([k, v]) for k, v in summary.items()]
    fig_isotherms()
    fig_working_capacity(cy)
    fig_energy(cy)
    fig_breakthrough(cy)
    fig_cost_tornado(cy)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
