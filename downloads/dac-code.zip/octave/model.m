% DAC Adsorption Cycle + TEA — MATLAB/GNU Octave port of ../model.py
% Run: octave model.m   (or open in MATLAB). Ported line-for-line from the
% verified Python reference; see README for provenance of all parameters.

1;

function q = iso_calf20(y, P, T)
  R = 8.314;
  c = y .* P ./ (R * T);
  b = 5.519e-7 * exp(35060 / (R * T));
  d = 5.187e-8 * exp(28950 / (R * T));
  q = 2.387 * b .* c ./ (1 + b .* c) + 3.271 * d .* c ./ (1 + d .* c);
end

function q = iso_lewatit(y, P, T)
  R = 8.314;
  p = y .* P;
  b = 9.0e-15 * exp(70000 / (R * T));
  q = 3.4 * b .* p ./ (1 + b .* p);
end

function [dq, qa, qd] = working_capacity(cy)
  if strcmp(cy.sorbent, "calf20")
    qa = iso_calf20(cy.y_ads, cy.P, cy.T_ads);  qd = iso_calf20(cy.y_des, cy.P_des, cy.T_des);
  else
    qa = iso_lewatit(cy.y_ads, cy.P, cy.T_ads); qd = iso_lewatit(cy.y_des, cy.P_des, cy.T_des);
  end
  dq = max(qa - qd, 0);
end

function e = regen_energy(cy)
  [dq, ~, ~] = working_capacity(cy);
  if dq <= 0, e = struct('thermal',Inf,'electric',Inf,'total',Inf,'dq',dq); return; end
  kgkg = dq * 0.044;
  sens = (cy.cp_sorbent + cy.steel_ratio * cy.cp_steel) * (cy.T_des - cy.T_ads) * (1 - cy.heat_recovery);
  th = (sens / kgkg + cy.dH_ads / 0.044) / 3.6;
  e = struct('thermal', th, 'electric', cy.fan_kwh_per_t, 'total', th + cy.fan_kwh_per_t, 'dq', dq);
end

function c = cost_per_tonne(cy)
  e = regen_energy(cy);
  if e.dq <= 0, c = struct('total', Inf); return; end
  crf = cy.r * (1 + cy.r)^cy.plant_life / ((1 + cy.r)^cy.plant_life - 1);
  kg_yr = e.dq * 0.044 * cy.cycles_per_day * 365;
  c.sorbent = cy.sorbent_cost / cy.sorbent_life / kg_yr * 1000;
  c.capex = cy.capex_per_tpy * crf;
  c.fom = cy.capex_per_tpy * cy.fom_frac;
  c.energy = e.thermal * cy.heat_price + e.electric * cy.elec_price;
  c.total = c.sorbent + c.capex + c.fom + c.energy;
end

cy = struct('T_ads',298.15,'T_des',373.15,'y_ads',420e-6,'y_des',1.0, ...
            'P',101325,'P_des',2000,'sorbent','lewatit', ...
            'cp_sorbent',1.0,'steel_ratio',1.0,'cp_steel',0.5,'dH_ads',70, ...
            'heat_recovery',0,'fan_kwh_per_t',150, ...
            'sorbent_cost',50,'sorbent_life',2,'capex_per_tpy',2000, ...
            'r',0.08,'plant_life',15,'elec_price',0.065,'heat_price',0.02, ...
            'fom_frac',0.04,'cycles_per_day',6);

[dq, qa, qd] = working_capacity(cy);
e = regen_energy(cy);  c = cost_per_tonne(cy);
printf("q_ads=%.4f q_des=%.4f dq=%.4f mmol/g\n", qa, qd, dq);
printf("thermal=%.1f kWh_th/t, electric=%.1f kWh_e/t\n", e.thermal, e.electric);
printf("cost total = %.1f $/t\n", c.total);
cy2 = cy; cy2.sorbent = "calf20"; cy2.dH_ads = 35;
printf("CALF-20 dq = %.4f mmol/g (fails for DAC)\n", working_capacity(cy2));

% isotherm comparison figure
ppm = logspace(log10(50), log10(2e5), 300);
f = figure("visible","off");
semilogx(ppm, iso_lewatit(ppm*1e-6,101325,298.15), "g-", "linewidth", 2); hold on;
semilogx(ppm, iso_lewatit(ppm*1e-6,101325,373.15), "g--", "linewidth", 2);
semilogx(ppm, iso_calf20(ppm*1e-6,101325,298.15), "b-", "linewidth", 2);
semilogx(ppm, iso_calf20(ppm*1e-6,101325,373.15), "b--", "linewidth", 2);
plot([420 420], ylim, "k:");
xlabel("CO2 partial pressure [ppm]"); ylabel("loading [mmol/g]");
legend("amine 25C","amine 100C","CALF-20 25C","CALF-20 100C","ambient","location","northwest");
title("Amine vs CALF-20 isotherms (Octave)");
print(f, fullfile(fileparts(mfilename("fullpath")), "fig1_isotherms_octave.png"), "-dpng", "-r140");
