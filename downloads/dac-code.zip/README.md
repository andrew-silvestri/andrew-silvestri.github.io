# 02 — DAC Fixed-Bed Adsorption Cycle + TEA

Temperature-swing adsorption cycle model + capture-cost model, grounded in the `dac/`
Green Fund project and the K-project sorbent work. Uses **your own CALF-20 dual-site
Langmuir parameters** from `Sorbent/CALF20 Calcs.xlsx` (Nguyen sheet) — validated: the
code reproduces that sheet's b@303 K = 0.611 m³/mol.

## Key finding (worth putting in the Green Fund narrative)

Run at DAC conditions, **CALF-20 has ~zero working capacity** (q_ads ≈ 0.031 mmol/g at
420 ppm; desorption backpressure beats any practical temperature swing). It's a flue-gas
physisorbent. This quantitatively justifies the K-project's choice of an amine
chemisorbent (Lewatit VP OC 1065-type), which the TEA runs on:

- Working capacity ≈ **1.06 mol/kg** per cycle (adsorb 25 °C/420 ppm; desorb 100 °C/2 kPa CO₂)
- Regeneration energy ≈ **1113 kWh_th + 150 kWh_e per tCO₂** (no heat recovery)
- Capture cost ≈ **$591/tCO₂** baseline — right in the published small-DAC range;
  tornado shows cycles/day, sorbent cost, and sorbent life dominate.

## Contents

| File | What it is |
|---|---|
| `model.py` | Verified reference: isotherms, working capacity, LDF breakthrough, energy, cost + tornado. |
| `dac_tea.xlsx` | Formula-driven workbook (`Inputs` → `Cycle` → `Cost`), recalculates on edit, verified error-free. |
| `julia/model.jl` + `Project.toml` | Faithful Julia port (untested in sandbox — Julia servers blocked; run locally). |
| `octave/model.m` | MATLAB/Octave port (same status). |
| `outputs/` | fig1 amine-vs-CALF-20 isotherms · fig2 working capacity vs T_des · fig3 energy vs heat recovery · fig4 breakthrough · fig5 cost tornado · summary.csv |

## Caveats / next steps

- Lewatit isotherm is a **single-site Langmuir calibrated to literature anchor points**
  (q≈1.4 mol/kg @ 42 Pa/25 °C, ΔH≈-70 kJ/mol). Replace with the full Toth fit (Bos et
  al. 2018) for publication-grade work.
- Humidity ignored (amine co-adsorption of H₂O raises real thermal duty ~2×) — flagged
  as the first refinement in the roadmap folder.
- LDF breakthrough is single-CSTR; extend to axial-dispersion PDE if you need profiles.
