# Bookshelf wallpaper

`bookshelf-app.html` is the whole application. Open it in any browser —
double-clicking the file works, no server, no internet. Drop in your
Goodreads export (Goodreads → My Books → Import/Export → Export), set your
screen size, and press Download.

Nothing leaves the page: the CSV is parsed in the browser, the shelf is
drawn in the browser, and the PNG is written by the browser. You can pull
the network cable first if you want to check.

To use the result as your wallpaper, right-click the PNG → Set as desktop
background, or on Windows:

    python set_wallpaper.py bookshelf-2560x1440.png
    python set_wallpaper.py --undo

`--undo` restores whatever wallpaper you had before. The script writes one
file (`undo_wallpaper.json`, next to itself) and nothing else. Removal is
deleting the folder.

What is real: titles, authors, page counts and years come from your export,
and a spine's width follows its page count. What is chosen: colours, cloth
and lettering are drawn deterministically from each title — the same book
always gets the same spine, but the spine is a design, not a photograph of
your edition.
