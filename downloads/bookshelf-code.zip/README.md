# Bookshelf wallpaper

`bookshelf-app.html` is the whole application. Open it in any browser —
double-clicking the file works, no server, no internet. Drop in your
Goodreads export (Goodreads → My Books → Import/Export → Export), set your
screen size, and press Download.

Nothing leaves the page: the CSV is parsed in the browser, the shelf is
drawn in the browser, and the PNG is written by the browser. You can pull
the network cable first if you want to check.

To use the result as your wallpaper, right-click the PNG → Set as desktop
background, or on Windows:

    python set_wallpaper.py bookshelf-2560x1440.png
    python set_wallpaper.py --undo

`--undo` restores whatever wallpaper you had before. The script writes one
file (`undo_wallpaper.json`, next to itself) and nothing else. Removal is
deleting the folder.

Two modes. Drawn spines (the default, fully offline): width from page
count, dress from era, deterministic per title. Real covers: tick the box
and the shelf becomes a wall of your books' actual covers, fetched from
Open Library by the ISBNs in your export — the page's one use of the
network — all brought to one matte finish so mixed scans sit together;
books with no cover on file are left off rather than faked. There is no
database of photographed book *spines* anywhere, at any scale, which is
why those are the two modes.
