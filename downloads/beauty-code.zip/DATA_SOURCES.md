# Data sources

Every input, what it is licensed under, and whether it travels in the code
archive. The rule: the archive ships every script and every join, and every
input whose licence allows it; the one input whose licence does not is
fetched by the reader with their own token.

## Used

**AVONET** (Tobias et al. 2022, *Ecology Letters* 25:581–597). Sheet
`AVONET1_BirdLife`: 11,009 bird species on the HBW-BirdLife v5 taxonomy with
body mass, range size, family and order. figshare 10.6084/m9.figshare.16586228,
file 34480856, SHA-256 pinned in `fetch_traits.py`. **CC BY 4.0.** Slimmed
to `data/avonet_slim.csv` (ships); the 21 MB workbook stays in `data/raw/`.

**Rated attractiveness** (Santangeli et al. 2023, *npj Biodiversity* 2:20,
"What drives our aesthetic attraction to birds?"). The data-and-scripts
deposit, figshare 10.6084/m9.figshare.22231504, file 42156828, SHA-256
pinned: per-species, per-sex mean attractiveness from the iratebirds
project, keyed to the same BirdLife v5 names. **CC BY 4.0.** Averaged over
sex rows into `data/attractiveness_slim.csv` (ships). The deposit also
carries a `redlistCategory` column, Red List version 2022-1; it is not
copied into the slim table (see *Not shipped*).

**Year of description.** The GBIF backbone name-match API
(`api.gbif.org/v1/species/match`), which returns the full scientific name
with authorship, e.g. "(Linnaeus, 1758)"; the Catalogue of Life ChecklistBank
API (dataset 3LR) when GBIF has no exact match. GBIF backbone **CC BY 4.0**,
COL **CC BY 4.0**. `data/description_years.csv` (ships).

**Public attention.** English Wikipedia monthly pageviews, January 2016 to
December 2025, all access, user agents only, via the Wikimedia Analytics
API, after resolving each scientific name to its article through the
MediaWiki query API (most species pages sit under the common name; a name
that resolves to a genus page or to nothing is recorded with no article).
**CC0 1.0** per the Wikimedia Analytics API access policy.
`data/wikipedia_views.csv` (ships).

**Research effort.** OpenAlex works, 2015–2024, whose title or abstract
contains the scientific name as a phrase (`title_and_abstract.search`,
`publication_year:2015-2024`), one metered filter call per species.
**CC0.** `data/openalex_counts.csv` (ships) with the run log
`data/openalex_run_log.txt` recording what each run cost. Fetched
September 2026; kept as the count the page used before D-32.

**Research effort by record type** (the page's response since 24 October
2026, D-32). The same query with `group_by=type`, one call per species for
the 9,113 modelled birds and the 1,556 others with a Red List row:
`data/openalex_types.csv` (ships, CC0), run log `data/types_run_log.txt`.
Research means the OpenAlex types listed in `record_types.py`; `dataset`
(GBIF occurrence downloads, almost all) and `reference-entry` (Red List
assessments and Birds of the World accounts) are not research.
`data/type_sources.csv` (ships, CC0) is the spot check behind that sentence:
the sources of each type for 40 sampled species (`fetch_type_sources.py`).

**Red List category** (IUCN Red List of Threatened Species, API v4,
`/taxa/class/Aves`, latest global assessment per species). Terms of use
v3.1 (June 2024): section 4 bars redistributing Red List data "in their
original format"; section 3 "places no restrictions on use of the IUCN Red
List Categories associated with each named taxonomic entity"; the token is
personal. The archive takes the cautious reading and ships no table that
pairs a species with its category, in a column or by the order of its
rows: `data/topic_counts.csv` is sorted by species name (it was written
non-Least-Concern species first). The exception:
`data/lc_matched.csv` lists the 1,000 Least Concern species the comparison
is matched against.
`data/iucn_aves.csv` and `data/raw/iucn_aves/` are **not in git and not in
the archive**. Cite as: IUCN 2026. The IUCN Red List of Threatened Species.
Version 2026-1. https://www.iucnredlist.org. IUCN asks that a copy of any
publication using the data be sent to them.

**Red List Table 1a** (summary statistics, version 2026-1, last updated 9
July 2026): described, evaluated and threatened species by major group.
Published as a PDF only; `fetch_groups.py` downloads it, pins its hash and
parses the 21 group rows into `data/iucn_table1a.csv`, a cited aggregate
that ships.

**Class-level papers.** OpenAlex works 2015–2024 whose title or abstract
names the class (search strings in `fetch_groups.py`), restricted to works
whose primary topic is in Agricultural and Biological Sciences or
Environmental Science. Five vertebrate classes only. `data/group_counts.csv`
(ships) with the exact URLs, split by record type since 24 October 2026; the
figure uses its `research` column.

## Looked up, not recomputed

Numbers quoted from publications and carried in the payload's `looked_up`
block with their source: Metrick & Weitzman 1996; Mammides 2019; Guénard et
al. 2025; Bland et al. 2015; Borgelt et al. 2022; Cowie, Bouchet & Fontaine
2022; and the threat-term results of the published species-level models
listed in `models.json`.

## Not shipped, and why

- `data/iucn_aves.csv`, `data/raw/iucn_aves/`: Red List terms (above). Its
  SHA-256 does ship, in `manifest.json`, so a reader who fetches the
  categories with their own token can check they have the table this page
  was built from: `python3 build_beauty.py --verify-categories`.
- `data/birds_joined.csv`: the modelled table with the category column.
  `data/birds_open.csv` is the same rows without it and ships.
- `data/raw/`: the AVONET workbook, the Santangeli zip and the Table 1a
  PDF, each re-downloaded and hash-checked by its fetch script. The
  Santangeli zip's 2022-1 Red List column is read from there only as the
  labelled fallback when no token is set, and never copied out.
- Figures: the site's assets, regenerated by `fig_beauty.py`.

## Considered and not used

- **Web of Science / Scopus**: the databases behind most of the published
  models; subscription only. OpenAlex is the reproducible substitute.
- **BirdLife checklist** (free download with Red List category): BirdLife
  is the Red List Authority for birds, so the column is Red List data and
  the same terms apply; its own terms page could not be read.
- **Berti et al. 2020** cross-taxon charisma compilation (GitHub, no
  licence file) and **Tam et al. 2022** mammal h-index table (GigaDB, CC0,
  with Red List categories): mammals are the natural extension, not built.
- **Species360 ZIMS**: member-only. No free species-level captive
  collection dataset exists; the zoo thread is literature only.
- **US FWS expenditure reports** FY1989–2022: per-species dollars, PDF
  only; a thirty-report extraction the page does not need.
