"""
Longevity Quotient — allometric model, taxonomic aggregation, and visualiser.

LQ is defined by analogy with the encephalisation quotient. A species'
observed lifespan is divided by the lifespan predicted for an animal of its
body mass, where the prediction comes from an ordinary least squares fit of

    log10(L) = a + b * log10(M)

L is maximum lifespan in years, M is adult body mass in grams. LQ = 1 means the
species lives exactly as long as its mass predicts.

Two baselines are computed.

  LQ_global  fit over every species in the table
  LQ_class   fit within the species' own group, where that group is large
             enough and the fit is sound

The group baseline is the more meaningful of the two. Birds live roughly twice
as long as mammals of equal mass, so a global fit charges every bird a bonus it
did not earn and every mammal a penalty. The global fit is kept because it is
what most casual presentations of this idea actually mean.

Colonial organisms are excluded from every fit. A 4,265-year black coral or an
11,000-year glass sponge is a colony age, not the lifespan of an individual;
including them would drag the invertebrate baseline into nonsense. They are
still carried in the data and shown in the visualiser, flagged as colonial.

Run:
    python3 build_lq.py

Writes outputs/ figures, outputs/lq_table.csv, outputs/group_summary.csv,
outputs/summary.json, and the self-contained longevity.html visualiser.
"""

import csv
import json
import math
import os

import matplotlib
import sys as _sys, os as _os; _sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
from sitefig import BG, INK, DIM, RULE, FAINT, ACC, COOL, MOSS, ROSE, SLATE, DISTRICT, SUPPLY, PSYCH, SUN, INSOL, GOLD, GREY, VIOLET, BLUE, GREEN, WARM, ARROW, ONE_WAY_COL, TWO_WAY_COL, NODE_COL, WARM2, KCOL, CYCLE, FS_2, FS_1, FS0, FS1, FS2, FONT, MONO, NOTES, PROSE, CARD, THUMB, fig_size, save, WIDE, PLOT, SQUARE, TALL, row_aspect, panel  # noqa: E402,F401
import sitefig  # noqa: E402

# An audit line carries the text of what it found, and this tree's figures are
# full of characters a Windows console's default code page cannot encode:
# U+2212 in heat's colourbar label, U+2192 in the allocation figure's. Printing
# one raises UnicodeEncodeError and the builder dies REPORTING a problem, after
# auditing some of its figures and before auditing the rest. The crash needs a
# finding to appear, so a clean tree hides it entirely.
# Measured 2026-09-12: heat/model.py reported 1 of 7 figures and crashed;
# climate-cost/build_allocation_figure.py still crashed on U+2192 after the
# heat fix. Same fix and same reason as tests/test_generators.py and
# build_layer_diagram.py.
import sys
if hasattr(sys, "stdout") and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402 - needed at module level so
                                  # _save() (defined before figures()) can
                                  # reach it; a local import inside figures()
                                  # alone left _save() with an undefined name.

HERE = os.path.dirname(os.path.abspath(__file__))
# The merged table is the model of record when it exists. The hand-checked
# seed is kept beside it and is still the highest-precedence source inside the
# merge, so this is a widening rather than a replacement - and if the merge has
# never been run, the seed alone still builds a working model.
_SEED = os.path.join(HERE, "data", "animals.csv")
_MERGED = os.path.join(HERE, "data", "animals_merged.csv")
DATA = _MERGED if os.path.exists(_MERGED) else _SEED
OUT = os.path.join(HERE, "outputs")

# The site palette. Black is not in it: these figures are read on a
# dark page, and a black rule or marker on that page is invisible.
MIN_CLASS_N = 6
MIN_CLASS_R2 = 0.15

# Regression weights by data grade.
#
# Maximum longevity is a record, not a rate, so it scales with how hard anyone
# looked. A well-banded species accumulates a long maximum; an obscure one keeps
# whatever its single recaptured individual gave. That noise should not set the
# baseline everything else is measured against.
#
# The first attempt at fixing this simply dropped the uncertain grades. It made
# things worse. AnAge's sample size tracks how charismatic and tractable an
# animal is rather than anything about ageing, so the dropped records skewed
# small-bodied and short-lived: at 3,334 species, filtering moved the mammal
# slope from 0.158 to 0.120 — away from the 0.15-0.20 the comparative
# literature reports — and shifted every class quotient below 1.0 at once.
# Deleting a third of a sample is a large intervention and it was not a random
# third.
#
# Three strategies are available, and which one is right is an empirical
# question rather than a matter of taste. It was settled by simulation: build a
# table with a known slope, mark a third of it grade C, depress those lifespans
# by the sampling artefact, and see which method recovers the slope that was put
# in. Repeated with grade-C records skewed small-bodied, large-bodied, and not
# skewed at all:
#
#     C records skew     unweighted   hard filter   weighted    truth
#     small-bodied            0.199         0.160      0.175    0.160
#     large-bodied            0.120         0.160      0.146    0.160
#     no mass skew            0.171         0.160      0.164    0.160
#
# The hard filter recovers the truth exactly in every case; weighting gets 3-9%
# of the way wrong; leaving the artefact in costs up to 25%. The reason is that
# grade C marks a *bias*, not merely noise: those lifespans are systematically
# depressed by low sampling effort. Down-weighting a bias still lets it through.
# Deleting it does not.
#
# So "filter" is the default. "weighted" and "none" are kept because the
# simulation encodes an assumption — that the grade-C depression is roughly
# multiplicative and independent of mass — and it is worth being able to check
# what happens if that assumption is wrong. Choose with --weights.
FIT_STRATEGY = "filter"          # filter | weighted | none
QUALITY_WEIGHT = {"A": 1.0, "B": 0.5, "C": 0.2}
DEFAULT_WEIGHT = 0.5
EXCLUDE_GRADES = {"C"}

RANKS = ["kingdom", "phylum", "class", "order", "family", "genus"]

# Classes are pooled into baseline groups. Fish classes are combined because
# separately they are too thin to fit; the many small invertebrate classes are
# combined for the same reason. The pooling is coarse and is declared as such
# on the page.
FISH = {"Actinopterygii", "Chondrichthyes", "Sarcopterygii",
        "Petromyzontida", "Myxini", "Dipnoi"}
VERT = {"Mammalia", "Aves", "Reptilia", "Amphibia"}

# Different sources use different, equally valid taxonomies. AnAge carries the
# older fish classes (Teleostei, Chondrostei, Holostei) that modern usage folds
# into Actinopterygii, and the older mammal orders (Soricomorpha,
# Erinaceomorpha) that fold into Eulipotyphla. Left alone these fragment the
# groups: a merged table splits into an "Actinopterygii" group of 32 and a
# "Teleostei" group of 329 that ought to be one, and — worse — every class this
# file does not recognise falls into the invertebrate baseline, so 348 fish end
# up being told what an invertebrate of their mass should live.
#
# Names are normalised on load, from whichever source. The canonical form is
# the modern one.
CLASS_SYNONYM = {
    "Teleostei": "Actinopterygii",
    "Chondrostei": "Actinopterygii",
    "Holostei": "Actinopterygii",
    "Actinopteri": "Actinopterygii",
    "Neopterygii": "Actinopterygii",
    "Coelacanthi": "Sarcopterygii",
    "Actinistia": "Sarcopterygii",
    "Elasmobranchii": "Chondrichthyes",
    "Holocephali": "Chondrichthyes",
    "Cephalaspidomorphi": "Petromyzontida",
    "Hyperoartia": "Petromyzontida",
    "Petromyzonti": "Petromyzontida",
    "Insecta ": "Insecta",
    "Secernentea": "Chromadorea",
    "Reptilia ": "Reptilia",
}

ORDER_SYNONYM = {
    "Soricomorpha": "Eulipotyphla",
    "Erinaceomorpha": "Eulipotyphla",
    "Insectivora": "Eulipotyphla",
    "Cetacea": "Artiodactyla",
    "Cetartiodactyla": "Artiodactyla",
    "Caudata": "Urodela",
    "Crocodylia": "Crocodilia",
    "Struthioniformes ": "Struthioniformes",
    "Scorpaeniformes": "Perciformes",
    "Perciformes ": "Perciformes",
    "Trachichthyiformes": "Beryciformes",
    "Cypriniformes ": "Cypriniformes",
    "Squamata ": "Squamata",
    "Rodentia ": "Rodentia",
}


def normalise(row):
    """Fold source-specific taxon names onto one canonical set."""
    changed = []
    c = row["class"].strip()
    if c in CLASS_SYNONYM:
        changed.append(("class", c, CLASS_SYNONYM[c]))
        row["class"] = CLASS_SYNONYM[c]
    o = row["order"].strip()
    if o in ORDER_SYNONYM:
        changed.append(("order", o, ORDER_SYNONYM[o]))
        row["order"] = ORDER_SYNONYM[o]
    return changed


def pool_of(row):
    cls = row["class"]
    if cls in VERT:
        return cls
    if cls in FISH:
        return "Pisces"
    return "Invertebrata"


def load(path=DATA):
    rows = []
    renames = {}
    unknown_classes = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            for rank, old, new in normalise(r):
                renames[(rank, old, new)] = renames.get((rank, old, new), 0) + 1
            wild = float(r["wild_yr"]) if r["wild_yr"].strip() else None
            cap = float(r["captive_yr"]) if r["captive_yr"].strip() else None
            unk = (float(r["unknown_yr"])
                   if (r.get("unknown_yr") or "").strip() else None)
            if wild is None and cap is None and unk is None:
                continue
            vals = [v for v in (wild, cap, unk) if v is not None]
            row = {
                "name": r["common_name"],
                "sci": r["scientific_name"],
                "mass_g": float(r["mass_g"]),
                "wild": wild,
                "captive": cap,
                # A maximum the source reports without saying where the animal
                # lived. Kept apart from wild and captive so the visualiser can
                # say so; it still counts in the average and the maximum.
                "unrecorded": unk,
                # The average is over whichever measurements exist. A species
                # never held in captivity is not penalised with a zero; its
                # average is its wild value.
                "average": sum(vals) / len(vals),
                "maximum": max(vals),
                "colonial": r.get("colonial", "no").strip().lower() == "yes",
                "quality": r["quality"],
                "note": r.get("note", ""),
            }
            for rk in RANKS:
                row[rk] = r[rk].strip()
            row["pool"] = pool_of(r)
            if row["pool"] == "Invertebrata" and row["phylum"] == "Chordata":
                unknown_classes[r["class"]] = \
                    unknown_classes.get(r["class"], 0) + 1
            rows.append(row)

    if renames:
        print("taxonomy normalised:")
        for (rank, old, new), n in sorted(renames.items(),
                                          key=lambda kv: -kv[1]):
            print(f"    {rank:6s} {old:22s} -> {new:18s} ({n} rows)")
        print()
    # A chordate landing in the invertebrate baseline means a class name this
    # file does not know. That silently fits vertebrates against an
    # invertebrate curve, so it is shouted about rather than logged.
    if unknown_classes:
        print("WARNING — chordate classes not recognised, so pooled as "
              "invertebrates:")
        for k, n in sorted(unknown_classes.items(), key=lambda kv: -kv[1]):
            print(f"    {k:24s} {n} species")
        print("    Add them to FISH or CLASS_SYNONYM in build_lq.py.\n")
    return rows


def weight_of(row):
    if FIT_STRATEGY != "weighted":
        return 1.0
    return QUALITY_WEIGHT.get(row.get("quality", ""), DEFAULT_WEIGHT)


def in_fit(row):
    """Whether a record contributes to the regressions at all."""
    if row["colonial"]:
        return False
    if FIT_STRATEGY == "filter" and row["quality"] in EXCLUDE_GRADES:
        return False
    return True


def ols_loglog(rows, life_key="maximum"):
    """Weighted fit of log10(L) = a + b*log10(M).

    Returns (a, b, r2, n_eff). n_eff is Kish's effective sample size,
    (sum w)^2 / sum w^2 — the number of equally-weighted records the weighted
    set is worth. It is the honest n to quote: 1,000 records at weight 0.2 do
    not carry the information of 1,000 records at weight 1.
    """
    xs = [math.log10(r["mass_g"]) for r in rows]
    ys = [math.log10(r[life_key]) for r in rows]
    ws = [weight_of(r) for r in rows]
    sw = sum(ws)
    if sw == 0:
        return float("nan"), float("nan"), float("nan"), 0
    n_eff = sw ** 2 / sum(w * w for w in ws)
    mx = sum(w * x for w, x in zip(ws, xs)) / sw
    my = sum(w * y for w, y in zip(ws, ys)) / sw
    sxx = sum(w * (x - mx) ** 2 for w, x in zip(ws, xs))
    sxy = sum(w * (x - mx) * (y - my) for w, x, y in zip(ws, xs, ys))
    if sxx == 0:
        return float("nan"), float("nan"), float("nan"), n_eff
    b = sxy / sxx
    a = my - b * mx
    ss_res = sum(w * (y - (a + b * x)) ** 2 for w, x, y in zip(ws, xs, ys))
    ss_tot = sum(w * (y - my) ** 2 for w, y in zip(ws, ys))
    r2 = 1 - ss_res / ss_tot if ss_tot else float("nan")
    return a, b, r2, n_eff


def predict(a, b, mass_g):
    return 10 ** (a + b * math.log10(mass_g))


def geomean(vals):
    vals = [v for v in vals if v and v > 0]
    if not vals:
        return None
    return math.exp(sum(math.log(v) for v in vals) / len(vals))


def median(vals):
    vals = sorted(v for v in vals if v is not None)
    if not vals:
        return None
    n = len(vals)
    return vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2


OUTLIER_SIGMA = 3.0

# Grade-B records demoted by name, for a reason recorded here, before the
# preliminary fit sees them. Same consequence as the outlier rule (grade C,
# note says why, nothing deleted). D-29 item 7: Amniote gives the toolache
# wallaby (Macropus greyi) a maximum of 13 months at
# 10 kg, which is the kind of unit or field error the rule exists to catch,
# and it sat 0.006 log units inside the rule's cut. No other source in the
# tree records a lifespan for it, so none replaces the figure.
DEMOTE_BY_NAME = {
    "Macropus greyi": "Amniote's 13 months for a 10 kg wallaby is very "
                      "likely a unit or field error; no other source here "
                      "records its lifespan",
    "Thryonomys gregorianus": "Amniote's 10 months for a 2.3 kg cane rat is "
                              "very likely the same kind of error, just inside "
                              "the outlier cut; no other source here records "
                              "its lifespan (D-92 b, 2026-11-10)",
}


def demote_outliers(rows):
    """Grade-B records more than OUTLIER_SIGMA residual standard deviations
    from a preliminary fit of their own pool are demoted to grade C.

    The bottom of the ranking used to be twenty-eight Amniote records with
    maximum lifespans of one to three months at body masses up to five
    kilograms - an Indian hare at one month and 2.2 kg. Those are unit or
    field errors in the compilation, not observations, and they were graded B
    by construction (every Amniote row is), so the grade-C filter that keeps
    thin records out of the regressions never saw them. They sat at the low
    end of every sort and were the whole "who does not" half of the published
    ranked figure.

    The rule is the ordinary one for a regression: a residual more than three
    standard deviations from the fit is not drawn from the same population as
    the fit. It is applied in both directions - a compilation figure ten times
    too long is no more trustworthy than one ten times too short - and only to
    grade B. Grade A records are hand-verified with a citation each and are
    exempt: Labord's chameleon at 0.13x and the ocean quahog at 47x are real,
    and the rule must not eat the results it exists to protect. The
    preliminary fit is on A and B non-colonial rows, per pool, with the global
    fit standing in for a pool too small or too weak to fit on its own (the
    same test the final fit applies). Nothing is deleted: a demoted record
    keeps its row, its grade becomes C, its note says why, and the visualiser
    shows it under "Include C" like every other uncertain record.
    """
    by_name = []
    for r in rows:
        why = DEMOTE_BY_NAME.get(r["sci"])
        if why and r["quality"] == "B":
            r["quality"] = "C"
            r["note"] = ((r["note"] + "; ") if r["note"] else "") + (
                "demoted to C: " + why)
            by_name.append(r["sci"])
    pre = [r for r in rows if in_fit(r)]
    ga, gb, _, _ = ols_loglog(pre)
    pools = {}
    for r in pre:
        pools.setdefault(r["pool"], []).append(r)
    fits = {}
    for pool, members in pools.items():
        if len(members) < MIN_CLASS_N:
            continue
        a, b, r2, _ = ols_loglog(members)
        if b > 0 and r2 >= MIN_CLASS_R2:
            fits[pool] = (a, b)
    sd, demoted = {}, {}
    for pool, members in pools.items():
        a, b = fits.get(pool, (ga, gb))
        res = [math.log10(r["maximum"]) - (a + b * math.log10(r["mass_g"]))
               for r in members]
        mean = sum(res) / len(res)
        sd[pool] = math.sqrt(sum((x - mean) ** 2 for x in res) / len(res))
        for r, x in zip(members, res):
            if r["quality"] == "B" and abs(x - mean) > OUTLIER_SIGMA * sd[pool]:
                r["quality"] = "C"
                r["note"] = ((r["note"] + "; ") if r["note"] else "") + (
                    f"demoted to C: {10 ** abs(x - mean):.0f}x "
                    f"{'below' if x < mean else 'above'} its group's fit, "
                    f"past {OUTLIER_SIGMA:g} sd")
                demoted[pool] = demoted.get(pool, 0) + 1
    return {"sigma": OUTLIER_SIGMA, "applies_to": "grade B, non-colonial",
            "demoted": sum(demoted.values()), "by_pool": demoted,
            "demoted_by_name": by_name,
            "residual_sd_log10": {k: round(v, 4) for k, v in sd.items()}}


def score(rows, fit_rows):
    """Fit the global and per-pool baselines on fit_rows and score every row
    against them. Shared by build() and effort_check(), so the sensitivity
    run is the page's own arithmetic and not a copy of it."""
    ga, gb, gr2, gn = ols_loglog(fit_rows)

    pools = {}
    for r in fit_rows:
        pools.setdefault(r["pool"], []).append(r)

    fits, rejected = {}, {}
    for pool, members in pools.items():
        if len(members) < MIN_CLASS_N:
            rejected[pool] = f"fewer than {MIN_CLASS_N} species"
            continue
        a, b, r2, n = ols_loglog(members)
        if b <= 0:
            rejected[pool] = f"fit slope not positive (b={b:.3f}, n_eff={n:.0f})"
        elif r2 < MIN_CLASS_R2:
            rejected[pool] = f"fit too weak (r2={r2:.3f}, n_eff={n:.0f})"
        else:
            fits[pool] = (a, b, r2, n)

    for r in rows:
        r["pred_global"] = predict(ga, gb, r["mass_g"])
        f = fits.get(r["pool"])
        r["pred_class"] = predict(f[0], f[1], r["mass_g"]) if f else None
        for metric in ("wild", "captive", "average", "maximum"):
            v = r[metric]
            r["lq_global_" + metric] = (v / r["pred_global"]) if v else None
            r["lq_class_" + metric] = (
                (v / r["pred_class"]) if (v and r["pred_class"]) else None)
    return (ga, gb, gr2, gn), fits, rejected


# D-28 item 1 (QA 2026-10-22, qa-audit/lq_rev_rerun.py, ported here). Amniote
# supplies a lifespan only for species AnAge lacks, the less-studied ones, and
# at equal mass within family those records sit x0.60 (mammals), x0.75
# (reptiles), x0.82 (birds) below AnAge's medium-sample records. On species
# both carry they agree, so the gap is study effort, not units. The page's
# figures keep the pooled baseline (D-28 option B); this run rescales every
# non-seed record to AnAge's medium-sample level and re-runs the page's own
# outlier rule, fits and ranking, so Limits can print both side by side.
# Seed rows are not adjusted: they were picked for being exceptional, so their
# offset is selection, not effort.
EFFORT_FE = "family"
EFFORT_REF = "anage_medium"


def effort_levels(rows):
    """Label each row by where its lifespan came from and, for AnAge, the
    sample size AnAge itself records."""
    # AnAge's sample-size band, derived from the raw zip by
    # data/anage_sample.py (the raw files are not in the archive, nor in the
    # tree copies tests/test_generators.py builds from).
    with open(os.path.join(HERE, "data", "anage_sample.csv"),
              encoding="utf-8") as fh:
        samp = {r["scientific_name"]: r["sample_size"]
                for r in csv.DictReader(fh)}
    with open(os.path.join(OUT, "provenance.csv"), encoding="utf-8") as fh:
        prov = {r["scientific_name"]: r["taken_from"]
                for r in csv.DictReader(fh)}
    for r in rows:
        src = prov.get(r["sci"], "seed")
        r["effort"] = ("anage_" + (samp.get(r["sci"]) or "medium")
                       if src == "anage" else src)


def effort_offsets(rows, fe=EFFORT_FE):
    """log10 offset of each effort level from the reference, within pool, with
    log mass and taxon (fe) fixed effects so composition is not read as
    effort."""
    import numpy as np
    pre = [r for r in rows if in_fit(r)]
    levels = sorted({r["effort"] for r in pre} - {EFFORT_REF})
    pools = {}
    for r in pre:
        pools.setdefault(r["pool"], []).append(r)
    off = {}
    for p, m in sorted(pools.items()):
        if len(m) < 50:
            continue
        taxa = sorted({r[fe] for r in m})
        lv = [l for l in levels if sum(r["effort"] == l for r in m) >= 10]
        X = np.array([[math.log10(r["mass_g"])] + [r["effort"] == l for l in lv]
                      + [r[fe] == t for t in taxa] for r in m], float)
        y = np.array([math.log10(r["maximum"]) for r in m])
        beta, *_ = np.linalg.lstsq(X, y, rcond=None)
        off[p] = {l: float(v) for l, v in zip(lv, beta[1:1 + len(lv)])}
    return off


def headline_figures(fits, rows, groups):
    """The figures the page names, from one scored run, so the pooled and the
    effort-corrected runs are read by the same code."""
    av, mm = fits["Aves"], fits["Mammalia"]
    by = {r["name"]: r for r in rows}
    orders = sorted((g for g in groups["order"]
                     if g["n"] >= 4 and g["geo_lq"]), key=lambda g: -g["geo_lq"])
    fams = sorted((g for g in groups["family"]
                   if g["n"] >= 10 and g["geo_lq"]), key=lambda g: -g["geo_lq"])
    return {
        "bird_mammal_1kg": 10 ** (av[0] + 3 * av[1]) / 10 ** (mm[0] + 3 * mm[1]),
        "mammal_1kg_yr": 10 ** (mm[0] + 3 * mm[1]),
        "mammal_b": mm[1],
        "species": {s: own_lq(by[s]) for s in
                    ("Human", "Brandt's bat", "Naked mole-rat",
                     "African bush elephant", "Giraffe") if s in by},
        "orders": [[g["group"], g["geo_lq"], g["n"], g["baseline"]]
                   for g in orders],
        "families": [[g["group"], g["geo_lq"], g["n"]] for g in fams],
    }


def effort_check(path=DATA):
    rows = load(path)
    effort_levels(rows)
    off = effort_offsets(rows)
    for r in rows:
        d = 0.0 if r["effort"] == "seed" else \
            off.get(r["pool"], {}).get(r["effort"], 0.0)
        k = 10 ** (-d)
        for f in ("wild", "captive", "unrecorded", "average", "maximum"):
            if r[f]:
                r[f] *= k
    demote_outliers(rows)
    fit_rows = [r for r in rows if in_fit(r)]
    _, fits, _ = score(rows, fit_rows)
    groups = rank_summary([r for r in rows if r["quality"] != "C"])
    share = {}
    for p in ("Mammalia", "Reptilia", "Aves"):
        m = [r for r in fit_rows if r["pool"] == p]
        share[p] = sum(r["effort"] == "amniote" for r in m) / len(m)
    # The cruder bound QA ran beside it (V2): drop every grade-B record of
    # unknown or thin effort (Amniote, PanTHERIA, AmphiBIO, AnAge tiny and
    # small) instead of correcting it. It shrinks the mammal fit to a quarter
    # and skews it, so it is a bound, not a better estimate.
    rows2 = load(path)
    effort_levels(rows2)
    for r in rows2:
        if r["quality"] == "B" and r["effort"] in THIN_EFFORT:
            r["quality"] = "C"
    demote_outliers(rows2)
    fit2 = [r for r in rows2 if in_fit(r)]
    _, fits2, _ = score(rows2, fit2)
    groups2 = rank_summary([r for r in rows2 if r["quality"] != "C"])
    dropped = headline_figures(fits2, rows2, groups2)
    dropped["n_mammals"] = sum(1 for r in fit2 if r["pool"] == "Mammalia")
    return {"fixed_effects": EFFORT_FE, "reference": EFFORT_REF,
            "offsets_log10": off, "amniote_share_of_fit": share,
            "corrected": headline_figures(fits, rows, groups),
            "dropped": dropped}


THIN_EFFORT = ("anage_tiny", "anage_small", "amniote", "pantheria", "amphibio")


def spearman(a, b):
    """Rank correlation of two {name: value} maps over their common names."""
    common = sorted(set(a) & set(b))
    def ranks(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        out = [0] * len(v)
        for k, i in enumerate(order):
            out[i] = k
        return out
    x = ranks([a[k] for k in common])
    y = ranks([b[k] for k in common])
    n = len(common)
    mx, my = sum(x) / n, sum(y) / n
    sxy = sum((p - mx) * (q - my) for p, q in zip(x, y))
    sxx = sum((p - mx) ** 2 for p in x)
    syy = sum((q - my) ** 2 for q in y)
    return sxy / math.sqrt(sxx * syy), n


def build(path=DATA):
    rows = load(path)
    outliers = demote_outliers(rows)
    fit_rows = [r for r in rows if in_fit(r)]
    grade_census = {}
    for r in rows:
        if not r["colonial"]:
            grade_census[r["quality"]] = grade_census.get(r["quality"], 0) + 1

    (ga, gb, gr2, gn), fits, rejected = score(rows, fit_rows)

    os.makedirs(OUT, exist_ok=True)

    # ---- species table --------------------------------------------------
    cols = (["name", "sci"] + RANKS +
            ["mass_g", "wild", "captive", "unrecorded", "average", "maximum",
             "colonial", "pred_global", "pred_class", "lq_global_maximum",
             "lq_class_maximum", "quality", "note"])
    with open(os.path.join(OUT, "lq_table.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(cols)
        for r in sorted(rows, key=lambda r: -(r["lq_class_maximum"] or 0)):
            # D-29 item 12: four decimals wrote the rotifer, nematode and
            # tardigrade as 0.0 g, so the fits could not be recomputed from
            # the download. Sub-gram masses keep six significant figures.
            w.writerow([float(f"{r[c]:.6g}") if c == "mass_g"
                        and isinstance(r.get(c), float) and abs(r[c]) < 1
                        else round(r[c], 4) if isinstance(r.get(c), float)
                        else r.get(c) for c in cols])

    # ---- group table ----------------------------------------------------
    # Ranked over A and B only, which is what the visualiser shows by default
    # and what the page quotes. Grade C is uncertain by definition, and since
    # the outlier rule it is also where a compilation figure the fit cannot
    # account for is parked; averaging it into a group statistic would put the
    # artefact back into the number the page is built to report.
    ranked_rows = [r for r in rows if r["quality"] != "C"]
    groups = rank_summary(ranked_rows)
    with open(os.path.join(OUT, "group_summary.csv"), "w", newline="",
              encoding="utf-8") as fh:
        w = csv.writer(fh, lineterminator="\n")
        w.writerow(["rank", "group", "n_species", "n_colonial",
                    "geomean_lq_class", "scored_against", "median_lifespan_yr",
                    "min_mass_g", "max_mass_g", "longest_lived_species",
                    "longest_lived_yr"])
        for rk in RANKS:
            for g in groups[rk]:
                w.writerow([rk, g["group"], g["n"], g["n_colonial"],
                            None if g["geo_lq"] is None
                            else round(g["geo_lq"], 4), g["baseline"],
                            round(g["med_life"], 3), g["min_mass"],
                            g["max_mass"], g["top_name"], g["top_life"]])

    summary = {
        "n_species": len(rows),
        "n_colonial_excluded_from_fits": sum(1 for r in rows if r["colonial"]),
        "grade_census": grade_census,
        "quality_weights": QUALITY_WEIGHT,
        "ranks": {rk: len({r[rk] for r in rows if r[rk]}) for rk in RANKS},
        "global_fit": {"a": ga, "b": gb, "r2": gr2, "n": gn},
        "class_fits": {k: {"a": v[0], "b": v[1], "r2": v[2], "n": v[3]}
                       for k, v in fits.items()},
        "rejected_fits": rejected,
        "outlier_rule": outliers,
        "origin_census": {
            k: sum(1 for r in rows if r[k]) for k in
            ("wild", "captive", "unrecorded")},
        "headline": headline_figures(fits, rows, groups),
    }
    ec = effort_check(path)
    po = {o[0]: o[1] for o in summary["headline"]["orders"]}
    co = {o[0]: o[1] for o in ec["corrected"]["orders"]}
    rho, n_common = spearman(po, co)
    top = lambda d: set(sorted(d, key=lambda k: -d[k])[:10])
    ec["order_rank_spearman"] = rho
    ec["orders_compared"] = n_common
    ec["top10_shared"] = len(top(po) & top(co))
    summary["effort_check"] = ec
    with open(os.path.join(OUT, "summary.json"), "w", encoding="utf-8", newline="\n") as fh:
        json.dump(summary, fh, indent=2)

    report(rows, summary, fits, rejected, groups)
    write_html(rows, summary)
    # THE AUDIT'S VERDICT IS THE RUN'S EXIT STATUS. Until now this builder
    # printed LAYOUT and exited 0, which is the shape heat/figstyle.py and
    # storage/figstyle.py had until 2026-09-12 - and the shape that let heat
    # report 1 of 7 figures and exit clean, because a traceback and a verdict
    # both exit non-zero and nobody was reading the output. Third builder,
    # same gap, same one-line fix (trap 26).
    PROBLEMS.clear()
    try:
        figures(rows, summary, fit_rows)
        figures(rows, summary, fit_rows, width=sitefig.PHONE,
                only="allometry")
        figures(rows, summary, fit_rows, width=sitefig.PHONE, only="ranked")
        figures(rows, summary, fit_rows, width=sitefig.PHONE, only="wild")
        figures(rows, summary, fit_rows, width=sitefig.PHONE, only="orders")
    except ImportError:
        print("\nmatplotlib not present; figures skipped "
              "(the visualiser does not need them)")
    else:
        print(f"  {len(PROBLEMS)} layout problem(s) in total")
        for p in PROBLEMS[:10]:
            print("    " + p)
        if PROBLEMS:
            raise SystemExit(1)
    return rows, summary


def own_lq(r, metric="maximum"):
    """The quotient against the species' own group, or against the global fit
    where its group's fit was rejected."""
    if r["pred_class"] is not None:
        return r["lq_class_" + metric]
    return r["lq_global_" + metric]


def rank_summary(rows):
    """Aggregate every taxonomic rank. Colonial organisms are counted but
    kept out of the quotient statistics."""
    out = {}
    for rk in RANKS:
        buckets = {}
        for r in rows:
            key = r[rk]
            if key:
                buckets.setdefault(key, []).append(r)
        groups = []
        for key, members in buckets.items():
            solo = [m for m in members if not m["colonial"]]
            top = max(members, key=lambda m: m["maximum"])
            # D-28 item 2: a pool whose own fit is rejected (amphibians) falls
            # back to the global baseline, as the page says. Until 2026-10-24
            # its members carried no own-group quotient here, so Anura and
            # Urodela dropped out of every group ranking while the page and
            # the app (predOf = pc || pg) both applied the fallback.
            own = [own_lq(m) for m in solo]
            fell = sum(1 for m in solo if m["pred_class"] is None)
            groups.append({
                "group": key,
                "n": len(members),
                "n_colonial": len(members) - len(solo),
                "geo_lq": geomean(own),
                "baseline": ("global" if solo and fell == len(solo) else
                             "mixed" if fell else "own"),
                "med_life": median([m["maximum"] for m in members]),
                "min_mass": min(m["mass_g"] for m in members),
                "max_mass": max(m["mass_g"] for m in members),
                "top_name": top["name"],
                "top_life": top["maximum"],
            })
        groups.sort(key=lambda g: -(g["geo_lq"] or 0))
        out[rk] = groups
    return out


def report(rows, summary, fits, rejected, groups):
    print(f"{len(rows)} species  "
          + "  ".join(f"{summary['ranks'][r]} {r}" for r in RANKS))
    gc = summary["grade_census"]
    print(f"{summary['n_colonial_excluded_from_fits']} colonial organisms "
          f"excluded from every fit.")
    o = summary["outlier_rule"]
    print(f"{o['demoted']} grade-B records demoted to C for sitting more than "
          f"{o['sigma']:g} sd from their group's fit: "
          + "  ".join(f"{k} {v}" for k, v in sorted(o["by_pool"].items())))
    oc = summary["origin_census"]
    print(f"lifespan origin: wild {oc['wild']}  captive {oc['captive']}  "
          f"unrecorded {oc['unrecorded']}")
    print(f"fit strategy: {FIT_STRATEGY}  "
          + {"filter": "(grade C dropped from the regressions)",
             "weighted": "(grade C kept, down-weighted)",
             "none": "(every record counts equally)"}[FIT_STRATEGY])
    print("    grades present — " + "  ".join(
        f"{g}: {gc[g]}" for g in sorted(gc)))
    if FIT_STRATEGY == "weighted":
        print("    n below is Kish effective sample size, not a row count")
    print()
    g = summary["global_fit"]
    print(f"global : log10 L = {g['a']:.3f} + {g['b']:.3f} log10 M   "
          f"(r2={g['r2']:.3f}, n_eff={g['n']:.0f})")
    for k in sorted(fits):
        a, b, r2, n = fits[k]
        print(f"{k:14s}: log10 L = {a:.3f} + {b:.3f} log10 M   "
              f"(r2={r2:.3f}, n_eff={n:.0f})")
    for k in sorted(rejected):
        print(f"{k:14s}: no group fit — {rejected[k]}; using global baseline")

    print("\nClasses ranked by geometric mean quotient (n >= 3):")
    for gr in [g for g in groups["class"] if g["n"] >= 3 and g["geo_lq"]][:10]:
        print(f"  {gr['group']:18s} n={gr['n']:3d}  "
              f"LQ {gr['geo_lq']:5.2f}  median life "
              f"{gr['med_life']:6.1f} yr")
    print("\nOrders with the highest quotient (n >= 4):")
    for gr in [g for g in groups["order"] if g["n"] >= 4 and g["geo_lq"]][:6]:
        print(f"  {gr['group']:18s} n={gr['n']:3d}  LQ {gr['geo_lq']:5.2f}"
              f"   longest: {gr['top_name']} ({gr['top_life']:g} yr)")
    print("Orders with the lowest quotient (n >= 4):")
    low = [g for g in groups["order"] if g["n"] >= 4 and g["geo_lq"]][-4:]
    for gr in reversed(low):
        print(f"  {gr['group']:18s} n={gr['n']:3d}  LQ {gr['geo_lq']:5.2f}"
              f"   longest: {gr['top_name']} ({gr['top_life']:g} yr)")
    top = sorted([r for r in rows if r["lq_class_maximum"] and
                  not r["colonial"] and r["quality"] != "C"],
                 key=lambda r: -r["lq_class_maximum"])[:8]
    print("\nHighest LQ against own group:")
    for r in top:
        print(f"  {r['name']:32s} {r['lq_class_maximum']:6.2f}")
    bot = sorted([r for r in rows if r["lq_class_maximum"]
                  and r["quality"] != "C"],
                 key=lambda r: r["lq_class_maximum"])[:5]
    print("Lowest LQ against own group:")
    for r in bot:
        print(f"  {r['name']:32s} {r['lq_class_maximum']:6.2f}")


# ------------------------------------------------------------------ figures

# Every problem every audit found this run, as "figure.png: what".
PROBLEMS = []


def _save(fig, name, want=True):
    """Save a figure only after checking that nothing on it collides.

    `want=False` draws and audits but writes nothing: it is how figures() draws
    one narrow render without leaving three more on disk that no page reads.
    A generator that writes something nothing reads is how one goes stale.

    These four figures used to call savefig directly, so they were the one
    set on the site that was never checked; the audit already existed next
    door in fig_lq_explained.py and simply was not wired to them.
    """
    if not want:
        # Not written, so not audited and not reported. Auditing a figure
        # this call is about to discard printed LAYOUT lines naming a file
        # that never reaches disk, which reads as a failure and is not one.
        plt.close(fig)
        return []
    from fig_lq_explained import audit
    bad = audit(fig)
    if bad:
        print(f"  LAYOUT  {name}")
        for b in bad[:5]:
            print(f"            {b}")
    PROBLEMS.extend(f"{name}: {b}" for b in bad)
    if want:
        sitefig.save(fig, os.path.join(OUT, name), close=False)
    plt.close(fig)
    return bad


def figures(rows, summary, fit_rows, width=NOTES, only=None):
    """Draw the four figures. `only` draws one of them and returns.

    `only` names the figure to WRITE; the others are still drawn and audited
    and then discarded, so a narrow pass leaves no file on disk that no page
    reads. It is a parameter rather than an extracted function because the four
    figures share one rcParams block and one colour table, and splitting those
    out is a bigger change than this one needs to be.

    IT IS NOT HERE FOR SPEED, AND THE COMMENT THAT SAID SO WAS WRONG. When
    `only` was added on 2026-09-13 this docstring claimed a second full pass
    would be "minutes of work thrown away", because this builder re-fits eight
    thousand species. Measured the next day: a complete run is 4.8 SECONDS. The
    claim was written from the shape of the code rather than from a clock, which
    is the estimate-instead-of-measure habit in its cheapest form - nothing was
    lost by it, and it was still an unmeasured number stated as a reason.
    """

    # These four figures already carried INK/DIM and the real per-class site
    # colors (see `colors` below), but never actually switched the canvas to
    # the site's dark background - the choice of colors implies the intent,
    # the rcParams to realize it were simply never set, so every one of them
    # rendered as a light matplotlib-default figure next to the rest of the
    # (dark) site.
    sitefig.style(); plt.rcParams.update({
        # The page is set in the site's own sans stack; the figures were left
        # on matplotlib's DejaVu Sans, so every label under every chart was in
        # a different typeface from the caption beside it. Named as a
        # sans-serif list so a reader running this on a machine without Segoe
        # UI still gets a sane fallback rather than boxes.
        "font.family": FONT,
        "figure.facecolor": BG, "axes.facecolor": BG, "savefig.facecolor": BG,
        "text.color": INK, "axes.labelcolor": INK, "axes.titlecolor": INK,
        "xtick.color": DIM, "ytick.color": DIM,
        "axes.edgecolor": RULE, "grid.color": RULE,
        "axes.spines.top": False, "axes.spines.right": False,
    })

    # sitefig.wrap_label at the measured 26 for horizontal labels; see its
    # docstring for what 26 is and for the trigger that retires the count.
    W = sitefig.wrap_label if width != NOTES else (lambda s: s)
    ga, gb = summary["global_fit"]["a"], summary["global_fit"]["b"]
    # Amphibia was #a98fd8 and Pisces #6f7fd8, which put three violets
    # (with Mammalia's #8b7ff2) in one legend; at scatter-dot size they were
    # the same color. Both moved to hues already in the site's cycle.
    colors = {"Mammalia": ACC, "Aves": COOL, "Reptilia": MOSS,
              "Amphibia": GOLD, "Pisces": GREY,
              "Invertebrata": ROSE}

    fig, ax = plt.subplots(figsize=fig_size(width, PLOT))
    for pool in sorted({r["pool"] for r in rows}):
        sel = [r for r in rows if r["pool"] == pool and not r["colonial"]]
        ax.scatter([r["mass_g"] for r in sel], [r["maximum"] for r in sel],
                   s=20, alpha=.8, label=pool, color=colors.get(pool, "#888"),
                   edgecolor="none")
    col = [r for r in rows if r["colonial"]]
    if col:
        ax.scatter([r["mass_g"] for r in col], [r["maximum"] for r in col],
                   s=42, facecolor="none", edgecolor=ROSE, lw=1.3,
                   label="colonial (excluded from fit)")
    xs = [10 ** (i / 4) for i in range(-28, 34)]
    ax.plot(xs, [predict(ga, gb, x) for x in xs], "--", color=INK, lw=1.2,
            label=f"global fit, slope {gb:.3f}")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlabel("adult body mass (g)")
    ax.set_ylabel("maximum lifespan (years)")
    # The legend goes outside the axes. Inside, the bottom right corner is
    # occupied by the densest part of the cloud, so the key covered the data.
    ax.legend(fontsize=FS_2, frameon=False, loc="upper left",
              bbox_to_anchor=(1.01, 1.0), borderaxespad=0)
    ax.grid(alpha=.18, which="both")
    fig.tight_layout()

    # Species labels are placed last, against the settled axes, and any label
    # that would land on one already written is dropped rather than stacked.
    # Writing them all at a fixed offset produced "TurquoiseLabord's
    # chameleon" where two species sat close together, and pushed the label
    # of the heaviest animal off the right edge.
    named = ("Greenland shark", "Ocean quahog", "Bowhead whale",
             "Naked mole-rat", "Brandt's bat", "Glass sponge",
             "Giant Pacific octopus", "Common shrew", "Turquoise killifish",
             "Black coral", "Labord's chameleon")
    fig.canvas.draw()
    ren = fig.canvas.get_renderer()
    taken = []
    x0ax, x1ax = ax.get_window_extent(renderer=ren).x0, \
        ax.get_window_extent(renderer=ren).x1
    for r in sorted([r for r in rows if r["name"] in named],
                    key=lambda r: -r["maximum"]):
        px, py = ax.transData.transform((r["mass_g"], r["maximum"]))
        right = px > (x0ax + x1ax) / 2          # label inward near the edge
        ha, dx = ("right", -5) if right else ("left", 5)
        # Eight thousand dots sit behind these names. Without a plate behind
        # the text, the labels over the dense middle of the cloud were
        # unreadable; the box is the panel color, so it reads as a gap.
        t = ax.annotate(r["name"], (r["mass_g"], r["maximum"]), fontsize=FS_2,
                        xytext=(dx, 4), textcoords="offset points", ha=ha,
                        bbox=dict(boxstyle="round,pad=0.16", facecolor=BG,
                                  edgecolor="none"))
        bb = t.get_window_extent(renderer=ren)
        if any(bb.overlaps(o) for o in taken) or bb.x0 < x0ax or bb.x1 > x1ax:
            t.remove()
            continue
        taken.append(bb)
    # THE SECOND RENDER IS A SECOND FIGURE, NOT A SCALED ONE. A 714px
    # figure served into a 350px column shows its 12pt floor at 5.9px, and
    # dpi cannot change that: what a reader sees is point size times served
    # width over authored width (fig_floor.py). <picture> picks between
    # them, and tests/test_fig_floor.py measures the result at the width
    # the page actually serves.
    _save(fig, "fig1_allometry.png" if width == NOTES
               else "fig1_allometry-phone.png",
          want=only in (None, "allometry"))

    # Own-group quotient, with the global fallback for amphibians (D-28
    # item 2): on the class quotient alone the olm, fifth in the page's own
    # list, was missing from the figure beside it (claims check, R5).
    ranked = sorted([r for r in rows if own_lq(r)
                     and not r["colonial"] and r["quality"] != "C"],
                    key=lambda r: own_lq(r))
    sel = ranked[:12] + ranked[-18:]
    # Bars from zero on a linear axis, with the ocean quahog out at 48, drew
    # the twelve species below parity as nothing at all - the entire "and who
    # does not" half of the title was twelve blank rows. A quotient is a
    # ratio, so the axis is logarithmic and every bar runs from parity rather
    # than from zero: short to the left is half as long as predicted, short to
    # the right is twice.
    fig, ax = plt.subplots(figsize=fig_size(width, row_aspect(30, display_px=width)))
    ys = range(len(sel))
    ax.hlines(list(ys), 1, [own_lq(r) for r in sel],
              color=[colors.get(r["pool"], "#888") for r in sel], lw=3.4)
    ax.scatter([own_lq(r) for r in sel], list(ys), s=26, zorder=3,
               color=[colors.get(r["pool"], "#888") for r in sel])
    ax.set_yticks(list(ys))
    ax.set_yticklabels([r["name"] for r in sel])
    ax.set_xscale("log")
    ax.axvline(1, color=DIM, lw=1.2, ls="--")
    ax.set_xlabel(W("longevity quotient (observed ÷ predicted for its group, "
                    "log scale)"))
    ax.tick_params(labelsize=FS_2)
    ax.grid(axis="x", alpha=.18, which="both")
    ax.set_axisbelow(True)
    fig.tight_layout()
    _save(fig, "fig2_lq_ranked.png" if width == NOTES
               else "fig2_lq_ranked-phone.png",
          want=only in (None, "ranked"))

    pair = [r for r in rows if r["wild"] and r["captive"]]
    pair.sort(key=lambda r: r["captive"] / r["wild"])
    sel = pair[:10] + pair[-16:]
    # At 350 the 714's PLOT aspect gave 26 rows about 7px each and every
    # name sat on its neighbour (26 audit problems); the narrow render sizes
    # by rows, as fig2 does. The 714 keeps PLOT and its bytes.
    fig, ax = plt.subplots(figsize=fig_size(
        width, PLOT if width == NOTES
        else row_aspect(len(sel), display_px=width)))
    for i, r in enumerate(sel):
        ax.plot([r["wild"], r["captive"]], [i, i], color="#bbb", lw=1.4,
                zorder=1)
    ax.scatter([r["wild"] for r in sel], range(len(sel)), s=32,
               color=MOSS, label="wild", zorder=2)
    ax.scatter([r["captive"] for r in sel], range(len(sel)), s=32,
               color=ACC, label="captive", zorder=2)
    ax.set_yticks(range(len(sel)))
    ax.set_yticklabels([r["name"] for r in sel], fontsize=FS_2)
    ax.set_xscale("log")
    ax.set_xlabel(W("maximum lifespan (years, log scale)"))
    ax.legend(fontsize=FS_2, frameon=False)
    ax.grid(axis="x", alpha=.18, which="both")
    fig.tight_layout()
    _save(fig, "fig3_wild_vs_captive.png" if width == NOTES
               else "fig3_wild_vs_captive-phone.png",
          want=only in (None, "wild"))

    # order-level comparison, A and B only (see build())
    groups = rank_summary([r for r in rows if r["quality"] != "C"])
    ords = [g for g in groups["order"] if g["n"] >= 4 and g["geo_lq"]]
    ords.sort(key=lambda g: g["geo_lq"])
    # One column of every qualifying order made a figure 1350x5265 px - a
    # four-to-one sliver that the page had to scale to a thumbnail before it
    # fitted, at which point no label could be read. Same orders, two columns,
    # best at the top left: an aspect a page can actually show.
    ords.sort(key=lambda g: -g["geo_lq"])
    half = (len(ords) + 1) // 2
    cols = [ords[:half], ords[half:]]
    hi = max(g["geo_lq"] for g in ords) * 1.06
    fig, axes = plt.subplots(1, 2, figsize=(width / 72, max(4.5, 0.235 * half + 1.6)))
    for ax, part in zip(axes, cols):
        ys = range(len(part))
        # D-28 item 2: an order scored against the global fit (amphibians,
        # whose own fit is rejected) is drawn apart, because the all-animal
        # line is not the scale the other bars are on.
        ax.barh(list(ys), [g["geo_lq"] for g in part],
                color=[SLATE if g["baseline"] == "global" else ACC
                       for g in part], height=.72)
        ax.set_yticks(list(ys))
        ax.set_yticklabels([g["group"] + (" *" if g["baseline"] == "global"
                                          else "") for g in part],
                           fontsize=FS_2)
        ax.invert_yaxis()
        ax.set_xlim(0, hi)
        ax.axvline(1, color=DIM, lw=1.2, ls="--")
        if width == NOTES:
            ax.set_xlabel("geometric mean longevity quotient")
        ax.grid(axis="x", alpha=.18)
        ax.set_axisbelow(True)
        ax.tick_params(axis="x", labelsize=FS_2)
    if width == NOTES:
        fig.tight_layout(rect=(0, 0, 1, .975))
    else:
        # At 350 each ~160px panel cannot hold its own copy of the label
        # (off canvas, and the two copies overlap), which is what fired the
        # wrap trigger in 1c0ec82. The two panels share one axis, so the
        # narrow render says it once, under both, where it fits unwrapped:
        # no third wrap count.
        fig.tight_layout(rect=(0, .05, 1, .975))
        fig.text(.5, .008, "geometric mean longevity quotient", ha="center",
                 va="bottom", fontsize=plt.rcParams["axes.labelsize"])
    _save(fig, "fig4_orders.png" if width == NOTES
               else "fig4_orders-phone.png",
          want=only in (None, "orders"))
    print("\nfigures written to outputs/")


# --------------------------------------------------------------------- html
def write_html(rows, summary):
    """Write the visualiser.

    The payload is column-oriented and dictionary-encoded, which is not
    premature: a row-oriented dump of this table spends 427 kB repeating the
    word "Mammalia" and 2,921 genus names, because taxonomy is exactly the kind
    of field that has a few hundred distinct values and eight thousand
    occurrences. Encoding each rank once and storing indices takes the page
    from 2.4 MB to well under a megabyte, and the browser parses a flat array
    of integers far faster than it parses eight thousand object literals.

    It is also handed over as a JSON string for JSON.parse rather than as a
    JavaScript object literal. The literal has to go through the full
    expression parser; JSON.parse has a dedicated one, and on a payload this
    size the difference is the gap between a page that appears and a page that
    hesitates.
    """
    # dictionary-encoded fields: a few hundred distinct values, thousands of uses
    DICT = ["c", "q", "note"] + [rk[:2] for rk in RANKS]
    NUM = ["m", "w", "p", "u", "a", "mx", "pg", "pc", "col"]
    COLS = ["n", "s"] + NUM + DICT

    tables = {k: {} for k in DICT}

    def idx(field, value):
        d = tables[field]
        v = value or ""
        if v not in d:
            d[v] = len(d)
        return d[v]

    cols = {c: [] for c in COLS}
    for r in rows:
        cols["n"].append(r["name"])
        cols["s"].append(r["sci"])
        cols["m"].append(r["mass_g"])
        cols["w"].append(r["wild"])
        cols["p"].append(r["captive"])
        cols["u"].append(r["unrecorded"])
        cols["a"].append(round(r["average"], 3))
        cols["mx"].append(r["maximum"])
        cols["pg"].append(round(r["pred_global"], 4))
        cols["pc"].append(round(r["pred_class"], 4) if r["pred_class"]
                          else None)
        cols["col"].append(1 if r["colonial"] else 0)
        cols["c"].append(idx("c", r["pool"]))
        cols["q"].append(idx("q", r["quality"]))
        cols["note"].append(idx("note", r.get("note", "")))
        for rk in RANKS:
            cols[rk[:2]].append(idx(rk[:2], r[rk]))

    payload = {
        "n": len(rows),
        "cols": cols,
        "dict": {k: [s for s, _ in sorted(v.items(), key=lambda kv: kv[1])]
                 for k, v in tables.items()},
        "dictFields": DICT,
    }

    tpl = open(os.path.join(HERE, "template.html"), encoding="utf-8").read()
    blob = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    html = tpl.replace("/*DATA*/", json.dumps(blob, ensure_ascii=False))
    html = html.replace("/*FITS*/", json.dumps(summary, ensure_ascii=False,
                                               separators=(",", ":")))
    path = os.path.join(HERE, "longevity.html")
    # newline="\n": site/.gitattributes declares eol=lf and Python text mode on Windows writes CRLF.
    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(html)
    print(f"\nvisualiser written: {path} "
          f"({os.path.getsize(path)/1024:.0f} kB, self-contained)")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("--weights", default=FIT_STRATEGY,
                    choices=["filter", "weighted", "none"],
                    help="how to handle low-confidence records: drop them from "
                         "the fits (default, best in simulation), down-weight "
                         "them, or treat every record equally")
    ap.add_argument("--data", default=DATA,
                    help="species table to build from "
                         "(default data/animals.csv; pass "
                         "data/animals_merged.csv after a merge)")
    args = ap.parse_args()
    FIT_STRATEGY = args.weights
    build(args.data)
