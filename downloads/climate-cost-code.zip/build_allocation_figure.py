"""
The allocation figure on climate-cost.html, drawn from the model of record.

Two panels, one axis. Above: a kilogram of hard cheese, France to New York,
under every published way of splitting a dairy cow between her milk and her
meat. Below: a pair of leather shoes, Italy to New York, under every published
way of splitting a beef animal between its meat and its hide. Same model, same
engine, same scale; the only thing that changes between bars is the one number
on the contested edge.

The point of the pair: for the cheese the split *is* the answer (about 93% of
the kilogram sits on the herd stages; the figure prints the live value), for
the shoe it barely moves it (the hide is 9% of the pair). This replaces a video that claimed the shoe "nearly
tripled" under mass allocation. It did not; the video scaled the whole shoe by
the ratio of two factors, and no script in the repository could regenerate it.
That is why this file exists: the figure is built here, from `lca.py`, with
every alternative factor written next to the publication it comes from, and
the page names this script in its provenance.

The one framing of "how much it moves", used in the figure and on the page:

    spread = highest total / lowest total across the published bases shown.

Not adjacent bases, not economic-vs-physical only, not the default against
anything. Ambiguity about which two numbers a multiple refers to is exactly
what produced 11.65.

Run:  python3 build_allocation_figure.py          # writes site/assets/
      python3 build_allocation_figure.py --check  # numbers only, no file
"""
import os
import textwrap
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "data"))

import matplotlib                       # noqa: E402
# An audit line carries the text of what it found, and this tree's figures are
# full of characters a Windows console's default code page cannot encode:
# U+2212 in heat's colourbar label, U+2192 in the allocation figure's. Printing
# one raises UnicodeEncodeError and the builder dies REPORTING a problem, after
# auditing some of its figures and before auditing the rest. The crash needs a
# finding to appear, so a clean tree hides it entirely.
# Measured 2026-09-12: heat/model.py reported 1 of 7 figures and crashed;
# climate-cost/build_allocation_figure.py still crashed on U+2192 after the
# heat fix. Same fix and same reason as tests/test_generators.py and
# build_layer_diagram.py.
if hasattr(sys, "stdout") and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

matplotlib.use("Agg")
import matplotlib.pyplot as plt         # noqa: E402

import sitefig                          # noqa: E402
from sitefig import (MONO, BG, INK, DIM, RULE, FAINT, ACC, MOSS, COOL, SLATE,  # noqa: E402,F401
                     FS_2, FS_1, FS0, NOTES, PHONE, fig_size, save)
from fig_floor import floor_problems    # noqa: E402
import lca                              # noqa: E402  the model of record; imported, not edited
from processes import PRODUCTS          # noqa: E402

OUT = os.path.join(ROOT, "site", "assets", "climate_allocation_bases.png")
OUT_PHONE = os.path.join(ROOT, "site", "assets", "climate_allocation_bases-phone.png")

# ---------------------------------------------------------------- bases ----
# Every factor here is quoted from a named publication. The one marked
# `default` is the value shipped in data/processes.py and must reproduce the
# published table exactly; the script refuses to draw if it does not.
#
# Cheese: Flysjo, Cederberg, Henriksson & Ledgard 2011, Int J Life Cycle
# Assess 16:420-430, Table 1 ("How does co-product handling affect the carbon
# footprint of milk?"), and IDF Bulletin 479/2015 pp. 35-36. The herd stages -
# enteric, feed, manure, milking - all carry the milk share; they move
# together because they are one decision.
CHEESE = dict(
    item="cheese", stages=("enteric", "feed", "manure", "dairy"),
    label="cheese, hard · 1 kg · France → New York\nthe cow split between milk and meat",
    bases=[
        ("system expansion, low",   0.63, "Flysjö 2011: 63–76%", False),
        ("system expansion, high",  0.76, "Flysjö 2011",             False),
        ("physical, Swedish milk",  0.85, "Flysjö 2011, Sweden; IDF 2010 method", False),
        ("physical, IDF typical herd", 0.88, "IDF Bulletin 479 (2015) p. 35, BMR 0.02", True),
        ("economic",                0.92, "Flysjö 2011, New Zealand", False),
        ("protein",                 0.93, "Flysjö 2011, Sweden",      False),
        ("mass",                    0.98, "Flysjö 2011",              False),
        # Not an allocation basis: drawn grey for scale and left out of the
        # spread (D-27 item 5; until 2026-10-24 it set the spread, x1.54).
        ("none: milk carries the cow", 1.00, "reference", False),
    ])

# Shoes: Lunesu, Correddu, Carta, Sechi, Farina & Pulina 2025, Animals
# 15(24):3546 ("Attributing Farm-to-Slaughter Emissions to Hides"): economic
# allocation "averaging 2.68% for 2023"; physical allocation "an average of
# 5.9% of live weight", range 4.2% (cull dairy cows) to 6.9% (semi-heavy young
# bulls). The model's own 2.2% is an assumption in the economic range and is
# drawn as the default; it is not a published value and is labelled so.
SHOES = dict(
    item="leather_shoes", stages=("hide",),
    label="shoes, leather · 1 pair · Italy → New York\nthe animal split between meat and hide",
    bases=[
        ("economic, model default", 0.022, "assumed", True),
        ("economic, 2023 mean",     0.027, "Lunesu et al. 2025",      False),
        ("physical, live-weight mean", 0.059, "Lunesu et al. 2025",   False),
        ("physical, live-weight max",  0.069, "Lunesu et al. 2025, young bulls", False),
    ])

# The numbers the page's table publishes for the two defaults. If the model
# no longer reproduces them the data has moved and the figure would be stale.
# 2026-10-24 (R5, D-26/D-27): 13.18 -> 13.37 (milk share 0.85 -> IDF's 0.88,
# corrected GWPs) and 3.66 -> 10.56 (tanning no longer carries the hide's
# 2.2%, so the contested stage fell from 9% of the pair to under 2%).
PUBLISHED = {"cheese": 13.37, "leather_shoes": 10.56}


def total_at(item, stages, share):
    """Run the model with the contested stages at `share`, restoring the
    data afterwards. `None` means the shipped value."""
    p = PRODUCTS[item]
    saved = {}
    try:
        for st in p["stages"]:
            if st["id"] in stages and share is not None:
                saved[st["id"]] = st["share"]
                st["share"] = share
        return lca.Model(item, p["default_origin"], p["default_dest"]).run()["total"]
    finally:
        for st in p["stages"]:
            if st["id"] in saved:
                st["share"] = saved[st["id"]]


def compute(panel):
    rows = []
    for label, share, source, default in panel["bases"]:
        t = total_at(panel["item"], panel["stages"], share)
        if default:
            shipped = total_at(panel["item"], panel["stages"], None)
            if abs(t - shipped) > 1e-9:
                raise SystemExit(f"{panel['item']}: the base marked default "
                                 f"({share}) is not the shipped share")
            if round(t, 2) != PUBLISHED[panel["item"]]:
                raise SystemExit(f"{panel['item']}: model gives {t:.2f}, page "
                                 f"table says {PUBLISHED[panel['item']]}; "
                                 "regenerate the table before this figure")
        rows.append((label, share, source, default, t))
    published = [r[4] for r in rows if r[2] not in ("assumed", "reference")]
    spread = max(published) / min(published)
    return rows, spread


# The source note under the figure. Both renders print it; the 714 keeps its
# hand-set breaks, the 350 breaks it by measured width (_fill).
FOOT = ("Spread = highest ÷ lowest total across the published bases shown; the model’s assumed\n"
        "2.2% and the 100% no-allocation case are drawn grey and not counted. Bars: the shipped\n"
        "default in dark blue, published alternatives in light blue. Milk–meat factors: Flysjö,\n"
        "Cederberg, Henriksson & Ledgard 2011, Int J LCA 16:420, Table 1; IDF Bulletin 479 (2015)\n"
        "pp. 35–36. Hide factors: Lunesu et al. 2025, Animals 15:3546. Every bar is one run of\n"
        "climate-cost/lca.py with that factor on the contested edge; drawn by build_allocation_figure.py.")


# ------------------------------------------------------------------ draw ----
def draw(cheese, shoes, out):
    sitefig.style()
    # Drawn at the width it is shown: the text column of a notes page, 714px
    # (sitefig NOTES). Until 2026-09-05 this was fig_size(PROSE, 1.7), a
    # 1140px render squeezed to 714 on climate-cost.html, its 12px labels at
    # 7.5 on screen - the model chart's fault in reverse (PHASE4 A3). Two
    # panels side by side do not fit 714 with these labels, so they stack.
    w, h = fig_size(NOTES, 0.92)
    fig, axes = plt.subplots(2, 1, figsize=(w, h), sharex=True,
                             gridspec_kw=dict(hspace=0.62))
    texts = []
    xmax = 19.0     # room for the "15.4 kg" label at 714px

    for ax, (panel, (rows, spread)) in zip(axes, ((CHEESE, cheese), (SHOES, shoes))):
        n = len(rows)
        ys = list(range(n))[::-1]
        for y, (label, share, source, default, t) in zip(ys, rows):
            col = SLATE if source in ("assumed", "reference") else (ACC if default else COOL)
            ax.barh(y, t, height=0.62, color=col, edgecolor="none")
            texts.append(ax.text(t + 0.18, y, f"{t:.1f} kg", va="center",
                                 ha="left", fontsize=FS_2, color=INK))
            # the factor, inside the bar when there is room, else after the number
            ftxt = f"{share*100:.1f}%" if share < 0.1 else f"{share*100:.0f}%"
            if t > 2.4:
                texts.append(ax.text(0.18, y, ftxt, va="center", ha="left",
                                     fontsize=FS_2, color=BG))
            else:
                texts.append(ax.text(t + 1.55, y, ftxt, va="center", ha="left",
                                     fontsize=FS_2, color=DIM))
        ax.set_yticks(ys)
        ax.set_yticklabels([r[0] for r in rows], fontsize=FS_2)
        ax.tick_params(axis="y", length=0, pad=6)
        ax.set_xlim(0, xmax)
        ax.set_xticks(range(0, int(xmax) + 1, 5))   # matplotlib's extra tick at 20 sat off the canvas
        ax.set_ylim(-0.7, n - 0.3)
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.spines["bottom"].set_color(RULE)
        ax.set_xlabel("kg CO₂e per functional unit", fontsize=FS_2, color=DIM)
        ax.xaxis.grid(True, color=FAINT, linewidth=0.8)
        ax.set_axisbelow(True)
        # No figure title and no subtitle: the page heading and caption do that
        # job (sitefig: "a figure carries none; a sheet labels its panels").
        # A two-panel sheet keeps one short label per panel, set through
        # sitefig.panel() so it is the same furniture as every other sheet.
        sitefig.panel(ax, panel["label"], pad=10)
        texts += sitefig.titles(ax)
        texts.append(ax.text(1.0, -0.2, f"spread ×{spread:.2f}",
                             transform=ax.transAxes, ha="right", va="top",
                             fontsize=FS_1, color=INK))
        share_of = _stage_share(panel)
        texts.append(ax.text(0, -0.2, f"contested stage: {share_of:.0%} of the total",
                             transform=ax.transAxes, ha="left", va="top",
                             fontsize=FS_2, color=DIM))

    foot = FOOT
    texts.append(fig.text(0.045, 0.012, foot, fontsize=FS_2, color=DIM,
                          va="bottom", ha="left", linespacing=1.45))
    fig.subplots_adjust(left=0.30, right=0.975, top=0.94, bottom=0.30)
    sitefig.centre(fig)      # the margins above are a guess; this measures
    problems = audit(fig, texts)
    size = save(fig, out)
    return size, problems


def _fill(fig, text, room_px, **kw):
    """Break `text` into lines no wider than `room_px` as drawn, word by word.

    The 350 render's long strings (panel labels, the source note) are wrapped
    by MEASURING each candidate line, not by a character count: sitefig's 26
    and 11 are two such counts already, and a third is the trigger recorded
    beside sitefig.wrap_label that says the parameter is wrong. Same words in
    the same order; only where the lines break moves."""
    r = fig.canvas.get_renderer()
    probe = fig.text(0, 0, "", **kw)

    def width(s):
        probe.set_text(s)
        return probe.get_window_extent(renderer=r).width

    lines, cur = [], ""
    for word in text.split():
        cand = word if not cur else cur + " " + word
        if cur and width(cand) > room_px:
            lines.append(cur)
            cur = word
        else:
            cur = cand
    lines.append(cur)
    too_wide = any(width(l) > room_px for l in lines)
    probe.remove()
    if too_wide:
        raise SystemExit(f"_fill: a single word is wider than {room_px:.0f}px")
    return "\n".join(lines)


def draw_phone(cheese, shoes, out):
    """The 350 render: a second figure, not a scaled one (Stage A, 2026-10-18).

    At 350 the 714's label column leaves the bars no room: the 714 layout drawn
    at 350 reports 53 audit problems, the row labels off the canvas at every
    aspect tried. So each row's label sits ABOVE its bar, left-aligned, and the
    bar runs the full width. Value and factor stay where the 714 has them; the
    panel labels and the source note break by measured width (_fill). Same
    rows, numbers and words."""
    sitefig.style()
    rows_n = len(cheese[0]) + len(shoes[0])
    # fig_size takes width / height. Height: ~46px a row (label line + bar),
    # ~130px per panel for its label, axis and footer line, ~180px for the
    # ten-line note.
    w, h = fig_size(PHONE, PHONE / (46 * rows_n + 2 * 130 + 180))
    fig = plt.figure(figsize=(w, h))
    W = fig.get_size_inches()[0] * fig.dpi
    texts = []
    xmax = 19.0
    foot_kw = dict(fontsize=FS_2, color=DIM, linespacing=1.45)
    foot = _fill(fig, " ".join(FOOT.split()), W * 0.92, **foot_kw)
    foot_t = fig.text(0.04, 0.008, foot, va="bottom", ha="left", **foot_kw)
    texts.append(foot_t)
    fig.canvas.draw()
    foot_top = foot_t.get_window_extent().y1 / (h * fig.dpi)

    heights = [len(cheese[0]), len(shoes[0])]
    gs = fig.add_gridspec(2, 1, height_ratios=heights, hspace=0.80,
                          left=0.04, right=0.96, top=0.93, bottom=foot_top + 0.075)
    axes = [fig.add_subplot(gs[0]), fig.add_subplot(gs[1])]
    for ax, (panel, (rows, spread)) in zip(axes, ((CHEESE, cheese), (SHOES, shoes))):
        n = len(rows)
        ys = list(range(n))[::-1]
        ax.set_xlim(0, xmax)
        ax.set_ylim(-0.75, n - 0.05)
        fig.canvas.draw()
        r = fig.canvas.get_renderer()
        for y, (label, share, source, default, t) in zip(ys, rows):
            col = SLATE if source in ("assumed", "reference") else (ACC if default else COOL)
            ax.barh(y - 0.18, t, height=0.40, color=col, edgecolor="none")
            texts.append(ax.text(0, y + 0.10, label, va="bottom", ha="left",
                                 fontsize=FS_2, color=INK))
            v = ax.text(t + 0.18, y - 0.18, f"{t:.1f} kg", va="center",
                        ha="left", fontsize=FS_2, color=INK)
            texts.append(v)
            ftxt = f"{share*100:.1f}%" if share < 0.1 else f"{share*100:.0f}%"
            inside = ax.text(0.18, y - 0.18, ftxt, va="center", ha="left",
                             fontsize=FS_2, color=BG)
            # inside the bar only if it ends inside the bar, measured; BG text
            # past a bar's end is invisible, and no audit would say so
            bar_end = ax.transData.transform((t, 0))[0]
            if inside.get_window_extent(renderer=r).x1 + 3 > bar_end:
                inside.remove()
                vx1 = v.get_window_extent(renderer=r).x1
                x_after = ax.transData.inverted().transform((vx1 + 8, 0))[0]
                inside = ax.text(x_after, y - 0.18, ftxt, va="center",
                                 ha="left", fontsize=FS_2, color=DIM)
            texts.append(inside)
        ax.set_yticks([])
        ax.set_xticks(range(0, int(xmax) + 1, 5))
        for s in ("top", "right", "left"):
            ax.spines[s].set_visible(False)
        ax.spines["bottom"].set_color(RULE)
        ax.set_xlabel("kg CO₂e per functional unit", fontsize=FS_2, color=DIM)
        ax.xaxis.grid(True, color=FAINT, linewidth=0.8)
        ax.set_axisbelow(True)
        lab = "\n".join(_fill(fig, part, W * 0.92, fontsize=FS_1, fontfamily=MONO)
                        for part in panel["label"].split("\n"))
        sitefig.panel(ax, lab, pad=8)
        texts += sitefig.titles(ax)
        share_of = _stage_share(panel)
        # placed in points under the x label, not in axes fractions: the
        # two panels differ in height, so one fraction is two distances
        # -48, not -40: under Perfidy an x label's box is 1.25 em tall, not
        # 1.00 as under IBM Plex, and -40 put this line on it (2026-11-08)
        texts.append(ax.annotate(f"contested stage: {share_of:.0%} of the total",
                                 (0, 0), xycoords="axes fraction",
                                 xytext=(0, -48), textcoords="offset points",
                                 ha="left", va="top", fontsize=FS_2, color=DIM))
        texts.append(ax.annotate(f"spread ×{spread:.2f}",
                                 (1, 0), xycoords="axes fraction",
                                 xytext=(0, -48), textcoords="offset points",
                                 ha="right", va="top", fontsize=FS_1, color=INK))
    sitefig.centre(fig)
    problems = audit(fig, texts)
    size = save(fig, out)
    return size, problems


def _stage_share(panel):
    p = PRODUCTS[panel["item"]]
    r = lca.Model(panel["item"], p["default_origin"], p["default_dest"]).run()
    return sum(s["total"] for s in r["spine"] if s["id"] in panel["stages"]) / r["total"]


def audit(fig, texts):
    """The sibling builders' checks: nothing under the on-screen floor,
    nothing off the canvas, no two labels on top of each other."""
    fig.canvas.draw()
    r = fig.canvas.get_renderer()
    items = [(t, t.get_fontsize() >= FS0) for t in texts]
    for ax in fig.axes:
        items += [(t, False) for t in ax.get_yticklabels() + ax.get_xticklabels()]
        items.append((ax.xaxis.label, False))
    problems = floor_problems(fig, items) + sitefig.grid_problems(fig)
    W, H = fig.get_size_inches() * fig.dpi
    boxes = []
    for t, _ in items:
        if not t.get_text().strip():
            continue
        b = t.get_window_extent(renderer=r)
        if b.x0 < -1 or b.y0 < -1 or b.x1 > W + 1 or b.y1 > H + 1:
            problems.append(f"off canvas: {t.get_text()[:30]!r}")
        boxes.append((b, t.get_text()[:30]))
    for i in range(len(boxes)):
        for j in range(i + 1, len(boxes)):
            a, b = boxes[i][0], boxes[j][0]
            if a.overlaps(b) and boxes[i][1] != boxes[j][1]:
                problems.append(f"overlap: {boxes[i][1]!r} / {boxes[j][1]!r}")
    return problems


def main():
    cheese = compute(CHEESE)
    shoes = compute(SHOES)
    for name, (rows, spread) in (("cheese", cheese), ("shoes", shoes)):
        print(f"\n{name}: spread x{spread:.2f} (highest / lowest published)")
        for label, share, source, default, t in rows:
            print(f"  {label:30s} {share:6.3f}  {t:6.2f} kg   {source}"
                  f"{'   <- shipped default' if default else ''}")
    if "--check" in sys.argv:
        return 0
    size, problems = draw(cheese, shoes, OUT)
    print(f"\nwritten {OUT} ({size/1024:.0f} kB)")
    size, phone = draw_phone(cheese, shoes, OUT_PHONE)
    print(f"written {OUT_PHONE} ({size/1024:.0f} kB)")
    problems += [f"350: {p}" for p in phone]
    if problems:
        print("audit:")
        for p in problems:
            print("  " + p)
        return 1
    print("audit: 0 problems")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
