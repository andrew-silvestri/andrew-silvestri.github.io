# The true climate cost of a thing

A life-cycle model that shows its working. Give it an item, a producing region
and a destination, and it returns the chain as it happens: a spine of stages
from the field to the bin, with a branching tree under each stage showing where
that stage's emissions came from. The branches have branches, and every edge
carries the share of that process the product is charged for.

## Contents

| File | What it is |
|---|---|
| `lca.py` | The engine and the command line. Also writes the visualiser with `--build`. |
| `data/processes.py` | The process graph: every process, its direct emissions, its inputs, and the allocation basis on each edge, each with the note and source it came from. |
| `engine.js` | The same arithmetic in JavaScript, so the page recomputes rather than looking answers up. `climate-cost/test_scene.js` checks the two against each other. |
| `scene.js` | The visualiser's drawing. |
| `template.html` | The visualiser's shell; `lca.py --build` fills in the engine, the scene and the data. |
| `test_lca.py` | The model against its published ranges, the tree summing at every node, a stage's allocation reaching the processes beneath it, the levers moving the answer the way physics says, and the corrected inputs (warming potentials, soil factor, milk share, tanning) held a second time. `--break tanning\|gwp\|milk` puts one back and must exit 1. |
| `update_page.py`, `page.html` | Write the article, climate-cost.html, from the model: every number on it is computed here. They import `insight.py` and `add_citations.py` from the site repository, which this archive does not carry, so they document the page rather than run from here. |
| `test_scene.js` | The JavaScript engine against `lca.py`, plus the scene's layout and overlap checks. |

## Run it

```
python3 lca.py                      # the default item, a field tomato, Spain to Texas
python3 lca.py --list               # every item, region and freight mode
python3 lca.py --all                # one line per item at its default route
python3 lca.py --item cheese --from FR --to US-NY
python3 lca.py --build              # writes climate-cost.html, self-contained
python3 test_lca.py                 # prints "0 failure(s)"
python3 test_lca.py --break tanning # exits 1: the check sees the old fault
```

`test_scene.js` is here for completeness and does **not** run from this archive:
it loads jsdom and three from the site repository's `tests/node_modules`, which
is not part of it.

## What to expect

`--all` prints twenty items at their default routes, from beef at 53.08 kg CO2e
per kilogram as eaten down to a field tomato at 0.67. `test_lca.py` prints
`0 failure(s)`; every total lands inside the published range it is checked
against, and the cutoff it applies discards under 1% of any total.

## The assumptions, which are the point

- **Allocation is stated on every edge**, not buried. A slaughterhouse also
  makes leather, a dairy cow also becomes beef, and the share charged to the
  product in the model is a judgement with a named basis. Where the shared
  stage is most of the answer - cheese - the published bases disagree by half
  again. The engine's default picks one of them (0.88, the International
  Dairy Federation's 2015 physical formula for a typical herd), and
  `build_allocation_figure.py` runs each of them.
- **Global warming potentials are 100-year values** from IPCC AR6 Table 7.15
  as corrected by the errata of 7 October 2025: methane of non-fossil origin
  25.3, fossil methane 28.1, nitrous oxide 267. `data/processes.py` restates
  each single-gas figure from the value it was written at through `gas()`,
  so the correction is one visible multiplication.
- **Corrected 24 October 2026**: tanning is charged to the leather shoe in
  full (it had carried the hide's 2.2% share), soil nitrous oxide counts the
  indirect part as well as the direct, and the cheese's milk share is IDF's.
  The article's Corrections section lists every total that moved.
- **Corrected 10 November 2026**: a co-product share now applies to every
  stage that flows into the stage where the products separate, as ISO 14044
  allocates the inputs of a multi-output process, so the slaughterhouse's
  0.72 to the meat covers the animal too (`lca.py` `stage_shares()`; until
  then the beef carried its animal in full). The foods with a co-product fell
  9-30%; beef 73.42 -> 53.08.
- **A vehicle's factory is divided by the distance it will cover**, and that
  lifetime is an assumption rather than a measurement. It is exposed as a
  control so it can be argued with instead of inherited.
- **Production electricity and consumption electricity are charged
  separately**, at the grid of the region where each happens.
