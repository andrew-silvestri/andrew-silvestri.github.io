"""
Process data for the life-cycle model.

Every number here is a per-functional-unit emission factor with a stated basis.
The structure is deliberately not a flat table of footprints: a flat table can
tell you a tomato is 0.4 kg CO2e and nothing else. This is a graph of processes,
each of which knows what it consumes, so the model can be asked *why* — which is
the whole point.

Two ideas carry the weight.

**Direct emissions** are what a process releases itself, per unit of its own
output. A tractor pass emits diesel combustion products. A field emits nitrous
oxide. Nothing upstream is included.

**Allocation** is the fraction of a process that should be charged to our
product. This is the part most footprint numbers hide. A dairy cow produces milk
and, eventually, beef; charging all of her methane to the milk is a choice, not
a measurement. ISO 14044 asks for physical causality first and economic value
second, and where the split is genuinely arbitrary this file says so in the
note. Allocation multiplies down a chain: a fertiliser plant's emissions reach
our tomato multiplied by every allocation factor between them.

Emission factors are drawn from the ranges in Poore & Nemecek (Science, 2018),
IPCC AR6 Chapter 7 and the 2019 Refinement to the IPCC Guidelines, ecoinvent
process descriptions, and DEFRA/BEIS transport factors. They are representative
figures for a class of production, not measurements of any particular farm.
"""

# ---------------------------------------------------------------- regions ---
# Grid intensity in kg CO2e per kWh, and a coordinate for distance.
# Grid figures are operating margin, roughly 2023-2024.
REGIONS = {
    "ES": dict(name="Spain",        lat=40.0, lon=-3.7,   grid=0.17),
    "NL": dict(name="Netherlands",  lat=52.1, lon=5.3,    grid=0.27),
    "MA": dict(name="Morocco",      lat=31.8, lon=-7.1,   grid=0.61),
    "MX": dict(name="Mexico",       lat=23.6, lon=-102.6, grid=0.42),
    "US-TX": dict(name="Texas",     lat=31.0, lon=-99.0,  grid=0.37),
    "US-CA": dict(name="California",lat=36.8, lon=-119.4, grid=0.21),
    "US-NY": dict(name="New York",  lat=42.9, lon=-75.5,  grid=0.21),
    "BR": dict(name="Brazil",       lat=-14.2, lon=-51.9, grid=0.10),
    "CO": dict(name="Colombia",     lat=4.6,  lon=-74.1,  grid=0.16),
    "ET": dict(name="Ethiopia",     lat=9.1,  lon=40.5,   grid=0.03),
    "CN": dict(name="China",        lat=35.9, lon=104.2,  grid=0.55),
    "IN": dict(name="India",        lat=20.6, lon=79.0,   grid=0.63),
    "AU": dict(name="Australia",    lat=-25.3, lon=133.8, grid=0.51),
    "NZ": dict(name="New Zealand",  lat=-41.0, lon=174.9, grid=0.10),
    "KE": dict(name="Kenya",        lat=-0.02, lon=37.9,  grid=0.09),
    "CI": dict(name="Cote d'Ivoire",lat=7.5,  lon=-5.5,   grid=0.44),
    "FR": dict(name="France",       lat=46.6, lon=2.2,    grid=0.06),
    "IT": dict(name="Italy",        lat=41.9, lon=12.6,   grid=0.33),
    "PE": dict(name="Peru",         lat=-9.2, lon=-75.0,  grid=0.25),
    "VN": dict(name="Vietnam",      lat=14.1, lon=108.3,  grid=0.44),
}

# ------------------------------------------------------------- transport ----
# kg CO2e per tonne-kilometre, well-to-wheel. Air freight is two orders of
# magnitude worse than sea and that single fact decides more food footprints
# than any farming practice.
TRANSPORT = {
    "sea":   dict(name="container ship", ef=0.012, speed_kmh=37,
                  note="DEFRA 2023 bulk container, well-to-wheel"),
    "road":  dict(name="refrigerated truck", ef=0.115, speed_kmh=65,
                  note="DEFRA 2023 articulated HGV, refrigerated uplift"),
    "rail":  dict(name="freight rail", ef=0.028, speed_kmh=45,
                  note="DEFRA 2023 freight rail"),
    "air":   dict(name="air freight", ef=1.05, speed_kmh=800,
                  note="DEFRA 2023 long-haul belly freight, with RFI ~1.9"),
}

# --------------------------------------------------------------- processes --
# direct: kg CO2e per unit of this process's own output
# unit:   what one unit of output is
# inputs: (process id, amount of that input per unit of this output, allocation)
#
# The allocation on an edge answers: of this input's burden, what share belongs
# to us? It is 1.0 unless the input process makes something else too.
PROCESSES = {

    # ---- energy and materials, the deep background ----------------------
    "natgas_extraction": dict(
        name="Natural gas extraction", unit="kg gas", direct=0.42,
        note="Includes about 1.5% fugitive methane at 82x GWP20-equivalent "
             "accounting on a 100-year basis; the leak rate is the single most "
             "disputed number in the gas chain and ranges 0.5-3.5%.",
        quality="B", inputs=[]),
    "ammonia": dict(
        name="Ammonia synthesis (Haber-Bosch)", unit="kg N", direct=1.9,
        note="Steam methane reforming plus synthesis. About 1.2 kg of the "
             "total is process CO2 from reforming and 0.7 kg is combustion.",
        quality="A", inputs=[("natgas_extraction", 0.62, 1.0)]),
    "nitrate_fert": dict(
        name="Nitric acid and nitrate finishing", unit="kg N", direct=1.4,
        note="Nitrous oxide from nitric acid production. Abated plants emit a "
             "fifth of this; unabated ones several times more.",
        quality="B", inputs=[("ammonia", 1.0, 1.0)]),
    "phosphate_fert": dict(
        name="Phosphate rock and processing", unit="kg P2O5", direct=1.1,
        note="Mining, beneficiation, acidulation.", quality="B", inputs=[]),
    "pesticide": dict(
        name="Pesticide manufacture", unit="kg active", direct=11.0,
        note="Energy-intensive fine chemical synthesis. Small mass, large "
             "factor, usually a minor share of a crop total.",
        quality="C", inputs=[("natgas_extraction", 1.8, 1.0)]),
    "diesel": dict(
        name="Diesel, refined and burned", unit="litre", direct=3.17,
        note="2.68 kg tailpipe plus about 0.49 kg refining and distribution.",
        quality="A", inputs=[]),
    "steel": dict(
        name="Steel, primary", unit="kg", direct=2.1,
        note="Blast furnace route.", quality="A", inputs=[]),
    "plastic_film": dict(
        name="Polyethylene film", unit="kg", direct=2.6,
        note="Resin plus extrusion.", quality="B",
        inputs=[("natgas_extraction", 0.9, 1.0)]),
    "cardboard": dict(
        name="Corrugated board", unit="kg", direct=0.94,
        note="Mixed virgin and recycled fibre, European average.",
        quality="B", inputs=[]),
    "glass_jar": dict(
        name="Glass container", unit="kg", direct=1.25,
        note="Furnace melt dominates. Heavy, which makes transport matter.",
        quality="B", inputs=[]),

    # ---- shared farm operations -----------------------------------------
    "field_n2o": dict(
        name="Soil nitrous oxide", unit="kg N applied", direct=4.4,
        note="IPCC 2019 refinement: about 1% of applied nitrogen leaves as "
             "N2O-N, and nitrous oxide is 273 times carbon dioxide over a "
             "century. This is why nitrogen dominates crop footprints.",
        quality="A", inputs=[]),
    "tillage": dict(
        name="Tillage and field passes", unit="hectare-season", direct=0.0,
        note="Emissions arrive through diesel.", quality="B",
        inputs=[("diesel", 95.0, 1.0)]),
    "irrigation_kwh": dict(
        name="Irrigation pumping", unit="kWh", direct=0.0,
        note="Charged at the producing region's grid intensity.",
        quality="A", inputs=[], grid_scaled=True),
    "process_kwh": dict(
        name="Processing electricity", unit="kWh", direct=0.0,
        note="Electricity used where the thing is made - milking parlours, "
             "slaughter lines, hulling, milling, glasshouse handling - and "
             "therefore charged at the PRODUCING region's grid, not the "
             "consuming one. Getting this backwards is an easy and invisible "
             "error: it makes a French dairy look dirty because someone in "
             "India ate the cheese.",
        quality="A", inputs=[], grid_scaled=True),
    "cold_store_origin": dict(
        name="Cold storage at origin", unit="kWh", direct=0.0,
        note="Chilling before export, charged at the producing grid.",
        quality="A", inputs=[], grid_scaled=True),
    "greenhouse_heat": dict(
        name="Greenhouse heating", unit="kg gas burned", direct=2.75,
        note="Combustion only. Heated winter production in northern Europe "
             "can exceed the entire rest of a tomato's chain.",
        quality="A", inputs=[("natgas_extraction", 1.0, 1.0)]),

    # ---- post-farm -------------------------------------------------------
    "cold_store_kwh": dict(
        name="Cold storage", unit="kWh", direct=0.0,
        note="Charged at the consuming region's grid intensity.",
        quality="A", inputs=[], grid_scaled=True, consumer_grid=True),
    "retail_kwh": dict(
        name="Retail refrigeration and lighting", unit="kWh", direct=0.0,
        note="Includes an allowance for refrigerant leakage, which for older "
             "supermarket systems can rival the electricity itself.",
        quality="B", inputs=[], grid_scaled=True, consumer_grid=True),
    "home_kwh": dict(
        name="Household use", unit="kWh", direct=0.0,
        note="Refrigeration and cooking in the consuming region.",
        quality="B", inputs=[], grid_scaled=True, consumer_grid=True),
    "landfill": dict(
        name="Food waste to landfill", unit="kg waste", direct=0.55,
        note="Anaerobic decay to methane, partially captured. Composting or "
             "digestion is roughly a fifth of this.",
        quality="B", inputs=[]),
}

# ---------------------------------------------------------------- products --
# Each product is a spine of life-cycle stages. A stage lists its inputs the
# same way a process does. Amounts are per kilogram of product as eaten, so
# losses along the chain are already folded into the amounts.
PRODUCTS = {

    "tomato_field": dict(
        name="Tomato, field grown", unit="1 kg as eaten", category="Vegetable",
        note="Open-field production. The comparison with the heated-greenhouse "
             "entry is the clearest demonstration in this model that how a "
             "thing is grown matters more than how far it travelled.",
        default_origin="ES", default_dest="US-TX",
        waste_frac=0.19, transport_mode="sea",
        stages=[
            dict(id="cultivation", name="Cultivation", inputs=[
                ("field_n2o", 0.0035, 1.0),
                ("ammonia", 0.0035, 1.0),
                ("nitrate_fert", 0.0012, 1.0),
                ("phosphate_fert", 0.0009, 1.0),
                ("pesticide", 0.00012, 1.0),
                ("irrigation_kwh", 0.075, 1.0),
                ("tillage", 0.00002, 1.0),
            ], direct=0.0,
               note="Nitrogen enters three ways: as the ammonia that made the "
                    "fertiliser, as the nitric acid that finished it, and as "
                    "the nitrous oxide the soil releases afterwards. The third "
                    "is usually the largest and is invisible at the farm gate."),
            dict(id="harvest", name="Harvest and grading", inputs=[
                ("diesel", 0.010, 1.0)], direct=0.0,
                note="Mechanical harvest and on-farm handling."),
            dict(id="packing", name="Packing", inputs=[
                ("cardboard", 0.055, 1.0),
                ("plastic_film", 0.008, 1.0),
                ("cold_store_origin", 0.045, 1.0)], direct=0.0,
                note="Packaging is small for produce sold loose and grows "
                     "quickly for anything sold in a tray."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True,
                 note="Computed from the great-circle distance between origin "
                      "and destination and the chosen mode."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 240, 1.0),
                ("cold_store_kwh", 0.10, 1.0),
                ("retail_kwh", 0.14, 1.0)], direct=0.0,
                note="Regional haul plus time on a chilled shelf."),
            dict(id="consumer", name="Consumer", inputs=[
                ("home_kwh", 0.06, 1.0),
                ("road", 7, 1.0)], direct=0.0,
                note="Fridge time and a share of the drive home."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True,
                 note="Household and retail losses, sent to landfill."),
        ]),

    "tomato_greenhouse": dict(
        name="Tomato, heated greenhouse", unit="1 kg as eaten",
        category="Vegetable",
        note="Northern European winter production under glass. Same plant, "
             "same distance, different heating.",
        default_origin="NL", default_dest="US-NY",
        waste_frac=0.19, transport_mode="sea",
        stages=[
            dict(id="cultivation", name="Cultivation under glass", inputs=[
                ("greenhouse_heat", 0.62, 1.0),
                ("field_n2o", 0.0030, 1.0),
                ("ammonia", 0.0030, 1.0),
                ("nitrate_fert", 0.0010, 1.0),
                ("irrigation_kwh", 0.11, 1.0),
                ("plastic_film", 0.004, 1.0),
            ], direct=0.0,
               note="The heating term is the entire story. Everything else in "
                    "this product is within noise of the field-grown version."),
            dict(id="harvest", name="Harvest and grading", inputs=[
                ("process_kwh", 0.012, 1.0)], direct=0.0,
                note="Glasshouse handling is largely electric."),
            dict(id="packing", name="Packing", inputs=[
                ("cardboard", 0.060, 1.0),
                ("plastic_film", 0.012, 1.0),
                ("cold_store_origin", 0.045, 1.0)], direct=0.0,
                note="Glasshouse fruit is usually sold in trays."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="As chosen."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 240, 1.0),
                ("cold_store_kwh", 0.10, 1.0),
                ("retail_kwh", 0.14, 1.0)], direct=0.0, note="As above."),
            dict(id="consumer", name="Consumer", inputs=[
                ("home_kwh", 0.06, 1.0),
                ("road", 7, 1.0)], direct=0.0, note="As above."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="As above."),
        ]),

    "beef": dict(
        name="Beef, from a dedicated herd", unit="1 kg as eaten",
        category="Meat",
        note="A beef herd raised for meat, not a dairy cow at the end of her "
             "milking life. That distinction is worth more than a factor of "
             "two and is the most common sleight of hand in beef footprints.",
        default_origin="BR", default_dest="US-TX",
        waste_frac=0.12, transport_mode="sea",
        stages=[
            dict(id="enteric", name="Enteric fermentation", inputs=[],
                 direct=38.0,
                 note="Methane from rumen microbes, at 27 times carbon dioxide "
                      "over a century. No feed change removes this; it is what "
                      "a ruminant is."),
            dict(id="feed", name="Feed production", inputs=[
                ("field_n2o", 0.42, 1.0),
                ("ammonia", 0.42, 1.0),
                ("nitrate_fert", 0.15, 1.0),
                ("tillage", 0.0018, 1.0),
                ("diesel", 0.55, 1.0),
            ], direct=0.0,
               note="Roughly 25 kg of feed per kg of carcass, most of it "
                    "pasture or forage, with the nitrogen following it."),
            dict(id="manure", name="Manure management", inputs=[], direct=6.2,
                 note="Methane and nitrous oxide from stored manure. Highly "
                      "sensitive to whether storage is anaerobic."),
            dict(id="landuse", name="Land use change", inputs=[], direct=16.0,
                 note="Amortised pasture expansion into forest. This is the "
                      "term that separates a Brazilian figure from a European "
                      "one, and the amortisation window - twenty years by "
                      "convention - is an accounting choice, not a fact.",
                 land_use=True),
            dict(id="slaughter", name="Slaughter and processing", inputs=[
                ("process_kwh", 0.55, 1.0),
                ("cold_store_origin", 0.35, 1.0)], direct=0.0,
                allocation=0.72,
                note="Allocation: hide, tallow, offal and bone meal leave the "
                     "plant as saleable products, so not all of the plant's "
                     "burden belongs to the meat. 0.72 is an economic split; a "
                     "mass split would give roughly 0.55 and a different total."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="Frozen or chilled."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 380, 1.0),
                ("cold_store_kwh", 0.30, 1.0),
                ("retail_kwh", 0.25, 1.0)], direct=0.0,
                note="Meat sits in colder cabinets than produce."),
            dict(id="consumer", name="Consumer", inputs=[
                ("home_kwh", 0.55, 1.0),
                ("road", 9, 1.0)], direct=0.0,
                note="Freezer time and cooking, which for beef is significant."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Trim, bone and plate waste."),
        ]),

    "chicken": dict(
        name="Chicken", unit="1 kg as eaten", category="Meat",
        note="A monogastric animal with no rumen, which is most of why it "
             "sits an order of magnitude below beef.",
        default_origin="BR", default_dest="US-TX",
        waste_frac=0.12, transport_mode="sea",
        stages=[
            dict(id="feed", name="Feed production", inputs=[
                ("field_n2o", 0.055, 1.0),
                ("ammonia", 0.055, 1.0),
                ("nitrate_fert", 0.020, 1.0),
                ("tillage", 0.0004, 1.0),
                ("diesel", 0.12, 1.0),
            ], direct=2.10,
               note="About 2.9 kg of feed per kg of carcass, mostly maize and "
                    "soy. The direct term carries soy land-use change and the "
                    "crop emissions the nitrogen lines do not reach, and it is "
                    "the largest single item in a chicken - roughly half. Feed "
                    "is where poultry's footprint lives, which is why feed "
                    "conversion ratio is the number the industry optimises."),
            dict(id="housing", name="Housing and manure", inputs=[
                ("process_kwh", 0.35, 1.0)], direct=0.75,
                note="Heated sheds, ventilation and litter management."),
            dict(id="slaughter", name="Slaughter and processing", inputs=[
                ("process_kwh", 0.30, 1.0),
                ("cold_store_origin", 0.25, 1.0)], direct=0.0,
                allocation=0.78,
                note="Allocation: feathers, offal and meal are co-products."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="Usually frozen."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 380, 1.0),
                ("cold_store_kwh", 0.28, 1.0),
                ("retail_kwh", 0.22, 1.0)], direct=0.0, note="Chilled chain."),
            dict(id="consumer", name="Consumer", inputs=[
                ("home_kwh", 0.40, 1.0),
                ("road", 9, 1.0)], direct=0.0, note="Fridge and oven."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Bone and plate waste."),
        ]),

    "coffee": dict(
        name="Coffee, roasted beans", unit="1 kg roasted", category="Beverage",
        note="Per kilogram of beans this looks large; per cup it is small, and "
             "what happens in the kitchen afterwards can exceed everything "
             "that happened on the farm.",
        default_origin="CO", default_dest="US-TX",
        waste_frac=0.05, transport_mode="sea",
        stages=[
            dict(id="cultivation", name="Cultivation", inputs=[
                ("field_n2o", 0.038, 1.0),
                ("ammonia", 0.038, 1.0),
                ("nitrate_fert", 0.014, 1.0),
                ("pesticide", 0.0025, 1.0),
                ("diesel", 0.18, 1.0),
            ], direct=0.35,
               note="Shade-grown systems sequester carbon and can come in far "
                    "lower; full-sun intensive systems higher. The direct term "
                    "here is an average land-use figure."),
            dict(id="wet_mill", name="Wet milling", inputs=[
                ("process_kwh", 0.35, 1.0)], direct=0.62,
                allocation=0.55,
                note="Allocation: pulp and mucilage are separated here and are "
                     "increasingly sold rather than dumped. The direct term is "
                     "methane from wastewater lagoons, which is the whole "
                     "reason wet processing is worse than dry."),
            dict(id="drying", name="Drying and hulling", inputs=[
                ("diesel", 0.08, 1.0)], direct=0.0,
                note="Sun drying where climate allows, mechanical where not."),
            dict(id="freight", name="Freight to roaster", inputs=[],
                 direct=0.0, transport=True,
                 note="Green beans ship dry and unrefrigerated, which makes "
                      "sea freight almost free in emissions terms."),
            dict(id="roasting", name="Roasting", inputs=[
                ("natgas_extraction", 0.075, 1.0)], direct=0.21,
                note="Roasting drives off about 16% of the mass as water, so "
                     "a kilogram of roasted beans started as more."),
            dict(id="packing", name="Packing", inputs=[
                ("plastic_film", 0.035, 1.0),
                ("cardboard", 0.020, 1.0)], direct=0.0,
                note="Valved foil-laminate bags, hard to recycle."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 520, 1.0),
                ("retail_kwh", 0.08, 1.0)], direct=0.0,
                note="Ambient, so no refrigeration."),
            dict(id="consumer", name="Brewing", inputs=[
                ("home_kwh", 1.30, 1.0)], direct=0.0,
                note="Heating water, and keeping it hot. A drip machine left "
                     "on a hotplate can use more energy than the roast."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Spent grounds."),
        ]),

    "almond": dict(
        name="Almonds", unit="1 kg as eaten", category="Nut",
        note="The interesting number here is not carbon but water, which this "
             "model does not track - a caveat worth stating rather than "
             "burying, since almonds are usually criticised on grounds this "
             "model is silent about.",
        default_origin="US-CA", default_dest="US-NY",
        waste_frac=0.04, transport_mode="rail",
        stages=[
            dict(id="cultivation", name="Orchard", inputs=[
                ("field_n2o", 0.070, 1.0),
                ("ammonia", 0.070, 1.0),
                ("nitrate_fert", 0.025, 1.0),
                ("pesticide", 0.0018, 1.0),
                ("irrigation_kwh", 1.90, 1.0),
                ("diesel", 0.22, 1.0),
            ], direct=-0.35,
               note="The negative direct term is carbon held in orchard "
                    "biomass over a 25-year rotation. It is real, it is "
                    "temporary, and whether it belongs in an annual footprint "
                    "is a live argument. Irrigation pumping is the largest "
                    "single line and scales with the Californian grid."),
            dict(id="hulling", name="Hulling and shelling", inputs=[
                ("process_kwh", 0.28, 1.0)], direct=0.0, allocation=0.62,
                note="Allocation: hulls and shells go to cattle feed and "
                     "bedding, and are genuinely sold."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="Ambient, shelf-stable."),
            dict(id="packing", name="Packing", inputs=[
                ("plastic_film", 0.030, 1.0),
                ("cardboard", 0.025, 1.0)], direct=0.0, note="Bagged."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 380, 1.0),
                ("retail_kwh", 0.06, 1.0)], direct=0.0, note="Ambient."),
            dict(id="consumer", name="Consumer", inputs=[], direct=0.0,
                 note="Eaten as they are; no cooking energy."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Minimal."),
        ]),

    "banana": dict(
        name="Banana", unit="1 kg as eaten", category="Fruit",
        note="The standard counter-example to food miles: a fruit that travels "
             "eight thousand kilometres and still comes in low, because it "
             "travels by sea and needs no heating.",
        default_origin="PE", default_dest="US-NY",
        waste_frac=0.20, transport_mode="sea",
        stages=[
            dict(id="cultivation", name="Cultivation", inputs=[
                ("field_n2o", 0.011, 1.0),
                ("ammonia", 0.011, 1.0),
                ("nitrate_fert", 0.004, 1.0),
                ("pesticide", 0.0009, 1.0),
                ("diesel", 0.045, 1.0),
            ], direct=0.10,
               note="Plantation systems with heavy fungicide use."),
            dict(id="packing", name="Packing", inputs=[
                ("cardboard", 0.075, 1.0),
                ("plastic_film", 0.006, 1.0)], direct=0.0,
                note="Boxed at origin. Cardboard is a real share of a banana."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True,
                 note="Reefer containers at 13 degrees."),
            dict(id="ripening", name="Ripening rooms", inputs=[
                ("cold_store_kwh", 0.14, 1.0)], direct=0.0,
                note="Ethylene-controlled ripening on arrival."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 300, 1.0),
                ("retail_kwh", 0.07, 1.0)], direct=0.0,
                note="Displayed at ambient temperature."),
            dict(id="consumer", name="Consumer", inputs=[
                ("road", 7, 1.0)], direct=0.0, note="No cooking."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True,
                 note="High household waste; bananas are thrown away often."),
        ]),

    "cheese": dict(
        name="Cheese, hard", unit="1 kg as eaten", category="Dairy",
        note="Ten kilograms of milk make one of cheese, so every burden in the "
             "milk chain arrives multiplied by ten.",
        default_origin="FR", default_dest="US-NY",
        waste_frac=0.08, transport_mode="sea",
        stages=[
            dict(id="enteric", name="Enteric fermentation", inputs=[],
                 direct=8.4, allocation=0.85,
                 note="Allocation: a dairy cow yields milk and, at the end, "
                      "meat. 0.85 to milk is the IDF standard economic split. "
                      "Charging her whole methane output to milk would raise "
                      "this figure by nearly a fifth."),
            dict(id="feed", name="Feed production", inputs=[
                ("field_n2o", 0.20, 1.0),
                ("ammonia", 0.20, 1.0),
                ("nitrate_fert", 0.07, 1.0),
                ("tillage", 0.0009, 1.0),
                ("diesel", 0.30, 1.0),
            ], direct=0.0, allocation=0.85,
               note="Concentrate and forage, carried at the same milk split."),
            dict(id="manure", name="Manure management", inputs=[], direct=2.1,
                 allocation=0.85, note="Slurry storage."),
            dict(id="dairy", name="Milking and cooling", inputs=[
                ("process_kwh", 0.65, 1.0),
                ("cold_store_origin", 0.40, 1.0)], direct=0.0, allocation=0.85,
                note="On-farm chilling is continuous."),
            dict(id="cheesemaking", name="Cheesemaking", inputs=[
                ("natgas_extraction", 0.12, 1.0),
                ("process_kwh", 0.55, 1.0)], direct=0.0, allocation=0.90,
                note="Allocation: whey leaves as a saleable protein stream, so "
                     "a tenth of the burden goes with it."),
            dict(id="ageing", name="Ageing", inputs=[
                ("cold_store_origin", 1.10, 1.0)], direct=0.0,
                note="Months in a temperature-controlled store. Time itself "
                     "costs energy, which few footprints show."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="Chilled."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 380, 1.0),
                ("cold_store_kwh", 0.30, 1.0),
                ("retail_kwh", 0.24, 1.0)], direct=0.0, note="Chilled cabinet."),
            dict(id="consumer", name="Consumer", inputs=[
                ("home_kwh", 0.30, 1.0)], direct=0.0, note="Fridge time."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Rind and spoilage."),
        ]),

    "rice": dict(
        name="Rice", unit="1 kg as eaten", category="Staple",
        note="The only major staple whose emissions are dominated by methane "
             "from the field itself, because flooding a paddy creates exactly "
             "the anaerobic conditions methanogens want.",
        default_origin="IN", default_dest="US-CA",
        waste_frac=0.10, transport_mode="sea",
        stages=[
            dict(id="paddy", name="Paddy methane", inputs=[], direct=1.85,
                 note="Continuous flooding. Alternate wetting and drying cuts "
                      "this by roughly half and is the single largest "
                      "mitigation available in rice."),
            dict(id="cultivation", name="Cultivation", inputs=[
                ("field_n2o", 0.014, 1.0),
                ("ammonia", 0.014, 1.0),
                ("nitrate_fert", 0.005, 1.0),
                ("irrigation_kwh", 0.42, 1.0),
                ("diesel", 0.10, 1.0),
            ], direct=0.0, note="Nitrogen and pumping."),
            dict(id="milling", name="Milling", inputs=[
                ("process_kwh", 0.09, 1.0)], direct=0.0, allocation=0.80,
                note="Allocation: bran and husk are sold for oil and fuel."),
            dict(id="freight", name="Freight to market", inputs=[],
                 direct=0.0, transport=True, note="Bagged, ambient."),
            dict(id="packing", name="Packing", inputs=[
                ("plastic_film", 0.012, 1.0)], direct=0.0, note="Bagged."),
            dict(id="distribution", name="Distribution and retail", inputs=[
                ("road", 380, 1.0),
                ("retail_kwh", 0.04, 1.0)], direct=0.0, note="Ambient."),
            dict(id="consumer", name="Cooking", inputs=[
                ("home_kwh", 0.55, 1.0)], direct=0.0,
                note="Twenty minutes of boiling, every time."),
            dict(id="waste", name="End of life", inputs=[], direct=0.0,
                 waste=True, note="Plate waste."),
        ]),
}
